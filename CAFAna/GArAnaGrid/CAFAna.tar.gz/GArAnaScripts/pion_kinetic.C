// Make a simple ND-GAr plot
// cafe pion_kinetic.C

#include "CAFAna/Core/SpectrumLoader.h"
#include "CAFAna/Core/Spectrum.h"
#include "CAFAna/Core/Binning.h"
#include "CAFAna/Core/Var.h"
#include "CAFAna/Core/Cut.h"
#include "CAFAna/Core/HistAxis.h"

#include "GArUtils.h"

#include "duneanaobj/StandardRecord/Proxy/SRProxy.h"
#include "duneanaobj/StandardRecord/SRGAr.h"

#include <TFile.h>
#include "TCanvas.h"
#include "TH1.h"
#include "TH2.h"
#include "THStack.h"
#include "TRatioPlot.h"
#include "TLegend.h"
#include "TPad.h"
#include "TGaxis.h"
#include "TColor.h"

#include <string>
#include <vector>
#include <unordered_map>

using namespace ana;

void pion_kinetic()
{

  // Environment variables and wildcards work. As do SAM datasets.
  const std::string fname = "/exp/dune/data/users/fmlopez/ND_GAr/auto_jobsub_garg4_100k_seed/caf/ndgar_mini_prod_caf_*.root";

  // I think CAFAna gets the total POT normalization automatically...
  const double pot = 5.0e18;
    
  // Source of events
  SpectrumLoader loader(fname);

  TFile *fout = new TFile("pion_kinetic.root","RECREATE");

  const Binning binsKE = Binning::Simple(20, 0.0, 3.0);

  const float muon_score_cut = 0.35;
  const float delta_r = 50.0;
  const float p_thres = 0.08;
  const float proton_dEdx_cut = 0.8;
  const float proton_tof_cut = 0.8;
  const float delta_calo = 0.1;
  const float distance_cut = 100.0;

  Spectrum sPionKineticEnergyProton(loader[kIsContainedNuMuCC(muon_score_cut, delta_r)], SRHistAxis("Kinetic energy [GeV]", binsKE, kGetPionKEnergyPDG(muon_score_cut, 2212, p_thres, proton_dEdx_cut, proton_tof_cut, delta_calo, distance_cut)));
  Spectrum sPionKineticEnergyPion(loader[kIsContainedNuMuCC(muon_score_cut, delta_r)], SRHistAxis("Kinetic energy [GeV]", binsKE, kGetPionKEnergyPDG(muon_score_cut, 211, p_thres, proton_dEdx_cut, proton_tof_cut, delta_calo, distance_cut)));
  Spectrum sPionKineticEnergyMuon(loader[kIsContainedNuMuCC(muon_score_cut, delta_r)], SRHistAxis("Kinetic energy [GeV]", binsKE, kGetPionKEnergyPDG(muon_score_cut, 13, p_thres, proton_dEdx_cut, proton_tof_cut, delta_calo, distance_cut)));
  Spectrum sPionKineticEnergyElectron(loader[kIsContainedNuMuCC(muon_score_cut, delta_r)], SRHistAxis("Kinetic energy [GeV]", binsKE, kGetPionKEnergyPDG(muon_score_cut, 11, p_thres, proton_dEdx_cut, proton_tof_cut, delta_calo, distance_cut)));

  loader.Go();

  fout->cd();

  TH1D* hPionKineticEnergyProton(sPionKineticEnergyProton.ToTH1(pot));
  hPionKineticEnergyProton->SetName("PionKineticEnergyProton");
  hPionKineticEnergyProton->Write("PionKineticEnergyProton", TObject::kWriteDelete);

  TH1D* hPionKineticEnergyPion(sPionKineticEnergyPion.ToTH1(pot));
  hPionKineticEnergyPion->SetName("PionKineticEnergyPion");
  hPionKineticEnergyPion->Write("PionKineticEnergyPion", TObject::kWriteDelete);

  TH1D* hPionKineticEnergyMuon(sPionKineticEnergyMuon.ToTH1(pot));
  hPionKineticEnergyMuon->SetName("PionKineticEnergyMuon");
  hPionKineticEnergyMuon->Write("PionKineticEnergyMuon", TObject::kWriteDelete);

  TH1D* hPionKineticEnergyElectron(sPionKineticEnergyElectron.ToTH1(pot));
  hPionKineticEnergyElectron->SetName("PionKineticEnergyElectron");
  hPionKineticEnergyElectron->Write("PionKineticEnergyElectron", TObject::kWriteDelete);

  fout->Close();

  THStack *hStacked = new THStack("hStacked","");
  std::vector<TH1 *> vStacked;

  hPionKineticEnergyProton->SetFillColor(TColor::GetColor("#3f90da"));
  vStacked.push_back(hPionKineticEnergyProton);

  hPionKineticEnergyPion->SetFillColor(TColor::GetColor("#ffa90e"));
  vStacked.push_back(hPionKineticEnergyPion);

  hPionKineticEnergyMuon->SetFillColor(TColor::GetColor("#bd1f01"));
  vStacked.push_back(hPionKineticEnergyMuon);

  hPionKineticEnergyElectron->SetFillColor(TColor::GetColor("#94a4a2"));
  vStacked.push_back(hPionKineticEnergyElectron);

  std::sort(vStacked.begin(), vStacked.end(),
            [](TH1 *a, TH1 *b) { return a->Integral() < b->Integral(); });

  
  for (auto h: vStacked) {
    hStacked->Add(h);
  }

  TCanvas *c = new TCanvas("c", "canvas", 800, 600);

  c->SetLeftMargin(0.15);
  c->SetBottomMargin(0.10);
  c->SetGrid(); // Grid

  hStacked->Draw("hist");

  // Y axis ratio plot settings
  hStacked->GetYaxis()->SetTitle("Counts");
  hStacked->GetYaxis()->SetNdivisions(505);
  hStacked->GetYaxis()->SetTitleSize(25);
  hStacked->GetYaxis()->SetTitleFont(43);
  hStacked->GetYaxis()->SetTitleOffset(2.5);
  hStacked->GetYaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
  hStacked->GetYaxis()->SetLabelSize(25);

  // X axis ratio plot settings
  hStacked->GetXaxis()->SetTitle("Proton ToF Score");
  hStacked->GetXaxis()->SetTitleSize(25);
  hStacked->GetXaxis()->SetTitleFont(43);
  hStacked->GetXaxis()->SetTitleOffset(1.0);
  hStacked->GetXaxis()->SetLabelFont(43); // Absolute font size in pixel (precision 3)
  hStacked->GetXaxis()->SetLabelSize(25);

  TLegend legend( .45, .50, .85, .85 );
  legend.SetTextSize(0.05);
  legend.AddEntry( hPionKineticEnergyProton, "p" );
  legend.AddEntry( hPionKineticEnergyPion, "\\pi^{\\pm}" );
  legend.AddEntry( hPionKineticEnergyMuon, "\\mu^{\\pm}" );
  legend.AddEntry( hPionKineticEnergyElectron, "e^{\\pm}" );
  legend.SetFillStyle(0);
  legend.Draw();

  c->Draw();

  c->SaveAs("pion_kinetic_energy.pdf");

}
