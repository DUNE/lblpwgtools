#pragma once

#include "CAFAnaCore/CAFAna/Core/MultiVar.h"

#include "duneanaobj/StandardRecord/Proxy/FwdDeclare.h"

namespace ana
{
  typedef _MultiVar<caf::SRProxy> MultiVar;
}
