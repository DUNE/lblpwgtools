// n.b.: this file exists only so that CMake can discover all the *other* headers that it depends on

#include "duneanaobj/StandardRecord/StandardRecord.h"
