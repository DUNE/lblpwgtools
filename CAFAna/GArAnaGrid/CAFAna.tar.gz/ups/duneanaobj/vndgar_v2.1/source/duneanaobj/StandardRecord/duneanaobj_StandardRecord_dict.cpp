// Do NOT change. Changes will be lost next time file is generated

#define R__DICTIONARY_FILENAME duneanaobj_StandardRecord_dict
#define R__NO_DEPRECATION

/*******************************************************************/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#define G__DICTIONARY
#include "RConfig.h"
#include "TClass.h"
#include "TDictAttributeMap.h"
#include "TInterpreter.h"
#include "TROOT.h"
#include "TBuffer.h"
#include "TMemberInspector.h"
#include "TInterpreter.h"
#include "TVirtualMutex.h"
#include "TError.h"

#ifndef G__ROOT
#define G__ROOT
#endif

#include "RtypesImp.h"
#include "TIsAProxy.h"
#include "TFileMergeInfo.h"
#include <algorithm>
#include "TCollectionProxyInfo.h"
/*******************************************************************/

#include "TDataMember.h"

// Header files passed as explicit arguments
#include "/exp/dune/app/users/fmlopez/ndgar_tests/duneanaobj/duneanaobj/StandardRecord/classes.h"

// Header files passed via #pragma extra_include

// The generated code does not explicitly qualify STL entities
namespace std {} using namespace std;

namespace ROOT {
   static TClass *cafcLcLSRVector3D_Dictionary();
   static void cafcLcLSRVector3D_TClassManip(TClass*);
   static void *new_cafcLcLSRVector3D(void *p = nullptr);
   static void *newArray_cafcLcLSRVector3D(Long_t size, void *p);
   static void delete_cafcLcLSRVector3D(void *p);
   static void deleteArray_cafcLcLSRVector3D(void *p);
   static void destruct_cafcLcLSRVector3D(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRVector3D*)
   {
      ::caf::SRVector3D *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRVector3D));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRVector3D", 10, "SRVector3D.h", 25,
                  typeid(::caf::SRVector3D), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRVector3D_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRVector3D) );
      instance.SetNew(&new_cafcLcLSRVector3D);
      instance.SetNewArray(&newArray_cafcLcLSRVector3D);
      instance.SetDelete(&delete_cafcLcLSRVector3D);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRVector3D);
      instance.SetDestructor(&destruct_cafcLcLSRVector3D);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRVector3D*)
   {
      return GenerateInitInstanceLocal((::caf::SRVector3D*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRVector3D*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRVector3D_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRVector3D*)nullptr)->GetClass();
      cafcLcLSRVector3D_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRVector3D_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRBeamBranch_Dictionary();
   static void cafcLcLSRBeamBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRBeamBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRBeamBranch(Long_t size, void *p);
   static void delete_cafcLcLSRBeamBranch(void *p);
   static void deleteArray_cafcLcLSRBeamBranch(void *p);
   static void destruct_cafcLcLSRBeamBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRBeamBranch*)
   {
      ::caf::SRBeamBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRBeamBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRBeamBranch", 10, "SRBeamBranch.h", 14,
                  typeid(::caf::SRBeamBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRBeamBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRBeamBranch) );
      instance.SetNew(&new_cafcLcLSRBeamBranch);
      instance.SetNewArray(&newArray_cafcLcLSRBeamBranch);
      instance.SetDelete(&delete_cafcLcLSRBeamBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRBeamBranch);
      instance.SetDestructor(&destruct_cafcLcLSRBeamBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRBeamBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRBeamBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRBeamBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRBeamBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRBeamBranch*)nullptr)->GetClass();
      cafcLcLSRBeamBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRBeamBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLTrueParticleID_Dictionary();
   static void cafcLcLTrueParticleID_TClassManip(TClass*);
   static void *new_cafcLcLTrueParticleID(void *p = nullptr);
   static void *newArray_cafcLcLTrueParticleID(Long_t size, void *p);
   static void delete_cafcLcLTrueParticleID(void *p);
   static void deleteArray_cafcLcLTrueParticleID(void *p);
   static void destruct_cafcLcLTrueParticleID(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::TrueParticleID*)
   {
      ::caf::TrueParticleID *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::TrueParticleID));
      static ::ROOT::TGenericClassInfo 
         instance("caf::TrueParticleID", 10, "SREnums.h", 94,
                  typeid(::caf::TrueParticleID), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLTrueParticleID_Dictionary, isa_proxy, 12,
                  sizeof(::caf::TrueParticleID) );
      instance.SetNew(&new_cafcLcLTrueParticleID);
      instance.SetNewArray(&newArray_cafcLcLTrueParticleID);
      instance.SetDelete(&delete_cafcLcLTrueParticleID);
      instance.SetDeleteArray(&deleteArray_cafcLcLTrueParticleID);
      instance.SetDestructor(&destruct_cafcLcLTrueParticleID);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::TrueParticleID*)
   {
      return GenerateInitInstanceLocal((::caf::TrueParticleID*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::TrueParticleID*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLTrueParticleID_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::TrueParticleID*)nullptr)->GetClass();
      cafcLcLTrueParticleID_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLTrueParticleID_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRDetectorMeta_Dictionary();
   static void cafcLcLSRDetectorMeta_TClassManip(TClass*);
   static void *new_cafcLcLSRDetectorMeta(void *p = nullptr);
   static void *newArray_cafcLcLSRDetectorMeta(Long_t size, void *p);
   static void delete_cafcLcLSRDetectorMeta(void *p);
   static void deleteArray_cafcLcLSRDetectorMeta(void *p);
   static void destruct_cafcLcLSRDetectorMeta(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRDetectorMeta*)
   {
      ::caf::SRDetectorMeta *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRDetectorMeta));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRDetectorMeta", 11, "SRMeta.h", 16,
                  typeid(::caf::SRDetectorMeta), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRDetectorMeta_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRDetectorMeta) );
      instance.SetNew(&new_cafcLcLSRDetectorMeta);
      instance.SetNewArray(&newArray_cafcLcLSRDetectorMeta);
      instance.SetDelete(&delete_cafcLcLSRDetectorMeta);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRDetectorMeta);
      instance.SetDestructor(&destruct_cafcLcLSRDetectorMeta);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRDetectorMeta*)
   {
      return GenerateInitInstanceLocal((::caf::SRDetectorMeta*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRDetectorMeta*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRDetectorMeta_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRDetectorMeta*)nullptr)->GetClass();
      cafcLcLSRDetectorMeta_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRDetectorMeta_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRDetectorMetaBranch_Dictionary();
   static void cafcLcLSRDetectorMetaBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRDetectorMetaBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRDetectorMetaBranch(Long_t size, void *p);
   static void delete_cafcLcLSRDetectorMetaBranch(void *p);
   static void deleteArray_cafcLcLSRDetectorMetaBranch(void *p);
   static void destruct_cafcLcLSRDetectorMetaBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRDetectorMetaBranch*)
   {
      ::caf::SRDetectorMetaBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRDetectorMetaBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRDetectorMetaBranch", 10, "SRDetectorMetaBranch.h", 12,
                  typeid(::caf::SRDetectorMetaBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRDetectorMetaBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRDetectorMetaBranch) );
      instance.SetNew(&new_cafcLcLSRDetectorMetaBranch);
      instance.SetNewArray(&newArray_cafcLcLSRDetectorMetaBranch);
      instance.SetDelete(&delete_cafcLcLSRDetectorMetaBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRDetectorMetaBranch);
      instance.SetDestructor(&destruct_cafcLcLSRDetectorMetaBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRDetectorMetaBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRDetectorMetaBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRDetectorMetaBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRDetectorMetaBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRDetectorMetaBranch*)nullptr)->GetClass();
      cafcLcLSRDetectorMetaBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRDetectorMetaBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRDirectionBranch_Dictionary();
   static void cafcLcLSRDirectionBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRDirectionBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRDirectionBranch(Long_t size, void *p);
   static void delete_cafcLcLSRDirectionBranch(void *p);
   static void deleteArray_cafcLcLSRDirectionBranch(void *p);
   static void destruct_cafcLcLSRDirectionBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRDirectionBranch*)
   {
      ::caf::SRDirectionBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRDirectionBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRDirectionBranch", 10, "SRDirectionBranch.h", 15,
                  typeid(::caf::SRDirectionBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRDirectionBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRDirectionBranch) );
      instance.SetNew(&new_cafcLcLSRDirectionBranch);
      instance.SetNewArray(&newArray_cafcLcLSRDirectionBranch);
      instance.SetDelete(&delete_cafcLcLSRDirectionBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRDirectionBranch);
      instance.SetDestructor(&destruct_cafcLcLSRDirectionBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRDirectionBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRDirectionBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRDirectionBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRDirectionBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRDirectionBranch*)nullptr)->GetClass();
      cafcLcLSRDirectionBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRDirectionBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNeutrinoEnergyBranch_Dictionary();
   static void cafcLcLSRNeutrinoEnergyBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRNeutrinoEnergyBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRNeutrinoEnergyBranch(Long_t size, void *p);
   static void delete_cafcLcLSRNeutrinoEnergyBranch(void *p);
   static void deleteArray_cafcLcLSRNeutrinoEnergyBranch(void *p);
   static void destruct_cafcLcLSRNeutrinoEnergyBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNeutrinoEnergyBranch*)
   {
      ::caf::SRNeutrinoEnergyBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNeutrinoEnergyBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNeutrinoEnergyBranch", 10, "SRNeutrinoEnergyBranch.h", 14,
                  typeid(::caf::SRNeutrinoEnergyBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNeutrinoEnergyBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNeutrinoEnergyBranch) );
      instance.SetNew(&new_cafcLcLSRNeutrinoEnergyBranch);
      instance.SetNewArray(&newArray_cafcLcLSRNeutrinoEnergyBranch);
      instance.SetDelete(&delete_cafcLcLSRNeutrinoEnergyBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNeutrinoEnergyBranch);
      instance.SetDestructor(&destruct_cafcLcLSRNeutrinoEnergyBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNeutrinoEnergyBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRNeutrinoEnergyBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNeutrinoEnergyBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNeutrinoEnergyBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNeutrinoEnergyBranch*)nullptr)->GetClass();
      cafcLcLSRNeutrinoEnergyBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNeutrinoEnergyBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRCVNScoreBranch_Dictionary();
   static void cafcLcLSRCVNScoreBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRCVNScoreBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRCVNScoreBranch(Long_t size, void *p);
   static void delete_cafcLcLSRCVNScoreBranch(void *p);
   static void deleteArray_cafcLcLSRCVNScoreBranch(void *p);
   static void destruct_cafcLcLSRCVNScoreBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRCVNScoreBranch*)
   {
      ::caf::SRCVNScoreBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRCVNScoreBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRCVNScoreBranch", 10, "SRCVNScoreBranch.h", 13,
                  typeid(::caf::SRCVNScoreBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRCVNScoreBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRCVNScoreBranch) );
      instance.SetNew(&new_cafcLcLSRCVNScoreBranch);
      instance.SetNewArray(&newArray_cafcLcLSRCVNScoreBranch);
      instance.SetDelete(&delete_cafcLcLSRCVNScoreBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRCVNScoreBranch);
      instance.SetDestructor(&destruct_cafcLcLSRCVNScoreBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRCVNScoreBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRCVNScoreBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRCVNScoreBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRCVNScoreBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRCVNScoreBranch*)nullptr)->GetClass();
      cafcLcLSRCVNScoreBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRCVNScoreBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNeutrinoHypothesisBranch_Dictionary();
   static void cafcLcLSRNeutrinoHypothesisBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRNeutrinoHypothesisBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRNeutrinoHypothesisBranch(Long_t size, void *p);
   static void delete_cafcLcLSRNeutrinoHypothesisBranch(void *p);
   static void deleteArray_cafcLcLSRNeutrinoHypothesisBranch(void *p);
   static void destruct_cafcLcLSRNeutrinoHypothesisBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNeutrinoHypothesisBranch*)
   {
      ::caf::SRNeutrinoHypothesisBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNeutrinoHypothesisBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNeutrinoHypothesisBranch", 10, "SRNeutrinoHypothesisBranch.h", 14,
                  typeid(::caf::SRNeutrinoHypothesisBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNeutrinoHypothesisBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNeutrinoHypothesisBranch) );
      instance.SetNew(&new_cafcLcLSRNeutrinoHypothesisBranch);
      instance.SetNewArray(&newArray_cafcLcLSRNeutrinoHypothesisBranch);
      instance.SetDelete(&delete_cafcLcLSRNeutrinoHypothesisBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNeutrinoHypothesisBranch);
      instance.SetDestructor(&destruct_cafcLcLSRNeutrinoHypothesisBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNeutrinoHypothesisBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRNeutrinoHypothesisBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNeutrinoHypothesisBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNeutrinoHypothesisBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNeutrinoHypothesisBranch*)nullptr)->GetClass();
      cafcLcLSRNeutrinoHypothesisBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNeutrinoHypothesisBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRLorentzVector_Dictionary();
   static void cafcLcLSRLorentzVector_TClassManip(TClass*);
   static void *new_cafcLcLSRLorentzVector(void *p = nullptr);
   static void *newArray_cafcLcLSRLorentzVector(Long_t size, void *p);
   static void delete_cafcLcLSRLorentzVector(void *p);
   static void deleteArray_cafcLcLSRLorentzVector(void *p);
   static void destruct_cafcLcLSRLorentzVector(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRLorentzVector*)
   {
      ::caf::SRLorentzVector *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRLorentzVector));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRLorentzVector", 10, "SRLorentzVector.h", 27,
                  typeid(::caf::SRLorentzVector), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRLorentzVector_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRLorentzVector) );
      instance.SetNew(&new_cafcLcLSRLorentzVector);
      instance.SetNewArray(&newArray_cafcLcLSRLorentzVector);
      instance.SetDelete(&delete_cafcLcLSRLorentzVector);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRLorentzVector);
      instance.SetDestructor(&destruct_cafcLcLSRLorentzVector);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRLorentzVector*)
   {
      return GenerateInitInstanceLocal((::caf::SRLorentzVector*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRLorentzVector*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRLorentzVector_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRLorentzVector*)nullptr)->GetClass();
      cafcLcLSRLorentzVector_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRLorentzVector_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRRecoParticle_Dictionary();
   static void cafcLcLSRRecoParticle_TClassManip(TClass*);
   static void *new_cafcLcLSRRecoParticle(void *p = nullptr);
   static void *newArray_cafcLcLSRRecoParticle(Long_t size, void *p);
   static void delete_cafcLcLSRRecoParticle(void *p);
   static void deleteArray_cafcLcLSRRecoParticle(void *p);
   static void destruct_cafcLcLSRRecoParticle(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRRecoParticle*)
   {
      ::caf::SRRecoParticle *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRRecoParticle));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRRecoParticle", 14, "SRRecoParticle.h", 17,
                  typeid(::caf::SRRecoParticle), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRRecoParticle_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRRecoParticle) );
      instance.SetNew(&new_cafcLcLSRRecoParticle);
      instance.SetNewArray(&newArray_cafcLcLSRRecoParticle);
      instance.SetDelete(&delete_cafcLcLSRRecoParticle);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRRecoParticle);
      instance.SetDestructor(&destruct_cafcLcLSRRecoParticle);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRRecoParticle*)
   {
      return GenerateInitInstanceLocal((::caf::SRRecoParticle*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRRecoParticle*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRRecoParticle_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRRecoParticle*)nullptr)->GetClass();
      cafcLcLSRRecoParticle_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRRecoParticle_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRRecoParticlesBranch_Dictionary();
   static void cafcLcLSRRecoParticlesBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRRecoParticlesBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRRecoParticlesBranch(Long_t size, void *p);
   static void delete_cafcLcLSRRecoParticlesBranch(void *p);
   static void deleteArray_cafcLcLSRRecoParticlesBranch(void *p);
   static void destruct_cafcLcLSRRecoParticlesBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRRecoParticlesBranch*)
   {
      ::caf::SRRecoParticlesBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRRecoParticlesBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRRecoParticlesBranch", 12, "SRRecoParticlesBranch.h", 16,
                  typeid(::caf::SRRecoParticlesBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRRecoParticlesBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRRecoParticlesBranch) );
      instance.SetNew(&new_cafcLcLSRRecoParticlesBranch);
      instance.SetNewArray(&newArray_cafcLcLSRRecoParticlesBranch);
      instance.SetDelete(&delete_cafcLcLSRRecoParticlesBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRRecoParticlesBranch);
      instance.SetDestructor(&destruct_cafcLcLSRRecoParticlesBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRRecoParticlesBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRRecoParticlesBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRRecoParticlesBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRRecoParticlesBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRRecoParticlesBranch*)nullptr)->GetClass();
      cafcLcLSRRecoParticlesBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRRecoParticlesBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRInteraction_Dictionary();
   static void cafcLcLSRInteraction_TClassManip(TClass*);
   static void *new_cafcLcLSRInteraction(void *p = nullptr);
   static void *newArray_cafcLcLSRInteraction(Long_t size, void *p);
   static void delete_cafcLcLSRInteraction(void *p);
   static void deleteArray_cafcLcLSRInteraction(void *p);
   static void destruct_cafcLcLSRInteraction(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRInteraction*)
   {
      ::caf::SRInteraction *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRInteraction));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRInteraction", 11, "SRInteraction.h", 18,
                  typeid(::caf::SRInteraction), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRInteraction_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRInteraction) );
      instance.SetNew(&new_cafcLcLSRInteraction);
      instance.SetNewArray(&newArray_cafcLcLSRInteraction);
      instance.SetDelete(&delete_cafcLcLSRInteraction);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRInteraction);
      instance.SetDestructor(&destruct_cafcLcLSRInteraction);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRInteraction*)
   {
      return GenerateInitInstanceLocal((::caf::SRInteraction*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRInteraction*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRInteraction_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRInteraction*)nullptr)->GetClass();
      cafcLcLSRInteraction_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRInteraction_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRInteractionBranch_Dictionary();
   static void cafcLcLSRInteractionBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRInteractionBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRInteractionBranch(Long_t size, void *p);
   static void delete_cafcLcLSRInteractionBranch(void *p);
   static void deleteArray_cafcLcLSRInteractionBranch(void *p);
   static void destruct_cafcLcLSRInteractionBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRInteractionBranch*)
   {
      ::caf::SRInteractionBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRInteractionBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRInteractionBranch", 11, "SRInteractionBranch.h", 15,
                  typeid(::caf::SRInteractionBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRInteractionBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRInteractionBranch) );
      instance.SetNew(&new_cafcLcLSRInteractionBranch);
      instance.SetNewArray(&newArray_cafcLcLSRInteractionBranch);
      instance.SetDelete(&delete_cafcLcLSRInteractionBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRInteractionBranch);
      instance.SetDestructor(&destruct_cafcLcLSRInteractionBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRInteractionBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRInteractionBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRInteractionBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRInteractionBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRInteractionBranch*)nullptr)->GetClass();
      cafcLcLSRInteractionBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRInteractionBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRCommonRecoBranch_Dictionary();
   static void cafcLcLSRCommonRecoBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRCommonRecoBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRCommonRecoBranch(Long_t size, void *p);
   static void delete_cafcLcLSRCommonRecoBranch(void *p);
   static void deleteArray_cafcLcLSRCommonRecoBranch(void *p);
   static void destruct_cafcLcLSRCommonRecoBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRCommonRecoBranch*)
   {
      ::caf::SRCommonRecoBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRCommonRecoBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRCommonRecoBranch", 12, "SRCommonRecoBranch.h", 16,
                  typeid(::caf::SRCommonRecoBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRCommonRecoBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRCommonRecoBranch) );
      instance.SetNew(&new_cafcLcLSRCommonRecoBranch);
      instance.SetNewArray(&newArray_cafcLcLSRCommonRecoBranch);
      instance.SetDelete(&delete_cafcLcLSRCommonRecoBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRCommonRecoBranch);
      instance.SetDestructor(&destruct_cafcLcLSRCommonRecoBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRCommonRecoBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRCommonRecoBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRCommonRecoBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRCommonRecoBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRCommonRecoBranch*)nullptr)->GetClass();
      cafcLcLSRCommonRecoBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRCommonRecoBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRTrueParticle_Dictionary();
   static void cafcLcLSRTrueParticle_TClassManip(TClass*);
   static void *new_cafcLcLSRTrueParticle(void *p = nullptr);
   static void *newArray_cafcLcLSRTrueParticle(Long_t size, void *p);
   static void delete_cafcLcLSRTrueParticle(void *p);
   static void deleteArray_cafcLcLSRTrueParticle(void *p);
   static void destruct_cafcLcLSRTrueParticle(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRTrueParticle*)
   {
      ::caf::SRTrueParticle *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRTrueParticle));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRTrueParticle", 15, "SRTrueParticle.h", 21,
                  typeid(::caf::SRTrueParticle), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRTrueParticle_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRTrueParticle) );
      instance.SetNew(&new_cafcLcLSRTrueParticle);
      instance.SetNewArray(&newArray_cafcLcLSRTrueParticle);
      instance.SetDelete(&delete_cafcLcLSRTrueParticle);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRTrueParticle);
      instance.SetDestructor(&destruct_cafcLcLSRTrueParticle);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRTrueParticle*)
   {
      return GenerateInitInstanceLocal((::caf::SRTrueParticle*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRTrueParticle*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRTrueParticle_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRTrueParticle*)nullptr)->GetClass();
      cafcLcLSRTrueParticle_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRTrueParticle_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRShower_Dictionary();
   static void cafcLcLSRShower_TClassManip(TClass*);
   static void *new_cafcLcLSRShower(void *p = nullptr);
   static void *newArray_cafcLcLSRShower(Long_t size, void *p);
   static void delete_cafcLcLSRShower(void *p);
   static void deleteArray_cafcLcLSRShower(void *p);
   static void destruct_cafcLcLSRShower(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRShower*)
   {
      ::caf::SRShower *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRShower));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRShower", 15, "SRShower.h", 16,
                  typeid(::caf::SRShower), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRShower_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRShower) );
      instance.SetNew(&new_cafcLcLSRShower);
      instance.SetNewArray(&newArray_cafcLcLSRShower);
      instance.SetDelete(&delete_cafcLcLSRShower);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRShower);
      instance.SetDestructor(&destruct_cafcLcLSRShower);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRShower*)
   {
      return GenerateInitInstanceLocal((::caf::SRShower*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRShower*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRShower_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRShower*)nullptr)->GetClass();
      cafcLcLSRShower_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRShower_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRTrack_Dictionary();
   static void cafcLcLSRTrack_TClassManip(TClass*);
   static void *new_cafcLcLSRTrack(void *p = nullptr);
   static void *newArray_cafcLcLSRTrack(Long_t size, void *p);
   static void delete_cafcLcLSRTrack(void *p);
   static void deleteArray_cafcLcLSRTrack(void *p);
   static void destruct_cafcLcLSRTrack(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRTrack*)
   {
      ::caf::SRTrack *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRTrack));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRTrack", 18, "SRTrack.h", 16,
                  typeid(::caf::SRTrack), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRTrack_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRTrack) );
      instance.SetNew(&new_cafcLcLSRTrack);
      instance.SetNewArray(&newArray_cafcLcLSRTrack);
      instance.SetDelete(&delete_cafcLcLSRTrack);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRTrack);
      instance.SetDestructor(&destruct_cafcLcLSRTrack);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRTrack*)
   {
      return GenerateInitInstanceLocal((::caf::SRTrack*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRTrack*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRTrack_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRTrack*)nullptr)->GetClass();
      cafcLcLSRTrack_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRTrack_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRFDInt_Dictionary();
   static void cafcLcLSRFDInt_TClassManip(TClass*);
   static void *new_cafcLcLSRFDInt(void *p = nullptr);
   static void *newArray_cafcLcLSRFDInt(Long_t size, void *p);
   static void delete_cafcLcLSRFDInt(void *p);
   static void deleteArray_cafcLcLSRFDInt(void *p);
   static void destruct_cafcLcLSRFDInt(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRFDInt*)
   {
      ::caf::SRFDInt *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRFDInt));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRFDInt", 10, "SRFD.h", 17,
                  typeid(::caf::SRFDInt), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRFDInt_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRFDInt) );
      instance.SetNew(&new_cafcLcLSRFDInt);
      instance.SetNewArray(&newArray_cafcLcLSRFDInt);
      instance.SetDelete(&delete_cafcLcLSRFDInt);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRFDInt);
      instance.SetDestructor(&destruct_cafcLcLSRFDInt);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRFDInt*)
   {
      return GenerateInitInstanceLocal((::caf::SRFDInt*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRFDInt*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRFDInt_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRFDInt*)nullptr)->GetClass();
      cafcLcLSRFDInt_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRFDInt_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRFD_Dictionary();
   static void cafcLcLSRFD_TClassManip(TClass*);
   static void *new_cafcLcLSRFD(void *p = nullptr);
   static void *newArray_cafcLcLSRFD(Long_t size, void *p);
   static void delete_cafcLcLSRFD(void *p);
   static void deleteArray_cafcLcLSRFD(void *p);
   static void destruct_cafcLcLSRFD(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRFD*)
   {
      ::caf::SRFD *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRFD));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRFD", 15, "SRFD.h", 37,
                  typeid(::caf::SRFD), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRFD_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRFD) );
      instance.SetNew(&new_cafcLcLSRFD);
      instance.SetNewArray(&newArray_cafcLcLSRFD);
      instance.SetDelete(&delete_cafcLcLSRFD);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRFD);
      instance.SetDestructor(&destruct_cafcLcLSRFD);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRFD*)
   {
      return GenerateInitInstanceLocal((::caf::SRFD*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRFD*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRFD_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRFD*)nullptr)->GetClass();
      cafcLcLSRFD_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRFD_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRFDBranch_Dictionary();
   static void cafcLcLSRFDBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRFDBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRFDBranch(Long_t size, void *p);
   static void delete_cafcLcLSRFDBranch(void *p);
   static void deleteArray_cafcLcLSRFDBranch(void *p);
   static void destruct_cafcLcLSRFDBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRFDBranch*)
   {
      ::caf::SRFDBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRFDBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRFDBranch", 13, "SRFDBranch.h", 16,
                  typeid(::caf::SRFDBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRFDBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRFDBranch) );
      instance.SetNew(&new_cafcLcLSRFDBranch);
      instance.SetNewArray(&newArray_cafcLcLSRFDBranch);
      instance.SetDelete(&delete_cafcLcLSRFDBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRFDBranch);
      instance.SetDestructor(&destruct_cafcLcLSRFDBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRFDBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRFDBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRFDBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRFDBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRFDBranch*)nullptr)->GetClass();
      cafcLcLSRFDBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRFDBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGArParticle_Dictionary();
   static void cafcLcLSRGArParticle_TClassManip(TClass*);
   static void *new_cafcLcLSRGArParticle(void *p = nullptr);
   static void *newArray_cafcLcLSRGArParticle(Long_t size, void *p);
   static void delete_cafcLcLSRGArParticle(void *p);
   static void deleteArray_cafcLcLSRGArParticle(void *p);
   static void destruct_cafcLcLSRGArParticle(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGArParticle*)
   {
      ::caf::SRGArParticle *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGArParticle));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGArParticle", 11, "SRGArParticle.h", 14,
                  typeid(::caf::SRGArParticle), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGArParticle_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGArParticle) );
      instance.SetNew(&new_cafcLcLSRGArParticle);
      instance.SetNewArray(&newArray_cafcLcLSRGArParticle);
      instance.SetDelete(&delete_cafcLcLSRGArParticle);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGArParticle);
      instance.SetDestructor(&destruct_cafcLcLSRGArParticle);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGArParticle*)
   {
      return GenerateInitInstanceLocal((::caf::SRGArParticle*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGArParticle*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGArParticle_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGArParticle*)nullptr)->GetClass();
      cafcLcLSRGArParticle_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGArParticle_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGArTrack_Dictionary();
   static void cafcLcLSRGArTrack_TClassManip(TClass*);
   static void *new_cafcLcLSRGArTrack(void *p = nullptr);
   static void *newArray_cafcLcLSRGArTrack(Long_t size, void *p);
   static void delete_cafcLcLSRGArTrack(void *p);
   static void deleteArray_cafcLcLSRGArTrack(void *p);
   static void destruct_cafcLcLSRGArTrack(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGArTrack*)
   {
      ::caf::SRGArTrack *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGArTrack));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGArTrack", 15, "SRGArTrack.h", 14,
                  typeid(::caf::SRGArTrack), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGArTrack_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGArTrack) );
      instance.SetNew(&new_cafcLcLSRGArTrack);
      instance.SetNewArray(&newArray_cafcLcLSRGArTrack);
      instance.SetDelete(&delete_cafcLcLSRGArTrack);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGArTrack);
      instance.SetDestructor(&destruct_cafcLcLSRGArTrack);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGArTrack*)
   {
      return GenerateInitInstanceLocal((::caf::SRGArTrack*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGArTrack*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGArTrack_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGArTrack*)nullptr)->GetClass();
      cafcLcLSRGArTrack_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGArTrack_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGArECAL_Dictionary();
   static void cafcLcLSRGArECAL_TClassManip(TClass*);
   static void *new_cafcLcLSRGArECAL(void *p = nullptr);
   static void *newArray_cafcLcLSRGArECAL(Long_t size, void *p);
   static void delete_cafcLcLSRGArECAL(void *p);
   static void deleteArray_cafcLcLSRGArECAL(void *p);
   static void destruct_cafcLcLSRGArECAL(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGArECAL*)
   {
      ::caf::SRGArECAL *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGArECAL));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGArECAL", 12, "SRGArECAL.h", 16,
                  typeid(::caf::SRGArECAL), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGArECAL_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGArECAL) );
      instance.SetNew(&new_cafcLcLSRGArECAL);
      instance.SetNewArray(&newArray_cafcLcLSRGArECAL);
      instance.SetDelete(&delete_cafcLcLSRGArECAL);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGArECAL);
      instance.SetDestructor(&destruct_cafcLcLSRGArECAL);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGArECAL*)
   {
      return GenerateInitInstanceLocal((::caf::SRGArECAL*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGArECAL*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGArECAL_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGArECAL*)nullptr)->GetClass();
      cafcLcLSRGArECAL_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGArECAL_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGArInt_Dictionary();
   static void cafcLcLSRGArInt_TClassManip(TClass*);
   static void *new_cafcLcLSRGArInt(void *p = nullptr);
   static void *newArray_cafcLcLSRGArInt(Long_t size, void *p);
   static void delete_cafcLcLSRGArInt(void *p);
   static void deleteArray_cafcLcLSRGArInt(void *p);
   static void destruct_cafcLcLSRGArInt(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGArInt*)
   {
      ::caf::SRGArInt *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGArInt));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGArInt", 11, "SRGAr.h", 17,
                  typeid(::caf::SRGArInt), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGArInt_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGArInt) );
      instance.SetNew(&new_cafcLcLSRGArInt);
      instance.SetNewArray(&newArray_cafcLcLSRGArInt);
      instance.SetDelete(&delete_cafcLcLSRGArInt);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGArInt);
      instance.SetDestructor(&destruct_cafcLcLSRGArInt);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGArInt*)
   {
      return GenerateInitInstanceLocal((::caf::SRGArInt*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGArInt*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGArInt_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGArInt*)nullptr)->GetClass();
      cafcLcLSRGArInt_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGArInt_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGArID_Dictionary();
   static void cafcLcLSRGArID_TClassManip(TClass*);
   static void *new_cafcLcLSRGArID(void *p = nullptr);
   static void *newArray_cafcLcLSRGArID(Long_t size, void *p);
   static void delete_cafcLcLSRGArID(void *p);
   static void deleteArray_cafcLcLSRGArID(void *p);
   static void destruct_cafcLcLSRGArID(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGArID*)
   {
      ::caf::SRGArID *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGArID));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGArID", 10, "SRGAr.h", 45,
                  typeid(::caf::SRGArID), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGArID_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGArID) );
      instance.SetNew(&new_cafcLcLSRGArID);
      instance.SetNewArray(&newArray_cafcLcLSRGArID);
      instance.SetDelete(&delete_cafcLcLSRGArID);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGArID);
      instance.SetDestructor(&destruct_cafcLcLSRGArID);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGArID*)
   {
      return GenerateInitInstanceLocal((::caf::SRGArID*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGArID*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGArID_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGArID*)nullptr)->GetClass();
      cafcLcLSRGArID_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGArID_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGAr_Dictionary();
   static void cafcLcLSRGAr_TClassManip(TClass*);
   static void *new_cafcLcLSRGAr(void *p = nullptr);
   static void *newArray_cafcLcLSRGAr(Long_t size, void *p);
   static void delete_cafcLcLSRGAr(void *p);
   static void deleteArray_cafcLcLSRGAr(void *p);
   static void destruct_cafcLcLSRGAr(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGAr*)
   {
      ::caf::SRGAr *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGAr));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGAr", 11, "SRGAr.h", 54,
                  typeid(::caf::SRGAr), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGAr_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGAr) );
      instance.SetNew(&new_cafcLcLSRGAr);
      instance.SetNewArray(&newArray_cafcLcLSRGAr);
      instance.SetDelete(&delete_cafcLcLSRGAr);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGAr);
      instance.SetDestructor(&destruct_cafcLcLSRGAr);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGAr*)
   {
      return GenerateInitInstanceLocal((::caf::SRGAr*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGAr*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGAr_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGAr*)nullptr)->GetClass();
      cafcLcLSRGAr_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGAr_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDLArInt_Dictionary();
   static void cafcLcLSRNDLArInt_TClassManip(TClass*);
   static void *new_cafcLcLSRNDLArInt(void *p = nullptr);
   static void *newArray_cafcLcLSRNDLArInt(Long_t size, void *p);
   static void delete_cafcLcLSRNDLArInt(void *p);
   static void deleteArray_cafcLcLSRNDLArInt(void *p);
   static void destruct_cafcLcLSRNDLArInt(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDLArInt*)
   {
      ::caf::SRNDLArInt *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDLArInt));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDLArInt", 10, "SRNDLAr.h", 16,
                  typeid(::caf::SRNDLArInt), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDLArInt_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDLArInt) );
      instance.SetNew(&new_cafcLcLSRNDLArInt);
      instance.SetNewArray(&newArray_cafcLcLSRNDLArInt);
      instance.SetDelete(&delete_cafcLcLSRNDLArInt);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDLArInt);
      instance.SetDestructor(&destruct_cafcLcLSRNDLArInt);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDLArInt*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDLArInt*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDLArInt*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDLArInt_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDLArInt*)nullptr)->GetClass();
      cafcLcLSRNDLArInt_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDLArInt_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDLArID_Dictionary();
   static void cafcLcLSRNDLArID_TClassManip(TClass*);
   static void *new_cafcLcLSRNDLArID(void *p = nullptr);
   static void *newArray_cafcLcLSRNDLArID(Long_t size, void *p);
   static void delete_cafcLcLSRNDLArID(void *p);
   static void deleteArray_cafcLcLSRNDLArID(void *p);
   static void destruct_cafcLcLSRNDLArID(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDLArID*)
   {
      ::caf::SRNDLArID *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDLArID));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDLArID", 10, "SRNDLAr.h", 27,
                  typeid(::caf::SRNDLArID), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDLArID_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDLArID) );
      instance.SetNew(&new_cafcLcLSRNDLArID);
      instance.SetNewArray(&newArray_cafcLcLSRNDLArID);
      instance.SetDelete(&delete_cafcLcLSRNDLArID);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDLArID);
      instance.SetDestructor(&destruct_cafcLcLSRNDLArID);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDLArID*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDLArID*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDLArID*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDLArID_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDLArID*)nullptr)->GetClass();
      cafcLcLSRNDLArID_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDLArID_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDLAr_Dictionary();
   static void cafcLcLSRNDLAr_TClassManip(TClass*);
   static void *new_cafcLcLSRNDLAr(void *p = nullptr);
   static void *newArray_cafcLcLSRNDLAr(Long_t size, void *p);
   static void delete_cafcLcLSRNDLAr(void *p);
   static void deleteArray_cafcLcLSRNDLAr(void *p);
   static void destruct_cafcLcLSRNDLAr(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDLAr*)
   {
      ::caf::SRNDLAr *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDLAr));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDLAr", 11, "SRNDLAr.h", 36,
                  typeid(::caf::SRNDLAr), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDLAr_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDLAr) );
      instance.SetNew(&new_cafcLcLSRNDLAr);
      instance.SetNewArray(&newArray_cafcLcLSRNDLAr);
      instance.SetDelete(&delete_cafcLcLSRNDLAr);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDLAr);
      instance.SetDestructor(&destruct_cafcLcLSRNDLAr);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDLAr*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDLAr*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDLAr*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDLAr_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDLAr*)nullptr)->GetClass();
      cafcLcLSRNDLAr_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDLAr_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRMINERvAInt_Dictionary();
   static void cafcLcLSRMINERvAInt_TClassManip(TClass*);
   static void *new_cafcLcLSRMINERvAInt(void *p = nullptr);
   static void *newArray_cafcLcLSRMINERvAInt(Long_t size, void *p);
   static void delete_cafcLcLSRMINERvAInt(void *p);
   static void deleteArray_cafcLcLSRMINERvAInt(void *p);
   static void destruct_cafcLcLSRMINERvAInt(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRMINERvAInt*)
   {
      ::caf::SRMINERvAInt *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRMINERvAInt));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRMINERvAInt", 10, "SRMINERvA.h", 18,
                  typeid(::caf::SRMINERvAInt), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRMINERvAInt_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRMINERvAInt) );
      instance.SetNew(&new_cafcLcLSRMINERvAInt);
      instance.SetNewArray(&newArray_cafcLcLSRMINERvAInt);
      instance.SetDelete(&delete_cafcLcLSRMINERvAInt);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRMINERvAInt);
      instance.SetDestructor(&destruct_cafcLcLSRMINERvAInt);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRMINERvAInt*)
   {
      return GenerateInitInstanceLocal((::caf::SRMINERvAInt*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRMINERvAInt*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRMINERvAInt_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRMINERvAInt*)nullptr)->GetClass();
      cafcLcLSRMINERvAInt_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRMINERvAInt_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRMINERvA_Dictionary();
   static void cafcLcLSRMINERvA_TClassManip(TClass*);
   static void *new_cafcLcLSRMINERvA(void *p = nullptr);
   static void *newArray_cafcLcLSRMINERvA(Long_t size, void *p);
   static void delete_cafcLcLSRMINERvA(void *p);
   static void deleteArray_cafcLcLSRMINERvA(void *p);
   static void destruct_cafcLcLSRMINERvA(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRMINERvA*)
   {
      ::caf::SRMINERvA *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRMINERvA));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRMINERvA", 10, "SRMINERvA.h", 37,
                  typeid(::caf::SRMINERvA), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRMINERvA_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRMINERvA) );
      instance.SetNew(&new_cafcLcLSRMINERvA);
      instance.SetNewArray(&newArray_cafcLcLSRMINERvA);
      instance.SetDelete(&delete_cafcLcLSRMINERvA);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRMINERvA);
      instance.SetDestructor(&destruct_cafcLcLSRMINERvA);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRMINERvA*)
   {
      return GenerateInitInstanceLocal((::caf::SRMINERvA*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRMINERvA*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRMINERvA_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRMINERvA*)nullptr)->GetClass();
      cafcLcLSRMINERvA_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRMINERvA_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRTMSInt_Dictionary();
   static void cafcLcLSRTMSInt_TClassManip(TClass*);
   static void *new_cafcLcLSRTMSInt(void *p = nullptr);
   static void *newArray_cafcLcLSRTMSInt(Long_t size, void *p);
   static void delete_cafcLcLSRTMSInt(void *p);
   static void deleteArray_cafcLcLSRTMSInt(void *p);
   static void destruct_cafcLcLSRTMSInt(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRTMSInt*)
   {
      ::caf::SRTMSInt *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRTMSInt));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRTMSInt", 10, "SRTMS.h", 12,
                  typeid(::caf::SRTMSInt), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRTMSInt_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRTMSInt) );
      instance.SetNew(&new_cafcLcLSRTMSInt);
      instance.SetNewArray(&newArray_cafcLcLSRTMSInt);
      instance.SetDelete(&delete_cafcLcLSRTMSInt);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRTMSInt);
      instance.SetDestructor(&destruct_cafcLcLSRTMSInt);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRTMSInt*)
   {
      return GenerateInitInstanceLocal((::caf::SRTMSInt*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRTMSInt*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRTMSInt_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRTMSInt*)nullptr)->GetClass();
      cafcLcLSRTMSInt_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRTMSInt_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRTMSID_Dictionary();
   static void cafcLcLSRTMSID_TClassManip(TClass*);
   static void *new_cafcLcLSRTMSID(void *p = nullptr);
   static void *newArray_cafcLcLSRTMSID(Long_t size, void *p);
   static void delete_cafcLcLSRTMSID(void *p);
   static void deleteArray_cafcLcLSRTMSID(void *p);
   static void destruct_cafcLcLSRTMSID(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRTMSID*)
   {
      ::caf::SRTMSID *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRTMSID));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRTMSID", 10, "SRTMS.h", 20,
                  typeid(::caf::SRTMSID), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRTMSID_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRTMSID) );
      instance.SetNew(&new_cafcLcLSRTMSID);
      instance.SetNewArray(&newArray_cafcLcLSRTMSID);
      instance.SetDelete(&delete_cafcLcLSRTMSID);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRTMSID);
      instance.SetDestructor(&destruct_cafcLcLSRTMSID);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRTMSID*)
   {
      return GenerateInitInstanceLocal((::caf::SRTMSID*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRTMSID*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRTMSID_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRTMSID*)nullptr)->GetClass();
      cafcLcLSRTMSID_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRTMSID_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRTMS_Dictionary();
   static void cafcLcLSRTMS_TClassManip(TClass*);
   static void *new_cafcLcLSRTMS(void *p = nullptr);
   static void *newArray_cafcLcLSRTMS(Long_t size, void *p);
   static void delete_cafcLcLSRTMS(void *p);
   static void deleteArray_cafcLcLSRTMS(void *p);
   static void destruct_cafcLcLSRTMS(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRTMS*)
   {
      ::caf::SRTMS *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRTMS));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRTMS", 11, "SRTMS.h", 27,
                  typeid(::caf::SRTMS), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRTMS_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRTMS) );
      instance.SetNew(&new_cafcLcLSRTMS);
      instance.SetNewArray(&newArray_cafcLcLSRTMS);
      instance.SetDelete(&delete_cafcLcLSRTMS);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRTMS);
      instance.SetDestructor(&destruct_cafcLcLSRTMS);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRTMS*)
   {
      return GenerateInitInstanceLocal((::caf::SRTMS*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRTMS*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRTMS_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRTMS*)nullptr)->GetClass();
      cafcLcLSRTMS_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRTMS_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDShowerAssn_Dictionary();
   static void cafcLcLSRNDShowerAssn_TClassManip(TClass*);
   static void *new_cafcLcLSRNDShowerAssn(void *p = nullptr);
   static void *newArray_cafcLcLSRNDShowerAssn(Long_t size, void *p);
   static void delete_cafcLcLSRNDShowerAssn(void *p);
   static void deleteArray_cafcLcLSRNDShowerAssn(void *p);
   static void destruct_cafcLcLSRNDShowerAssn(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDShowerAssn*)
   {
      ::caf::SRNDShowerAssn *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDShowerAssn));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDShowerAssn", 10, "SRNDShowerAssn.h", 14,
                  typeid(::caf::SRNDShowerAssn), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDShowerAssn_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDShowerAssn) );
      instance.SetNew(&new_cafcLcLSRNDShowerAssn);
      instance.SetNewArray(&newArray_cafcLcLSRNDShowerAssn);
      instance.SetDelete(&delete_cafcLcLSRNDShowerAssn);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDShowerAssn);
      instance.SetDestructor(&destruct_cafcLcLSRNDShowerAssn);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDShowerAssn*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDShowerAssn*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDShowerAssn*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDShowerAssn_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDShowerAssn*)nullptr)->GetClass();
      cafcLcLSRNDShowerAssn_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDShowerAssn_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDTrackAssn_Dictionary();
   static void cafcLcLSRNDTrackAssn_TClassManip(TClass*);
   static void *new_cafcLcLSRNDTrackAssn(void *p = nullptr);
   static void *newArray_cafcLcLSRNDTrackAssn(Long_t size, void *p);
   static void delete_cafcLcLSRNDTrackAssn(void *p);
   static void deleteArray_cafcLcLSRNDTrackAssn(void *p);
   static void destruct_cafcLcLSRNDTrackAssn(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDTrackAssn*)
   {
      ::caf::SRNDTrackAssn *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDTrackAssn));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDTrackAssn", 13, "SRNDTrackAssn.h", 14,
                  typeid(::caf::SRNDTrackAssn), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDTrackAssn_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDTrackAssn) );
      instance.SetNew(&new_cafcLcLSRNDTrackAssn);
      instance.SetNewArray(&newArray_cafcLcLSRNDTrackAssn);
      instance.SetDelete(&delete_cafcLcLSRNDTrackAssn);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDTrackAssn);
      instance.SetDestructor(&destruct_cafcLcLSRNDTrackAssn);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDTrackAssn*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDTrackAssn*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDTrackAssn*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDTrackAssn_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDTrackAssn*)nullptr)->GetClass();
      cafcLcLSRNDTrackAssn_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDTrackAssn_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDTrkAssnBranch_Dictionary();
   static void cafcLcLSRNDTrkAssnBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRNDTrkAssnBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRNDTrkAssnBranch(Long_t size, void *p);
   static void delete_cafcLcLSRNDTrkAssnBranch(void *p);
   static void deleteArray_cafcLcLSRNDTrkAssnBranch(void *p);
   static void destruct_cafcLcLSRNDTrkAssnBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDTrkAssnBranch*)
   {
      ::caf::SRNDTrkAssnBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDTrkAssnBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDTrkAssnBranch", 10, "SRNDAssnBranch.h", 15,
                  typeid(::caf::SRNDTrkAssnBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDTrkAssnBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDTrkAssnBranch) );
      instance.SetNew(&new_cafcLcLSRNDTrkAssnBranch);
      instance.SetNewArray(&newArray_cafcLcLSRNDTrkAssnBranch);
      instance.SetDelete(&delete_cafcLcLSRNDTrkAssnBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDTrkAssnBranch);
      instance.SetDestructor(&destruct_cafcLcLSRNDTrkAssnBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDTrkAssnBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDTrkAssnBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDTrkAssnBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDTrkAssnBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDTrkAssnBranch*)nullptr)->GetClass();
      cafcLcLSRNDTrkAssnBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDTrkAssnBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDShwAssnBranch_Dictionary();
   static void cafcLcLSRNDShwAssnBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRNDShwAssnBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRNDShwAssnBranch(Long_t size, void *p);
   static void delete_cafcLcLSRNDShwAssnBranch(void *p);
   static void deleteArray_cafcLcLSRNDShwAssnBranch(void *p);
   static void destruct_cafcLcLSRNDShwAssnBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDShwAssnBranch*)
   {
      ::caf::SRNDShwAssnBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDShwAssnBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDShwAssnBranch", 10, "SRNDAssnBranch.h", 22,
                  typeid(::caf::SRNDShwAssnBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDShwAssnBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDShwAssnBranch) );
      instance.SetNew(&new_cafcLcLSRNDShwAssnBranch);
      instance.SetNewArray(&newArray_cafcLcLSRNDShwAssnBranch);
      instance.SetDelete(&delete_cafcLcLSRNDShwAssnBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDShwAssnBranch);
      instance.SetDestructor(&destruct_cafcLcLSRNDShwAssnBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDShwAssnBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDShwAssnBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDShwAssnBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDShwAssnBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDShwAssnBranch*)nullptr)->GetClass();
      cafcLcLSRNDShwAssnBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDShwAssnBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRSAND_Dictionary();
   static void cafcLcLSRSAND_TClassManip(TClass*);
   static void *new_cafcLcLSRSAND(void *p = nullptr);
   static void *newArray_cafcLcLSRSAND(Long_t size, void *p);
   static void delete_cafcLcLSRSAND(void *p);
   static void deleteArray_cafcLcLSRSAND(void *p);
   static void destruct_cafcLcLSRSAND(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRSAND*)
   {
      ::caf::SRSAND *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRSAND));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRSAND", 14, "SRSAND.h", 29,
                  typeid(::caf::SRSAND), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRSAND_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRSAND) );
      instance.SetNew(&new_cafcLcLSRSAND);
      instance.SetNewArray(&newArray_cafcLcLSRSAND);
      instance.SetDelete(&delete_cafcLcLSRSAND);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRSAND);
      instance.SetDestructor(&destruct_cafcLcLSRSAND);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRSAND*)
   {
      return GenerateInitInstanceLocal((::caf::SRSAND*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRSAND*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRSAND_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRSAND*)nullptr)->GetClass();
      cafcLcLSRSAND_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRSAND_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDBranch_Dictionary();
   static void cafcLcLSRNDBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRNDBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRNDBranch(Long_t size, void *p);
   static void delete_cafcLcLSRNDBranch(void *p);
   static void deleteArray_cafcLcLSRNDBranch(void *p);
   static void destruct_cafcLcLSRNDBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDBranch*)
   {
      ::caf::SRNDBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDBranch", 15, "SRNDBranch.h", 20,
                  typeid(::caf::SRNDBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDBranch) );
      instance.SetNew(&new_cafcLcLSRNDBranch);
      instance.SetNewArray(&newArray_cafcLcLSRNDBranch);
      instance.SetDelete(&delete_cafcLcLSRNDBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDBranch);
      instance.SetDestructor(&destruct_cafcLcLSRNDBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDBranch*)nullptr)->GetClass();
      cafcLcLSRNDBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRTrueInteraction_Dictionary();
   static void cafcLcLSRTrueInteraction_TClassManip(TClass*);
   static void *new_cafcLcLSRTrueInteraction(void *p = nullptr);
   static void *newArray_cafcLcLSRTrueInteraction(Long_t size, void *p);
   static void delete_cafcLcLSRTrueInteraction(void *p);
   static void deleteArray_cafcLcLSRTrueInteraction(void *p);
   static void destruct_cafcLcLSRTrueInteraction(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRTrueInteraction*)
   {
      ::caf::SRTrueInteraction *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRTrueInteraction));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRTrueInteraction", 17, "SRTrueInteraction.h", 39,
                  typeid(::caf::SRTrueInteraction), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRTrueInteraction_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRTrueInteraction) );
      instance.SetNew(&new_cafcLcLSRTrueInteraction);
      instance.SetNewArray(&newArray_cafcLcLSRTrueInteraction);
      instance.SetDelete(&delete_cafcLcLSRTrueInteraction);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRTrueInteraction);
      instance.SetDestructor(&destruct_cafcLcLSRTrueInteraction);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRTrueInteraction*)
   {
      return GenerateInitInstanceLocal((::caf::SRTrueInteraction*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRTrueInteraction*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRTrueInteraction_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRTrueInteraction*)nullptr)->GetClass();
      cafcLcLSRTrueInteraction_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRTrueInteraction_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRTruthBranch_Dictionary();
   static void cafcLcLSRTruthBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRTruthBranch(void *p = nullptr);
   static void *newArray_cafcLcLSRTruthBranch(Long_t size, void *p);
   static void delete_cafcLcLSRTruthBranch(void *p);
   static void deleteArray_cafcLcLSRTruthBranch(void *p);
   static void destruct_cafcLcLSRTruthBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRTruthBranch*)
   {
      ::caf::SRTruthBranch *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRTruthBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRTruthBranch", 10, "SRTruthBranch.h", 16,
                  typeid(::caf::SRTruthBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRTruthBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRTruthBranch) );
      instance.SetNew(&new_cafcLcLSRTruthBranch);
      instance.SetNewArray(&newArray_cafcLcLSRTruthBranch);
      instance.SetDelete(&delete_cafcLcLSRTruthBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRTruthBranch);
      instance.SetDestructor(&destruct_cafcLcLSRTruthBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRTruthBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRTruthBranch*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRTruthBranch*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRTruthBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRTruthBranch*)nullptr)->GetClass();
      cafcLcLSRTruthBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRTruthBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLStandardRecord_Dictionary();
   static void cafcLcLStandardRecord_TClassManip(TClass*);
   static void *new_cafcLcLStandardRecord(void *p = nullptr);
   static void *newArray_cafcLcLStandardRecord(Long_t size, void *p);
   static void delete_cafcLcLStandardRecord(void *p);
   static void deleteArray_cafcLcLStandardRecord(void *p);
   static void destruct_cafcLcLStandardRecord(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::StandardRecord*)
   {
      ::caf::StandardRecord *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::StandardRecord));
      static ::ROOT::TGenericClassInfo 
         instance("caf::StandardRecord", 15, "StandardRecord.h", 24,
                  typeid(::caf::StandardRecord), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLStandardRecord_Dictionary, isa_proxy, 12,
                  sizeof(::caf::StandardRecord) );
      instance.SetNew(&new_cafcLcLStandardRecord);
      instance.SetNewArray(&newArray_cafcLcLStandardRecord);
      instance.SetDelete(&delete_cafcLcLStandardRecord);
      instance.SetDeleteArray(&deleteArray_cafcLcLStandardRecord);
      instance.SetDestructor(&destruct_cafcLcLStandardRecord);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::StandardRecord*)
   {
      return GenerateInitInstanceLocal((::caf::StandardRecord*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::StandardRecord*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLStandardRecord_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::StandardRecord*)nullptr)->GetClass();
      cafcLcLStandardRecord_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLStandardRecord_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRSystParamHeader_Dictionary();
   static void cafcLcLSRSystParamHeader_TClassManip(TClass*);
   static void *new_cafcLcLSRSystParamHeader(void *p = nullptr);
   static void *newArray_cafcLcLSRSystParamHeader(Long_t size, void *p);
   static void delete_cafcLcLSRSystParamHeader(void *p);
   static void deleteArray_cafcLcLSRSystParamHeader(void *p);
   static void destruct_cafcLcLSRSystParamHeader(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRSystParamHeader*)
   {
      ::caf::SRSystParamHeader *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRSystParamHeader));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRSystParamHeader", 10, "SRSystParamHeader.h", 9,
                  typeid(::caf::SRSystParamHeader), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRSystParamHeader_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRSystParamHeader) );
      instance.SetNew(&new_cafcLcLSRSystParamHeader);
      instance.SetNewArray(&newArray_cafcLcLSRSystParamHeader);
      instance.SetDelete(&delete_cafcLcLSRSystParamHeader);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRSystParamHeader);
      instance.SetDestructor(&destruct_cafcLcLSRSystParamHeader);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRSystParamHeader*)
   {
      return GenerateInitInstanceLocal((::caf::SRSystParamHeader*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRSystParamHeader*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRSystParamHeader_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRSystParamHeader*)nullptr)->GetClass();
      cafcLcLSRSystParamHeader_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRSystParamHeader_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRWeightGlobal_Dictionary();
   static void cafcLcLSRWeightGlobal_TClassManip(TClass*);
   static void *new_cafcLcLSRWeightGlobal(void *p = nullptr);
   static void *newArray_cafcLcLSRWeightGlobal(Long_t size, void *p);
   static void delete_cafcLcLSRWeightGlobal(void *p);
   static void deleteArray_cafcLcLSRWeightGlobal(void *p);
   static void destruct_cafcLcLSRWeightGlobal(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRWeightGlobal*)
   {
      ::caf::SRWeightGlobal *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRWeightGlobal));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRWeightGlobal", 10, "SRWeightGlobal.h", 10,
                  typeid(::caf::SRWeightGlobal), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRWeightGlobal_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRWeightGlobal) );
      instance.SetNew(&new_cafcLcLSRWeightGlobal);
      instance.SetNewArray(&newArray_cafcLcLSRWeightGlobal);
      instance.SetDelete(&delete_cafcLcLSRWeightGlobal);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRWeightGlobal);
      instance.SetDestructor(&destruct_cafcLcLSRWeightGlobal);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRWeightGlobal*)
   {
      return GenerateInitInstanceLocal((::caf::SRWeightGlobal*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRWeightGlobal*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRWeightGlobal_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRWeightGlobal*)nullptr)->GetClass();
      cafcLcLSRWeightGlobal_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRWeightGlobal_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGlobal_Dictionary();
   static void cafcLcLSRGlobal_TClassManip(TClass*);
   static void *new_cafcLcLSRGlobal(void *p = nullptr);
   static void *newArray_cafcLcLSRGlobal(Long_t size, void *p);
   static void delete_cafcLcLSRGlobal(void *p);
   static void deleteArray_cafcLcLSRGlobal(void *p);
   static void destruct_cafcLcLSRGlobal(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGlobal*)
   {
      ::caf::SRGlobal *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGlobal));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGlobal", 10, "SRGlobal.h", 8,
                  typeid(::caf::SRGlobal), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGlobal_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGlobal) );
      instance.SetNew(&new_cafcLcLSRGlobal);
      instance.SetNewArray(&newArray_cafcLcLSRGlobal);
      instance.SetDelete(&delete_cafcLcLSRGlobal);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGlobal);
      instance.SetDestructor(&destruct_cafcLcLSRGlobal);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGlobal*)
   {
      return GenerateInitInstanceLocal((::caf::SRGlobal*)nullptr);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGlobal*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGlobal_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGlobal*)nullptr)->GetClass();
      cafcLcLSRGlobal_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGlobal_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRVector3D(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRVector3D : new ::caf::SRVector3D;
   }
   static void *newArray_cafcLcLSRVector3D(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRVector3D[nElements] : new ::caf::SRVector3D[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRVector3D(void *p) {
      delete ((::caf::SRVector3D*)p);
   }
   static void deleteArray_cafcLcLSRVector3D(void *p) {
      delete [] ((::caf::SRVector3D*)p);
   }
   static void destruct_cafcLcLSRVector3D(void *p) {
      typedef ::caf::SRVector3D current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRVector3D

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRBeamBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRBeamBranch : new ::caf::SRBeamBranch;
   }
   static void *newArray_cafcLcLSRBeamBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRBeamBranch[nElements] : new ::caf::SRBeamBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRBeamBranch(void *p) {
      delete ((::caf::SRBeamBranch*)p);
   }
   static void deleteArray_cafcLcLSRBeamBranch(void *p) {
      delete [] ((::caf::SRBeamBranch*)p);
   }
   static void destruct_cafcLcLSRBeamBranch(void *p) {
      typedef ::caf::SRBeamBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRBeamBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLTrueParticleID(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::TrueParticleID : new ::caf::TrueParticleID;
   }
   static void *newArray_cafcLcLTrueParticleID(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::TrueParticleID[nElements] : new ::caf::TrueParticleID[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLTrueParticleID(void *p) {
      delete ((::caf::TrueParticleID*)p);
   }
   static void deleteArray_cafcLcLTrueParticleID(void *p) {
      delete [] ((::caf::TrueParticleID*)p);
   }
   static void destruct_cafcLcLTrueParticleID(void *p) {
      typedef ::caf::TrueParticleID current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::TrueParticleID

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRDetectorMeta(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRDetectorMeta : new ::caf::SRDetectorMeta;
   }
   static void *newArray_cafcLcLSRDetectorMeta(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRDetectorMeta[nElements] : new ::caf::SRDetectorMeta[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRDetectorMeta(void *p) {
      delete ((::caf::SRDetectorMeta*)p);
   }
   static void deleteArray_cafcLcLSRDetectorMeta(void *p) {
      delete [] ((::caf::SRDetectorMeta*)p);
   }
   static void destruct_cafcLcLSRDetectorMeta(void *p) {
      typedef ::caf::SRDetectorMeta current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRDetectorMeta

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRDetectorMetaBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRDetectorMetaBranch : new ::caf::SRDetectorMetaBranch;
   }
   static void *newArray_cafcLcLSRDetectorMetaBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRDetectorMetaBranch[nElements] : new ::caf::SRDetectorMetaBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRDetectorMetaBranch(void *p) {
      delete ((::caf::SRDetectorMetaBranch*)p);
   }
   static void deleteArray_cafcLcLSRDetectorMetaBranch(void *p) {
      delete [] ((::caf::SRDetectorMetaBranch*)p);
   }
   static void destruct_cafcLcLSRDetectorMetaBranch(void *p) {
      typedef ::caf::SRDetectorMetaBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRDetectorMetaBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRDirectionBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRDirectionBranch : new ::caf::SRDirectionBranch;
   }
   static void *newArray_cafcLcLSRDirectionBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRDirectionBranch[nElements] : new ::caf::SRDirectionBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRDirectionBranch(void *p) {
      delete ((::caf::SRDirectionBranch*)p);
   }
   static void deleteArray_cafcLcLSRDirectionBranch(void *p) {
      delete [] ((::caf::SRDirectionBranch*)p);
   }
   static void destruct_cafcLcLSRDirectionBranch(void *p) {
      typedef ::caf::SRDirectionBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRDirectionBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNeutrinoEnergyBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNeutrinoEnergyBranch : new ::caf::SRNeutrinoEnergyBranch;
   }
   static void *newArray_cafcLcLSRNeutrinoEnergyBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNeutrinoEnergyBranch[nElements] : new ::caf::SRNeutrinoEnergyBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNeutrinoEnergyBranch(void *p) {
      delete ((::caf::SRNeutrinoEnergyBranch*)p);
   }
   static void deleteArray_cafcLcLSRNeutrinoEnergyBranch(void *p) {
      delete [] ((::caf::SRNeutrinoEnergyBranch*)p);
   }
   static void destruct_cafcLcLSRNeutrinoEnergyBranch(void *p) {
      typedef ::caf::SRNeutrinoEnergyBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNeutrinoEnergyBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRCVNScoreBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRCVNScoreBranch : new ::caf::SRCVNScoreBranch;
   }
   static void *newArray_cafcLcLSRCVNScoreBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRCVNScoreBranch[nElements] : new ::caf::SRCVNScoreBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRCVNScoreBranch(void *p) {
      delete ((::caf::SRCVNScoreBranch*)p);
   }
   static void deleteArray_cafcLcLSRCVNScoreBranch(void *p) {
      delete [] ((::caf::SRCVNScoreBranch*)p);
   }
   static void destruct_cafcLcLSRCVNScoreBranch(void *p) {
      typedef ::caf::SRCVNScoreBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRCVNScoreBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNeutrinoHypothesisBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNeutrinoHypothesisBranch : new ::caf::SRNeutrinoHypothesisBranch;
   }
   static void *newArray_cafcLcLSRNeutrinoHypothesisBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNeutrinoHypothesisBranch[nElements] : new ::caf::SRNeutrinoHypothesisBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNeutrinoHypothesisBranch(void *p) {
      delete ((::caf::SRNeutrinoHypothesisBranch*)p);
   }
   static void deleteArray_cafcLcLSRNeutrinoHypothesisBranch(void *p) {
      delete [] ((::caf::SRNeutrinoHypothesisBranch*)p);
   }
   static void destruct_cafcLcLSRNeutrinoHypothesisBranch(void *p) {
      typedef ::caf::SRNeutrinoHypothesisBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNeutrinoHypothesisBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRLorentzVector(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRLorentzVector : new ::caf::SRLorentzVector;
   }
   static void *newArray_cafcLcLSRLorentzVector(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRLorentzVector[nElements] : new ::caf::SRLorentzVector[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRLorentzVector(void *p) {
      delete ((::caf::SRLorentzVector*)p);
   }
   static void deleteArray_cafcLcLSRLorentzVector(void *p) {
      delete [] ((::caf::SRLorentzVector*)p);
   }
   static void destruct_cafcLcLSRLorentzVector(void *p) {
      typedef ::caf::SRLorentzVector current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRLorentzVector

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRRecoParticle(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRRecoParticle : new ::caf::SRRecoParticle;
   }
   static void *newArray_cafcLcLSRRecoParticle(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRRecoParticle[nElements] : new ::caf::SRRecoParticle[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRRecoParticle(void *p) {
      delete ((::caf::SRRecoParticle*)p);
   }
   static void deleteArray_cafcLcLSRRecoParticle(void *p) {
      delete [] ((::caf::SRRecoParticle*)p);
   }
   static void destruct_cafcLcLSRRecoParticle(void *p) {
      typedef ::caf::SRRecoParticle current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRRecoParticle

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRRecoParticlesBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRRecoParticlesBranch : new ::caf::SRRecoParticlesBranch;
   }
   static void *newArray_cafcLcLSRRecoParticlesBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRRecoParticlesBranch[nElements] : new ::caf::SRRecoParticlesBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRRecoParticlesBranch(void *p) {
      delete ((::caf::SRRecoParticlesBranch*)p);
   }
   static void deleteArray_cafcLcLSRRecoParticlesBranch(void *p) {
      delete [] ((::caf::SRRecoParticlesBranch*)p);
   }
   static void destruct_cafcLcLSRRecoParticlesBranch(void *p) {
      typedef ::caf::SRRecoParticlesBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRRecoParticlesBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRInteraction(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRInteraction : new ::caf::SRInteraction;
   }
   static void *newArray_cafcLcLSRInteraction(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRInteraction[nElements] : new ::caf::SRInteraction[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRInteraction(void *p) {
      delete ((::caf::SRInteraction*)p);
   }
   static void deleteArray_cafcLcLSRInteraction(void *p) {
      delete [] ((::caf::SRInteraction*)p);
   }
   static void destruct_cafcLcLSRInteraction(void *p) {
      typedef ::caf::SRInteraction current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRInteraction

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRInteractionBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRInteractionBranch : new ::caf::SRInteractionBranch;
   }
   static void *newArray_cafcLcLSRInteractionBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRInteractionBranch[nElements] : new ::caf::SRInteractionBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRInteractionBranch(void *p) {
      delete ((::caf::SRInteractionBranch*)p);
   }
   static void deleteArray_cafcLcLSRInteractionBranch(void *p) {
      delete [] ((::caf::SRInteractionBranch*)p);
   }
   static void destruct_cafcLcLSRInteractionBranch(void *p) {
      typedef ::caf::SRInteractionBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRInteractionBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRCommonRecoBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRCommonRecoBranch : new ::caf::SRCommonRecoBranch;
   }
   static void *newArray_cafcLcLSRCommonRecoBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRCommonRecoBranch[nElements] : new ::caf::SRCommonRecoBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRCommonRecoBranch(void *p) {
      delete ((::caf::SRCommonRecoBranch*)p);
   }
   static void deleteArray_cafcLcLSRCommonRecoBranch(void *p) {
      delete [] ((::caf::SRCommonRecoBranch*)p);
   }
   static void destruct_cafcLcLSRCommonRecoBranch(void *p) {
      typedef ::caf::SRCommonRecoBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRCommonRecoBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRTrueParticle(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTrueParticle : new ::caf::SRTrueParticle;
   }
   static void *newArray_cafcLcLSRTrueParticle(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTrueParticle[nElements] : new ::caf::SRTrueParticle[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRTrueParticle(void *p) {
      delete ((::caf::SRTrueParticle*)p);
   }
   static void deleteArray_cafcLcLSRTrueParticle(void *p) {
      delete [] ((::caf::SRTrueParticle*)p);
   }
   static void destruct_cafcLcLSRTrueParticle(void *p) {
      typedef ::caf::SRTrueParticle current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRTrueParticle

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRShower(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRShower : new ::caf::SRShower;
   }
   static void *newArray_cafcLcLSRShower(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRShower[nElements] : new ::caf::SRShower[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRShower(void *p) {
      delete ((::caf::SRShower*)p);
   }
   static void deleteArray_cafcLcLSRShower(void *p) {
      delete [] ((::caf::SRShower*)p);
   }
   static void destruct_cafcLcLSRShower(void *p) {
      typedef ::caf::SRShower current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRShower

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRTrack(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTrack : new ::caf::SRTrack;
   }
   static void *newArray_cafcLcLSRTrack(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTrack[nElements] : new ::caf::SRTrack[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRTrack(void *p) {
      delete ((::caf::SRTrack*)p);
   }
   static void deleteArray_cafcLcLSRTrack(void *p) {
      delete [] ((::caf::SRTrack*)p);
   }
   static void destruct_cafcLcLSRTrack(void *p) {
      typedef ::caf::SRTrack current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRTrack

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRFDInt(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRFDInt : new ::caf::SRFDInt;
   }
   static void *newArray_cafcLcLSRFDInt(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRFDInt[nElements] : new ::caf::SRFDInt[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRFDInt(void *p) {
      delete ((::caf::SRFDInt*)p);
   }
   static void deleteArray_cafcLcLSRFDInt(void *p) {
      delete [] ((::caf::SRFDInt*)p);
   }
   static void destruct_cafcLcLSRFDInt(void *p) {
      typedef ::caf::SRFDInt current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRFDInt

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRFD(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRFD : new ::caf::SRFD;
   }
   static void *newArray_cafcLcLSRFD(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRFD[nElements] : new ::caf::SRFD[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRFD(void *p) {
      delete ((::caf::SRFD*)p);
   }
   static void deleteArray_cafcLcLSRFD(void *p) {
      delete [] ((::caf::SRFD*)p);
   }
   static void destruct_cafcLcLSRFD(void *p) {
      typedef ::caf::SRFD current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRFD

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRFDBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRFDBranch : new ::caf::SRFDBranch;
   }
   static void *newArray_cafcLcLSRFDBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRFDBranch[nElements] : new ::caf::SRFDBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRFDBranch(void *p) {
      delete ((::caf::SRFDBranch*)p);
   }
   static void deleteArray_cafcLcLSRFDBranch(void *p) {
      delete [] ((::caf::SRFDBranch*)p);
   }
   static void destruct_cafcLcLSRFDBranch(void *p) {
      typedef ::caf::SRFDBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRFDBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGArParticle(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArParticle : new ::caf::SRGArParticle;
   }
   static void *newArray_cafcLcLSRGArParticle(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArParticle[nElements] : new ::caf::SRGArParticle[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGArParticle(void *p) {
      delete ((::caf::SRGArParticle*)p);
   }
   static void deleteArray_cafcLcLSRGArParticle(void *p) {
      delete [] ((::caf::SRGArParticle*)p);
   }
   static void destruct_cafcLcLSRGArParticle(void *p) {
      typedef ::caf::SRGArParticle current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGArParticle

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGArTrack(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArTrack : new ::caf::SRGArTrack;
   }
   static void *newArray_cafcLcLSRGArTrack(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArTrack[nElements] : new ::caf::SRGArTrack[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGArTrack(void *p) {
      delete ((::caf::SRGArTrack*)p);
   }
   static void deleteArray_cafcLcLSRGArTrack(void *p) {
      delete [] ((::caf::SRGArTrack*)p);
   }
   static void destruct_cafcLcLSRGArTrack(void *p) {
      typedef ::caf::SRGArTrack current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGArTrack

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGArECAL(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArECAL : new ::caf::SRGArECAL;
   }
   static void *newArray_cafcLcLSRGArECAL(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArECAL[nElements] : new ::caf::SRGArECAL[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGArECAL(void *p) {
      delete ((::caf::SRGArECAL*)p);
   }
   static void deleteArray_cafcLcLSRGArECAL(void *p) {
      delete [] ((::caf::SRGArECAL*)p);
   }
   static void destruct_cafcLcLSRGArECAL(void *p) {
      typedef ::caf::SRGArECAL current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGArECAL

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGArInt(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArInt : new ::caf::SRGArInt;
   }
   static void *newArray_cafcLcLSRGArInt(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArInt[nElements] : new ::caf::SRGArInt[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGArInt(void *p) {
      delete ((::caf::SRGArInt*)p);
   }
   static void deleteArray_cafcLcLSRGArInt(void *p) {
      delete [] ((::caf::SRGArInt*)p);
   }
   static void destruct_cafcLcLSRGArInt(void *p) {
      typedef ::caf::SRGArInt current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGArInt

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGArID(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArID : new ::caf::SRGArID;
   }
   static void *newArray_cafcLcLSRGArID(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArID[nElements] : new ::caf::SRGArID[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGArID(void *p) {
      delete ((::caf::SRGArID*)p);
   }
   static void deleteArray_cafcLcLSRGArID(void *p) {
      delete [] ((::caf::SRGArID*)p);
   }
   static void destruct_cafcLcLSRGArID(void *p) {
      typedef ::caf::SRGArID current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGArID

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGAr(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGAr : new ::caf::SRGAr;
   }
   static void *newArray_cafcLcLSRGAr(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGAr[nElements] : new ::caf::SRGAr[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGAr(void *p) {
      delete ((::caf::SRGAr*)p);
   }
   static void deleteArray_cafcLcLSRGAr(void *p) {
      delete [] ((::caf::SRGAr*)p);
   }
   static void destruct_cafcLcLSRGAr(void *p) {
      typedef ::caf::SRGAr current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGAr

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDLArInt(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDLArInt : new ::caf::SRNDLArInt;
   }
   static void *newArray_cafcLcLSRNDLArInt(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDLArInt[nElements] : new ::caf::SRNDLArInt[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDLArInt(void *p) {
      delete ((::caf::SRNDLArInt*)p);
   }
   static void deleteArray_cafcLcLSRNDLArInt(void *p) {
      delete [] ((::caf::SRNDLArInt*)p);
   }
   static void destruct_cafcLcLSRNDLArInt(void *p) {
      typedef ::caf::SRNDLArInt current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDLArInt

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDLArID(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDLArID : new ::caf::SRNDLArID;
   }
   static void *newArray_cafcLcLSRNDLArID(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDLArID[nElements] : new ::caf::SRNDLArID[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDLArID(void *p) {
      delete ((::caf::SRNDLArID*)p);
   }
   static void deleteArray_cafcLcLSRNDLArID(void *p) {
      delete [] ((::caf::SRNDLArID*)p);
   }
   static void destruct_cafcLcLSRNDLArID(void *p) {
      typedef ::caf::SRNDLArID current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDLArID

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDLAr(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDLAr : new ::caf::SRNDLAr;
   }
   static void *newArray_cafcLcLSRNDLAr(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDLAr[nElements] : new ::caf::SRNDLAr[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDLAr(void *p) {
      delete ((::caf::SRNDLAr*)p);
   }
   static void deleteArray_cafcLcLSRNDLAr(void *p) {
      delete [] ((::caf::SRNDLAr*)p);
   }
   static void destruct_cafcLcLSRNDLAr(void *p) {
      typedef ::caf::SRNDLAr current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDLAr

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRMINERvAInt(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRMINERvAInt : new ::caf::SRMINERvAInt;
   }
   static void *newArray_cafcLcLSRMINERvAInt(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRMINERvAInt[nElements] : new ::caf::SRMINERvAInt[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRMINERvAInt(void *p) {
      delete ((::caf::SRMINERvAInt*)p);
   }
   static void deleteArray_cafcLcLSRMINERvAInt(void *p) {
      delete [] ((::caf::SRMINERvAInt*)p);
   }
   static void destruct_cafcLcLSRMINERvAInt(void *p) {
      typedef ::caf::SRMINERvAInt current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRMINERvAInt

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRMINERvA(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRMINERvA : new ::caf::SRMINERvA;
   }
   static void *newArray_cafcLcLSRMINERvA(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRMINERvA[nElements] : new ::caf::SRMINERvA[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRMINERvA(void *p) {
      delete ((::caf::SRMINERvA*)p);
   }
   static void deleteArray_cafcLcLSRMINERvA(void *p) {
      delete [] ((::caf::SRMINERvA*)p);
   }
   static void destruct_cafcLcLSRMINERvA(void *p) {
      typedef ::caf::SRMINERvA current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRMINERvA

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRTMSInt(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTMSInt : new ::caf::SRTMSInt;
   }
   static void *newArray_cafcLcLSRTMSInt(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTMSInt[nElements] : new ::caf::SRTMSInt[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRTMSInt(void *p) {
      delete ((::caf::SRTMSInt*)p);
   }
   static void deleteArray_cafcLcLSRTMSInt(void *p) {
      delete [] ((::caf::SRTMSInt*)p);
   }
   static void destruct_cafcLcLSRTMSInt(void *p) {
      typedef ::caf::SRTMSInt current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRTMSInt

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRTMSID(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTMSID : new ::caf::SRTMSID;
   }
   static void *newArray_cafcLcLSRTMSID(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTMSID[nElements] : new ::caf::SRTMSID[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRTMSID(void *p) {
      delete ((::caf::SRTMSID*)p);
   }
   static void deleteArray_cafcLcLSRTMSID(void *p) {
      delete [] ((::caf::SRTMSID*)p);
   }
   static void destruct_cafcLcLSRTMSID(void *p) {
      typedef ::caf::SRTMSID current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRTMSID

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRTMS(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTMS : new ::caf::SRTMS;
   }
   static void *newArray_cafcLcLSRTMS(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTMS[nElements] : new ::caf::SRTMS[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRTMS(void *p) {
      delete ((::caf::SRTMS*)p);
   }
   static void deleteArray_cafcLcLSRTMS(void *p) {
      delete [] ((::caf::SRTMS*)p);
   }
   static void destruct_cafcLcLSRTMS(void *p) {
      typedef ::caf::SRTMS current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRTMS

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDShowerAssn(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDShowerAssn : new ::caf::SRNDShowerAssn;
   }
   static void *newArray_cafcLcLSRNDShowerAssn(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDShowerAssn[nElements] : new ::caf::SRNDShowerAssn[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDShowerAssn(void *p) {
      delete ((::caf::SRNDShowerAssn*)p);
   }
   static void deleteArray_cafcLcLSRNDShowerAssn(void *p) {
      delete [] ((::caf::SRNDShowerAssn*)p);
   }
   static void destruct_cafcLcLSRNDShowerAssn(void *p) {
      typedef ::caf::SRNDShowerAssn current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDShowerAssn

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDTrackAssn(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDTrackAssn : new ::caf::SRNDTrackAssn;
   }
   static void *newArray_cafcLcLSRNDTrackAssn(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDTrackAssn[nElements] : new ::caf::SRNDTrackAssn[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDTrackAssn(void *p) {
      delete ((::caf::SRNDTrackAssn*)p);
   }
   static void deleteArray_cafcLcLSRNDTrackAssn(void *p) {
      delete [] ((::caf::SRNDTrackAssn*)p);
   }
   static void destruct_cafcLcLSRNDTrackAssn(void *p) {
      typedef ::caf::SRNDTrackAssn current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDTrackAssn

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDTrkAssnBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDTrkAssnBranch : new ::caf::SRNDTrkAssnBranch;
   }
   static void *newArray_cafcLcLSRNDTrkAssnBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDTrkAssnBranch[nElements] : new ::caf::SRNDTrkAssnBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDTrkAssnBranch(void *p) {
      delete ((::caf::SRNDTrkAssnBranch*)p);
   }
   static void deleteArray_cafcLcLSRNDTrkAssnBranch(void *p) {
      delete [] ((::caf::SRNDTrkAssnBranch*)p);
   }
   static void destruct_cafcLcLSRNDTrkAssnBranch(void *p) {
      typedef ::caf::SRNDTrkAssnBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDTrkAssnBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDShwAssnBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDShwAssnBranch : new ::caf::SRNDShwAssnBranch;
   }
   static void *newArray_cafcLcLSRNDShwAssnBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDShwAssnBranch[nElements] : new ::caf::SRNDShwAssnBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDShwAssnBranch(void *p) {
      delete ((::caf::SRNDShwAssnBranch*)p);
   }
   static void deleteArray_cafcLcLSRNDShwAssnBranch(void *p) {
      delete [] ((::caf::SRNDShwAssnBranch*)p);
   }
   static void destruct_cafcLcLSRNDShwAssnBranch(void *p) {
      typedef ::caf::SRNDShwAssnBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDShwAssnBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRSAND(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRSAND : new ::caf::SRSAND;
   }
   static void *newArray_cafcLcLSRSAND(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRSAND[nElements] : new ::caf::SRSAND[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRSAND(void *p) {
      delete ((::caf::SRSAND*)p);
   }
   static void deleteArray_cafcLcLSRSAND(void *p) {
      delete [] ((::caf::SRSAND*)p);
   }
   static void destruct_cafcLcLSRSAND(void *p) {
      typedef ::caf::SRSAND current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRSAND

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDBranch : new ::caf::SRNDBranch;
   }
   static void *newArray_cafcLcLSRNDBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDBranch[nElements] : new ::caf::SRNDBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDBranch(void *p) {
      delete ((::caf::SRNDBranch*)p);
   }
   static void deleteArray_cafcLcLSRNDBranch(void *p) {
      delete [] ((::caf::SRNDBranch*)p);
   }
   static void destruct_cafcLcLSRNDBranch(void *p) {
      typedef ::caf::SRNDBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRTrueInteraction(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTrueInteraction : new ::caf::SRTrueInteraction;
   }
   static void *newArray_cafcLcLSRTrueInteraction(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTrueInteraction[nElements] : new ::caf::SRTrueInteraction[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRTrueInteraction(void *p) {
      delete ((::caf::SRTrueInteraction*)p);
   }
   static void deleteArray_cafcLcLSRTrueInteraction(void *p) {
      delete [] ((::caf::SRTrueInteraction*)p);
   }
   static void destruct_cafcLcLSRTrueInteraction(void *p) {
      typedef ::caf::SRTrueInteraction current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRTrueInteraction

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRTruthBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTruthBranch : new ::caf::SRTruthBranch;
   }
   static void *newArray_cafcLcLSRTruthBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTruthBranch[nElements] : new ::caf::SRTruthBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRTruthBranch(void *p) {
      delete ((::caf::SRTruthBranch*)p);
   }
   static void deleteArray_cafcLcLSRTruthBranch(void *p) {
      delete [] ((::caf::SRTruthBranch*)p);
   }
   static void destruct_cafcLcLSRTruthBranch(void *p) {
      typedef ::caf::SRTruthBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRTruthBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLStandardRecord(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::StandardRecord : new ::caf::StandardRecord;
   }
   static void *newArray_cafcLcLStandardRecord(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::StandardRecord[nElements] : new ::caf::StandardRecord[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLStandardRecord(void *p) {
      delete ((::caf::StandardRecord*)p);
   }
   static void deleteArray_cafcLcLStandardRecord(void *p) {
      delete [] ((::caf::StandardRecord*)p);
   }
   static void destruct_cafcLcLStandardRecord(void *p) {
      typedef ::caf::StandardRecord current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::StandardRecord

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRSystParamHeader(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRSystParamHeader : new ::caf::SRSystParamHeader;
   }
   static void *newArray_cafcLcLSRSystParamHeader(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRSystParamHeader[nElements] : new ::caf::SRSystParamHeader[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRSystParamHeader(void *p) {
      delete ((::caf::SRSystParamHeader*)p);
   }
   static void deleteArray_cafcLcLSRSystParamHeader(void *p) {
      delete [] ((::caf::SRSystParamHeader*)p);
   }
   static void destruct_cafcLcLSRSystParamHeader(void *p) {
      typedef ::caf::SRSystParamHeader current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRSystParamHeader

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRWeightGlobal(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRWeightGlobal : new ::caf::SRWeightGlobal;
   }
   static void *newArray_cafcLcLSRWeightGlobal(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRWeightGlobal[nElements] : new ::caf::SRWeightGlobal[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRWeightGlobal(void *p) {
      delete ((::caf::SRWeightGlobal*)p);
   }
   static void deleteArray_cafcLcLSRWeightGlobal(void *p) {
      delete [] ((::caf::SRWeightGlobal*)p);
   }
   static void destruct_cafcLcLSRWeightGlobal(void *p) {
      typedef ::caf::SRWeightGlobal current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRWeightGlobal

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGlobal(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGlobal : new ::caf::SRGlobal;
   }
   static void *newArray_cafcLcLSRGlobal(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGlobal[nElements] : new ::caf::SRGlobal[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGlobal(void *p) {
      delete ((::caf::SRGlobal*)p);
   }
   static void deleteArray_cafcLcLSRGlobal(void *p) {
      delete [] ((::caf::SRGlobal*)p);
   }
   static void destruct_cafcLcLSRGlobal(void *p) {
      typedef ::caf::SRGlobal current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGlobal

namespace ROOT {
   static TClass *vectorlEcafcLcLSRTrackgR_Dictionary();
   static void vectorlEcafcLcLSRTrackgR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRTrackgR(void *p = nullptr);
   static void *newArray_vectorlEcafcLcLSRTrackgR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRTrackgR(void *p);
   static void deleteArray_vectorlEcafcLcLSRTrackgR(void *p);
   static void destruct_vectorlEcafcLcLSRTrackgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRTrack>*)
   {
      vector<caf::SRTrack> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRTrack>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRTrack>", -2, "vector", 386,
                  typeid(vector<caf::SRTrack>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRTrackgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRTrack>) );
      instance.SetNew(&new_vectorlEcafcLcLSRTrackgR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRTrackgR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRTrackgR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRTrackgR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRTrackgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRTrack> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRTrack>","std::vector<caf::SRTrack, std::allocator<caf::SRTrack> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRTrack>*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRTrackgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRTrack>*)nullptr)->GetClass();
      vectorlEcafcLcLSRTrackgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRTrackgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRTrackgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRTrack> : new vector<caf::SRTrack>;
   }
   static void *newArray_vectorlEcafcLcLSRTrackgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRTrack>[nElements] : new vector<caf::SRTrack>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRTrackgR(void *p) {
      delete ((vector<caf::SRTrack>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRTrackgR(void *p) {
      delete [] ((vector<caf::SRTrack>*)p);
   }
   static void destruct_vectorlEcafcLcLSRTrackgR(void *p) {
      typedef vector<caf::SRTrack> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRTrack>

namespace ROOT {
   static TClass *vectorlEcafcLcLSRShowergR_Dictionary();
   static void vectorlEcafcLcLSRShowergR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRShowergR(void *p = nullptr);
   static void *newArray_vectorlEcafcLcLSRShowergR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRShowergR(void *p);
   static void deleteArray_vectorlEcafcLcLSRShowergR(void *p);
   static void destruct_vectorlEcafcLcLSRShowergR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRShower>*)
   {
      vector<caf::SRShower> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRShower>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRShower>", -2, "vector", 386,
                  typeid(vector<caf::SRShower>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRShowergR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRShower>) );
      instance.SetNew(&new_vectorlEcafcLcLSRShowergR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRShowergR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRShowergR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRShowergR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRShowergR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRShower> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRShower>","std::vector<caf::SRShower, std::allocator<caf::SRShower> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRShower>*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRShowergR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRShower>*)nullptr)->GetClass();
      vectorlEcafcLcLSRShowergR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRShowergR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRShowergR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRShower> : new vector<caf::SRShower>;
   }
   static void *newArray_vectorlEcafcLcLSRShowergR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRShower>[nElements] : new vector<caf::SRShower>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRShowergR(void *p) {
      delete ((vector<caf::SRShower>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRShowergR(void *p) {
      delete [] ((vector<caf::SRShower>*)p);
   }
   static void destruct_vectorlEcafcLcLSRShowergR(void *p) {
      typedef vector<caf::SRShower> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRShower>

namespace ROOT {
   static TClass *vectorlEcafcLcLSRRecoParticlegR_Dictionary();
   static void vectorlEcafcLcLSRRecoParticlegR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRRecoParticlegR(void *p = nullptr);
   static void *newArray_vectorlEcafcLcLSRRecoParticlegR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRRecoParticlegR(void *p);
   static void deleteArray_vectorlEcafcLcLSRRecoParticlegR(void *p);
   static void destruct_vectorlEcafcLcLSRRecoParticlegR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRRecoParticle>*)
   {
      vector<caf::SRRecoParticle> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRRecoParticle>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRRecoParticle>", -2, "vector", 386,
                  typeid(vector<caf::SRRecoParticle>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRRecoParticlegR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRRecoParticle>) );
      instance.SetNew(&new_vectorlEcafcLcLSRRecoParticlegR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRRecoParticlegR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRRecoParticlegR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRRecoParticlegR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRRecoParticlegR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRRecoParticle> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRRecoParticle>","std::vector<caf::SRRecoParticle, std::allocator<caf::SRRecoParticle> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRRecoParticle>*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRRecoParticlegR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRRecoParticle>*)nullptr)->GetClass();
      vectorlEcafcLcLSRRecoParticlegR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRRecoParticlegR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRRecoParticlegR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRRecoParticle> : new vector<caf::SRRecoParticle>;
   }
   static void *newArray_vectorlEcafcLcLSRRecoParticlegR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRRecoParticle>[nElements] : new vector<caf::SRRecoParticle>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRRecoParticlegR(void *p) {
      delete ((vector<caf::SRRecoParticle>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRRecoParticlegR(void *p) {
      delete [] ((vector<caf::SRRecoParticle>*)p);
   }
   static void destruct_vectorlEcafcLcLSRRecoParticlegR(void *p) {
      typedef vector<caf::SRRecoParticle> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRRecoParticle>

namespace ROOT {
   static TClass *vectorlEcafcLcLSRNDTrackAssngR_Dictionary();
   static void vectorlEcafcLcLSRNDTrackAssngR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRNDTrackAssngR(void *p = nullptr);
   static void *newArray_vectorlEcafcLcLSRNDTrackAssngR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRNDTrackAssngR(void *p);
   static void deleteArray_vectorlEcafcLcLSRNDTrackAssngR(void *p);
   static void destruct_vectorlEcafcLcLSRNDTrackAssngR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRNDTrackAssn>*)
   {
      vector<caf::SRNDTrackAssn> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRNDTrackAssn>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRNDTrackAssn>", -2, "vector", 386,
                  typeid(vector<caf::SRNDTrackAssn>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRNDTrackAssngR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRNDTrackAssn>) );
      instance.SetNew(&new_vectorlEcafcLcLSRNDTrackAssngR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRNDTrackAssngR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRNDTrackAssngR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRNDTrackAssngR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRNDTrackAssngR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRNDTrackAssn> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRNDTrackAssn>","std::vector<caf::SRNDTrackAssn, std::allocator<caf::SRNDTrackAssn> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRNDTrackAssn>*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRNDTrackAssngR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRNDTrackAssn>*)nullptr)->GetClass();
      vectorlEcafcLcLSRNDTrackAssngR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRNDTrackAssngR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRNDTrackAssngR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRNDTrackAssn> : new vector<caf::SRNDTrackAssn>;
   }
   static void *newArray_vectorlEcafcLcLSRNDTrackAssngR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRNDTrackAssn>[nElements] : new vector<caf::SRNDTrackAssn>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRNDTrackAssngR(void *p) {
      delete ((vector<caf::SRNDTrackAssn>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRNDTrackAssngR(void *p) {
      delete [] ((vector<caf::SRNDTrackAssn>*)p);
   }
   static void destruct_vectorlEcafcLcLSRNDTrackAssngR(void *p) {
      typedef vector<caf::SRNDTrackAssn> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRNDTrackAssn>

namespace ROOT {
   static TClass *vectorlEcafcLcLSRGArTrackgR_Dictionary();
   static void vectorlEcafcLcLSRGArTrackgR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRGArTrackgR(void *p = nullptr);
   static void *newArray_vectorlEcafcLcLSRGArTrackgR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRGArTrackgR(void *p);
   static void deleteArray_vectorlEcafcLcLSRGArTrackgR(void *p);
   static void destruct_vectorlEcafcLcLSRGArTrackgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRGArTrack>*)
   {
      vector<caf::SRGArTrack> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRGArTrack>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRGArTrack>", -2, "vector", 386,
                  typeid(vector<caf::SRGArTrack>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRGArTrackgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRGArTrack>) );
      instance.SetNew(&new_vectorlEcafcLcLSRGArTrackgR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRGArTrackgR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRGArTrackgR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRGArTrackgR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRGArTrackgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRGArTrack> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRGArTrack>","std::vector<caf::SRGArTrack, std::allocator<caf::SRGArTrack> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRGArTrack>*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRGArTrackgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRGArTrack>*)nullptr)->GetClass();
      vectorlEcafcLcLSRGArTrackgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRGArTrackgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRGArTrackgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRGArTrack> : new vector<caf::SRGArTrack>;
   }
   static void *newArray_vectorlEcafcLcLSRGArTrackgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRGArTrack>[nElements] : new vector<caf::SRGArTrack>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRGArTrackgR(void *p) {
      delete ((vector<caf::SRGArTrack>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRGArTrackgR(void *p) {
      delete [] ((vector<caf::SRGArTrack>*)p);
   }
   static void destruct_vectorlEcafcLcLSRGArTrackgR(void *p) {
      typedef vector<caf::SRGArTrack> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRGArTrack>

namespace ROOT {
   static TClass *vectorlEcafcLcLSRGArParticlegR_Dictionary();
   static void vectorlEcafcLcLSRGArParticlegR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRGArParticlegR(void *p = nullptr);
   static void *newArray_vectorlEcafcLcLSRGArParticlegR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRGArParticlegR(void *p);
   static void deleteArray_vectorlEcafcLcLSRGArParticlegR(void *p);
   static void destruct_vectorlEcafcLcLSRGArParticlegR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRGArParticle>*)
   {
      vector<caf::SRGArParticle> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRGArParticle>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRGArParticle>", -2, "vector", 386,
                  typeid(vector<caf::SRGArParticle>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRGArParticlegR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRGArParticle>) );
      instance.SetNew(&new_vectorlEcafcLcLSRGArParticlegR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRGArParticlegR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRGArParticlegR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRGArParticlegR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRGArParticlegR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRGArParticle> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRGArParticle>","std::vector<caf::SRGArParticle, std::allocator<caf::SRGArParticle> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRGArParticle>*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRGArParticlegR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRGArParticle>*)nullptr)->GetClass();
      vectorlEcafcLcLSRGArParticlegR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRGArParticlegR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRGArParticlegR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRGArParticle> : new vector<caf::SRGArParticle>;
   }
   static void *newArray_vectorlEcafcLcLSRGArParticlegR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRGArParticle>[nElements] : new vector<caf::SRGArParticle>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRGArParticlegR(void *p) {
      delete ((vector<caf::SRGArParticle>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRGArParticlegR(void *p) {
      delete [] ((vector<caf::SRGArParticle>*)p);
   }
   static void destruct_vectorlEcafcLcLSRGArParticlegR(void *p) {
      typedef vector<caf::SRGArParticle> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRGArParticle>

namespace ROOT {
   static TClass *vectorlEcafcLcLSRGArECALgR_Dictionary();
   static void vectorlEcafcLcLSRGArECALgR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRGArECALgR(void *p = nullptr);
   static void *newArray_vectorlEcafcLcLSRGArECALgR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRGArECALgR(void *p);
   static void deleteArray_vectorlEcafcLcLSRGArECALgR(void *p);
   static void destruct_vectorlEcafcLcLSRGArECALgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRGArECAL>*)
   {
      vector<caf::SRGArECAL> *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRGArECAL>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRGArECAL>", -2, "vector", 386,
                  typeid(vector<caf::SRGArECAL>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRGArECALgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRGArECAL>) );
      instance.SetNew(&new_vectorlEcafcLcLSRGArECALgR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRGArECALgR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRGArECALgR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRGArECALgR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRGArECALgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRGArECAL> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRGArECAL>","std::vector<caf::SRGArECAL, std::allocator<caf::SRGArECAL> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRGArECAL>*)nullptr); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRGArECALgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRGArECAL>*)nullptr)->GetClass();
      vectorlEcafcLcLSRGArECALgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRGArECALgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRGArECALgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRGArECAL> : new vector<caf::SRGArECAL>;
   }
   static void *newArray_vectorlEcafcLcLSRGArECALgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRGArECAL>[nElements] : new vector<caf::SRGArECAL>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRGArECALgR(void *p) {
      delete ((vector<caf::SRGArECAL>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRGArECALgR(void *p) {
      delete [] ((vector<caf::SRGArECAL>*)p);
   }
   static void destruct_vectorlEcafcLcLSRGArECALgR(void *p) {
      typedef vector<caf::SRGArECAL> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRGArECAL>

namespace {
  void TriggerDictionaryInitialization_libduneanaobj_StandardRecord_dict_Impl() {
    static const char* headers[] = {
"0",
nullptr
    };
    static const char* includePaths[] = {
"/exp/dune/app/users/fmlopez/ndgar_tests/duneanaobj",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/cetmodules/v3_13_02/src",
"/exp/dune/app/users/fmlopez/ndgar_tests/duneanaobj/duneanaobj/StandardRecord",
"/exp/dune/app/users/fmlopez/ndgar_tests/build",
"/exp/dune/app/users/fmlopez/ndgar_tests/duneanaobj",
"/exp/dune/app/users/fmlopez/ndgar_tests/build",
"/exp/dune/app/users/fmlopez/ndgar_tests/duneanaobj",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_26_06b/Linux64bit+3.10-2.17-e20-p3913-prof/include/",
"/exp/dune/app/users/fmlopez/ndgar_tests/build/duneanaobj/StandardRecord/",
nullptr
    };
    static const char* fwdDeclCode = R"DICTFWDDCLS(
#line 1 "libduneanaobj_StandardRecord_dict dictionary forward declarations' payload"
#pragma clang diagnostic ignored "-Wkeyword-compat"
#pragma clang diagnostic ignored "-Wignored-attributes"
#pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
extern int __Cling_AutoLoading_Map;
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRRecoParticle.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRRecoParticle;}
namespace std{template <typename _Tp> class __attribute__((annotate("$clingAutoload$bits/allocator.h")))  __attribute__((annotate("$clingAutoload$string")))  allocator;
}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRTrack.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRTrack;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRShower.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRShower;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGArParticle.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRGArParticle;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGArTrack.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRGArTrack;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGArECAL.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRGArECAL;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDTrackAssn.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDTrackAssn;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRVector3D.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRVector3D;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRBeamBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRBeamBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SREnums.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  TrueParticleID;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRMeta.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRDetectorMeta;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRDetectorMetaBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRDetectorMetaBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRDirectionBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRDirectionBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNeutrinoEnergyBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNeutrinoEnergyBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRCVNScoreBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRCVNScoreBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNeutrinoHypothesisBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNeutrinoHypothesisBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRLorentzVector.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRLorentzVector;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRRecoParticlesBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRRecoParticlesBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRInteraction.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRInteraction;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRInteractionBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRInteractionBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRCommonRecoBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRCommonRecoBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRTrueParticle.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRTrueParticle;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRFD.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRFDInt;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRFD.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRFD;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRFDBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRFDBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGAr.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRGArInt;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGAr.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRGArID;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGAr.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRGAr;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDLAr.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDLArInt;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDLAr.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDLArID;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDLAr.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDLAr;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRMINERvA.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRMINERvAInt;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRMINERvA.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRMINERvA;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRTMS.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRTMSInt;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRTMS.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRTMSID;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRTMS.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRTMS;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDShowerAssn.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDShowerAssn;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDAssnBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDTrkAssnBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDAssnBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDShwAssnBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRSAND.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRSAND;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRTrueInteraction.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRTrueInteraction;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRTruthBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRTruthBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  StandardRecord;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRSystParamHeader.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGlobal.h")))  SRSystParamHeader;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRWeightGlobal.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGlobal.h")))  SRWeightGlobal;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGlobal.h")))  SRGlobal;}
)DICTFWDDCLS";
    static const char* payloadCode = R"DICTPAYLOAD(
#line 1 "libduneanaobj_StandardRecord_dict dictionary payload"

#ifndef NDEBUG
  #define NDEBUG 1
#endif

#define _BACKWARD_BACKWARD_WARNING_H
// Inline headers
#include <vector>

#include "duneanaobj/StandardRecord/StandardRecord.h"
#include "duneanaobj/StandardRecord/SRGlobal.h"

#undef  _BACKWARD_BACKWARD_WARNING_H
)DICTPAYLOAD";
    static const char* classesHeaders[] = {
"caf::Detector", payloadCode, "@",
"caf::Generator", payloadCode, "@",
"caf::SRBeamBranch", payloadCode, "@",
"caf::SRCVNScoreBranch", payloadCode, "@",
"caf::SRCommonRecoBranch", payloadCode, "@",
"caf::SRDetectorMeta", payloadCode, "@",
"caf::SRDetectorMetaBranch", payloadCode, "@",
"caf::SRDirectionBranch", payloadCode, "@",
"caf::SRFD", payloadCode, "@",
"caf::SRFDBranch", payloadCode, "@",
"caf::SRFDInt", payloadCode, "@",
"caf::SRGAr", payloadCode, "@",
"caf::SRGArECAL", payloadCode, "@",
"caf::SRGArID", payloadCode, "@",
"caf::SRGArInt", payloadCode, "@",
"caf::SRGArParticle", payloadCode, "@",
"caf::SRGArTrack", payloadCode, "@",
"caf::SRGlobal", payloadCode, "@",
"caf::SRInteraction", payloadCode, "@",
"caf::SRInteractionBranch", payloadCode, "@",
"caf::SRLorentzVector", payloadCode, "@",
"caf::SRMINERvA", payloadCode, "@",
"caf::SRMINERvAInt", payloadCode, "@",
"caf::SRNDBranch", payloadCode, "@",
"caf::SRNDLAr", payloadCode, "@",
"caf::SRNDLArID", payloadCode, "@",
"caf::SRNDLArInt", payloadCode, "@",
"caf::SRNDShowerAssn", payloadCode, "@",
"caf::SRNDShwAssnBranch", payloadCode, "@",
"caf::SRNDTrackAssn", payloadCode, "@",
"caf::SRNDTrkAssnBranch", payloadCode, "@",
"caf::SRNeutrinoEnergyBranch", payloadCode, "@",
"caf::SRNeutrinoHypothesisBranch", payloadCode, "@",
"caf::SRRecoParticle", payloadCode, "@",
"caf::SRRecoParticlesBranch", payloadCode, "@",
"caf::SRSAND", payloadCode, "@",
"caf::SRShower", payloadCode, "@",
"caf::SRSystParamHeader", payloadCode, "@",
"caf::SRTMS", payloadCode, "@",
"caf::SRTMSID", payloadCode, "@",
"caf::SRTMSInt", payloadCode, "@",
"caf::SRTrack", payloadCode, "@",
"caf::SRTrueInteraction", payloadCode, "@",
"caf::SRTrueParticle", payloadCode, "@",
"caf::SRTruthBranch", payloadCode, "@",
"caf::SRVector3D", payloadCode, "@",
"caf::SRWeightGlobal", payloadCode, "@",
"caf::ScatteringMode", payloadCode, "@",
"caf::StandardRecord", payloadCode, "@",
"caf::TrueParticleID", payloadCode, "@",
nullptr
};
    static bool isInitialized = false;
    if (!isInitialized) {
      TROOT::RegisterModule("libduneanaobj_StandardRecord_dict",
        headers, includePaths, payloadCode, fwdDeclCode,
        TriggerDictionaryInitialization_libduneanaobj_StandardRecord_dict_Impl, {}, classesHeaders, /*hasCxxModule*/false);
      isInitialized = true;
    }
  }
  static struct DictInit {
    DictInit() {
      TriggerDictionaryInitialization_libduneanaobj_StandardRecord_dict_Impl();
    }
  } __TheDictionaryInitializer;
}
void TriggerDictionaryInitialization_libduneanaobj_StandardRecord_dict() {
  TriggerDictionaryInitialization_libduneanaobj_StandardRecord_dict_Impl();
}
