
namespace caf{using SRProxy = caf::Proxy<caf::StandardRecord>;}

