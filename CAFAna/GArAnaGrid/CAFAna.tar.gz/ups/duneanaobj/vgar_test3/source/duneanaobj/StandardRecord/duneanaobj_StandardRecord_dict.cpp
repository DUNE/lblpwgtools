// Do NOT change. Changes will be lost next time file is generated

#define R__DICTIONARY_FILENAME duneanaobj_StandardRecord_dict
#define R__NO_DEPRECATION

/*******************************************************************/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#define G__DICTIONARY
#include "RConfig.h"
#include "TClass.h"
#include "TDictAttributeMap.h"
#include "TInterpreter.h"
#include "TROOT.h"
#include "TBuffer.h"
#include "TMemberInspector.h"
#include "TInterpreter.h"
#include "TVirtualMutex.h"
#include "TError.h"

#ifndef G__ROOT
#define G__ROOT
#endif

#include "RtypesImp.h"
#include "TIsAProxy.h"
#include "TFileMergeInfo.h"
#include <algorithm>
#include "TCollectionProxyInfo.h"
/*******************************************************************/

#include "TDataMember.h"

// The generated code does not explicitly qualifies STL entities
namespace std {} using namespace std;

// Header files passed as explicit arguments
#include "/dune/app/users/fmlopez/ndgar_tests/duneanaobj/duneanaobj/StandardRecord/classes.h"

// Header files passed via #pragma extra_include

namespace ROOT {
   static TClass *cafcLcLSRVector3D_Dictionary();
   static void cafcLcLSRVector3D_TClassManip(TClass*);
   static void *new_cafcLcLSRVector3D(void *p = 0);
   static void *newArray_cafcLcLSRVector3D(Long_t size, void *p);
   static void delete_cafcLcLSRVector3D(void *p);
   static void deleteArray_cafcLcLSRVector3D(void *p);
   static void destruct_cafcLcLSRVector3D(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRVector3D*)
   {
      ::caf::SRVector3D *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRVector3D));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRVector3D", 10, "SRVector3D.h", 25,
                  typeid(::caf::SRVector3D), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRVector3D_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRVector3D) );
      instance.SetNew(&new_cafcLcLSRVector3D);
      instance.SetNewArray(&newArray_cafcLcLSRVector3D);
      instance.SetDelete(&delete_cafcLcLSRVector3D);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRVector3D);
      instance.SetDestructor(&destruct_cafcLcLSRVector3D);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRVector3D*)
   {
      return GenerateInitInstanceLocal((::caf::SRVector3D*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRVector3D*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRVector3D_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRVector3D*)0x0)->GetClass();
      cafcLcLSRVector3D_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRVector3D_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRLorentzVector_Dictionary();
   static void cafcLcLSRLorentzVector_TClassManip(TClass*);
   static void *new_cafcLcLSRLorentzVector(void *p = 0);
   static void *newArray_cafcLcLSRLorentzVector(Long_t size, void *p);
   static void delete_cafcLcLSRLorentzVector(void *p);
   static void deleteArray_cafcLcLSRLorentzVector(void *p);
   static void destruct_cafcLcLSRLorentzVector(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRLorentzVector*)
   {
      ::caf::SRLorentzVector *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRLorentzVector));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRLorentzVector", 10, "SRLorentzVector.h", 27,
                  typeid(::caf::SRLorentzVector), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRLorentzVector_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRLorentzVector) );
      instance.SetNew(&new_cafcLcLSRLorentzVector);
      instance.SetNewArray(&newArray_cafcLcLSRLorentzVector);
      instance.SetDelete(&delete_cafcLcLSRLorentzVector);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRLorentzVector);
      instance.SetDestructor(&destruct_cafcLcLSRLorentzVector);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRLorentzVector*)
   {
      return GenerateInitInstanceLocal((::caf::SRLorentzVector*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRLorentzVector*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRLorentzVector_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRLorentzVector*)0x0)->GetClass();
      cafcLcLSRLorentzVector_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRLorentzVector_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRParticleTruth_Dictionary();
   static void cafcLcLSRParticleTruth_TClassManip(TClass*);
   static void *new_cafcLcLSRParticleTruth(void *p = 0);
   static void *newArray_cafcLcLSRParticleTruth(Long_t size, void *p);
   static void delete_cafcLcLSRParticleTruth(void *p);
   static void deleteArray_cafcLcLSRParticleTruth(void *p);
   static void destruct_cafcLcLSRParticleTruth(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRParticleTruth*)
   {
      ::caf::SRParticleTruth *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRParticleTruth));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRParticleTruth", 10, "SRParticleTruth.h", 16,
                  typeid(::caf::SRParticleTruth), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRParticleTruth_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRParticleTruth) );
      instance.SetNew(&new_cafcLcLSRParticleTruth);
      instance.SetNewArray(&newArray_cafcLcLSRParticleTruth);
      instance.SetDelete(&delete_cafcLcLSRParticleTruth);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRParticleTruth);
      instance.SetDestructor(&destruct_cafcLcLSRParticleTruth);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRParticleTruth*)
   {
      return GenerateInitInstanceLocal((::caf::SRParticleTruth*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRParticleTruth*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRParticleTruth_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRParticleTruth*)0x0)->GetClass();
      cafcLcLSRParticleTruth_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRParticleTruth_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRTrack_Dictionary();
   static void cafcLcLSRTrack_TClassManip(TClass*);
   static void *new_cafcLcLSRTrack(void *p = 0);
   static void *newArray_cafcLcLSRTrack(Long_t size, void *p);
   static void delete_cafcLcLSRTrack(void *p);
   static void deleteArray_cafcLcLSRTrack(void *p);
   static void destruct_cafcLcLSRTrack(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRTrack*)
   {
      ::caf::SRTrack *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRTrack));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRTrack", 13, "SRTrack.h", 15,
                  typeid(::caf::SRTrack), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRTrack_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRTrack) );
      instance.SetNew(&new_cafcLcLSRTrack);
      instance.SetNewArray(&newArray_cafcLcLSRTrack);
      instance.SetDelete(&delete_cafcLcLSRTrack);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRTrack);
      instance.SetDestructor(&destruct_cafcLcLSRTrack);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRTrack*)
   {
      return GenerateInitInstanceLocal((::caf::SRTrack*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRTrack*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRTrack_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRTrack*)0x0)->GetClass();
      cafcLcLSRTrack_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRTrack_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGArTrack_Dictionary();
   static void cafcLcLSRGArTrack_TClassManip(TClass*);
   static void *new_cafcLcLSRGArTrack(void *p = 0);
   static void *newArray_cafcLcLSRGArTrack(Long_t size, void *p);
   static void delete_cafcLcLSRGArTrack(void *p);
   static void deleteArray_cafcLcLSRGArTrack(void *p);
   static void destruct_cafcLcLSRGArTrack(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGArTrack*)
   {
      ::caf::SRGArTrack *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGArTrack));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGArTrack", 11, "SRGArTrack.h", 14,
                  typeid(::caf::SRGArTrack), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGArTrack_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGArTrack) );
      instance.SetNew(&new_cafcLcLSRGArTrack);
      instance.SetNewArray(&newArray_cafcLcLSRGArTrack);
      instance.SetDelete(&delete_cafcLcLSRGArTrack);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGArTrack);
      instance.SetDestructor(&destruct_cafcLcLSRGArTrack);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGArTrack*)
   {
      return GenerateInitInstanceLocal((::caf::SRGArTrack*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGArTrack*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGArTrack_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGArTrack*)0x0)->GetClass();
      cafcLcLSRGArTrack_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGArTrack_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGArECAL_Dictionary();
   static void cafcLcLSRGArECAL_TClassManip(TClass*);
   static void *new_cafcLcLSRGArECAL(void *p = 0);
   static void *newArray_cafcLcLSRGArECAL(Long_t size, void *p);
   static void delete_cafcLcLSRGArECAL(void *p);
   static void deleteArray_cafcLcLSRGArECAL(void *p);
   static void destruct_cafcLcLSRGArECAL(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGArECAL*)
   {
      ::caf::SRGArECAL *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGArECAL));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGArECAL", 11, "SRGArECAL.h", 16,
                  typeid(::caf::SRGArECAL), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGArECAL_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGArECAL) );
      instance.SetNew(&new_cafcLcLSRGArECAL);
      instance.SetNewArray(&newArray_cafcLcLSRGArECAL);
      instance.SetDelete(&delete_cafcLcLSRGArECAL);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGArECAL);
      instance.SetDestructor(&destruct_cafcLcLSRGArECAL);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGArECAL*)
   {
      return GenerateInitInstanceLocal((::caf::SRGArECAL*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGArECAL*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGArECAL_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGArECAL*)0x0)->GetClass();
      cafcLcLSRGArECAL_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGArECAL_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGAr_Dictionary();
   static void cafcLcLSRGAr_TClassManip(TClass*);
   static void *new_cafcLcLSRGAr(void *p = 0);
   static void *newArray_cafcLcLSRGAr(Long_t size, void *p);
   static void delete_cafcLcLSRGAr(void *p);
   static void deleteArray_cafcLcLSRGAr(void *p);
   static void destruct_cafcLcLSRGAr(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGAr*)
   {
      ::caf::SRGAr *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGAr));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGAr", 11, "SRGAr.h", 16,
                  typeid(::caf::SRGAr), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGAr_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGAr) );
      instance.SetNew(&new_cafcLcLSRGAr);
      instance.SetNewArray(&newArray_cafcLcLSRGAr);
      instance.SetDelete(&delete_cafcLcLSRGAr);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGAr);
      instance.SetDestructor(&destruct_cafcLcLSRGAr);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGAr*)
   {
      return GenerateInitInstanceLocal((::caf::SRGAr*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGAr*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGAr_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGAr*)0x0)->GetClass();
      cafcLcLSRGAr_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGAr_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRShower_Dictionary();
   static void cafcLcLSRShower_TClassManip(TClass*);
   static void *new_cafcLcLSRShower(void *p = 0);
   static void *newArray_cafcLcLSRShower(Long_t size, void *p);
   static void delete_cafcLcLSRShower(void *p);
   static void deleteArray_cafcLcLSRShower(void *p);
   static void destruct_cafcLcLSRShower(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRShower*)
   {
      ::caf::SRShower *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRShower));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRShower", 10, "SRShower.h", 16,
                  typeid(::caf::SRShower), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRShower_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRShower) );
      instance.SetNew(&new_cafcLcLSRShower);
      instance.SetNewArray(&newArray_cafcLcLSRShower);
      instance.SetDelete(&delete_cafcLcLSRShower);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRShower);
      instance.SetDestructor(&destruct_cafcLcLSRShower);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRShower*)
   {
      return GenerateInitInstanceLocal((::caf::SRShower*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRShower*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRShower_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRShower*)0x0)->GetClass();
      cafcLcLSRShower_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRShower_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDLAr_Dictionary();
   static void cafcLcLSRNDLAr_TClassManip(TClass*);
   static void *new_cafcLcLSRNDLAr(void *p = 0);
   static void *newArray_cafcLcLSRNDLAr(Long_t size, void *p);
   static void delete_cafcLcLSRNDLAr(void *p);
   static void deleteArray_cafcLcLSRNDLAr(void *p);
   static void destruct_cafcLcLSRNDLAr(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDLAr*)
   {
      ::caf::SRNDLAr *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDLAr));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDLAr", 10, "SRNDLAr.h", 16,
                  typeid(::caf::SRNDLAr), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDLAr_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDLAr) );
      instance.SetNew(&new_cafcLcLSRNDLAr);
      instance.SetNewArray(&newArray_cafcLcLSRNDLAr);
      instance.SetDelete(&delete_cafcLcLSRNDLAr);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDLAr);
      instance.SetDestructor(&destruct_cafcLcLSRNDLAr);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDLAr*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDLAr*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDLAr*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDLAr_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDLAr*)0x0)->GetClass();
      cafcLcLSRNDLAr_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDLAr_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDTrackAssn_Dictionary();
   static void cafcLcLSRNDTrackAssn_TClassManip(TClass*);
   static void *new_cafcLcLSRNDTrackAssn(void *p = 0);
   static void *newArray_cafcLcLSRNDTrackAssn(Long_t size, void *p);
   static void delete_cafcLcLSRNDTrackAssn(void *p);
   static void deleteArray_cafcLcLSRNDTrackAssn(void *p);
   static void destruct_cafcLcLSRNDTrackAssn(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDTrackAssn*)
   {
      ::caf::SRNDTrackAssn *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDTrackAssn));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDTrackAssn", 10, "SRNDTrackAssn.h", 10,
                  typeid(::caf::SRNDTrackAssn), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDTrackAssn_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDTrackAssn) );
      instance.SetNew(&new_cafcLcLSRNDTrackAssn);
      instance.SetNewArray(&newArray_cafcLcLSRNDTrackAssn);
      instance.SetDelete(&delete_cafcLcLSRNDTrackAssn);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDTrackAssn);
      instance.SetDestructor(&destruct_cafcLcLSRNDTrackAssn);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDTrackAssn*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDTrackAssn*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDTrackAssn*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDTrackAssn_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDTrackAssn*)0x0)->GetClass();
      cafcLcLSRNDTrackAssn_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDTrackAssn_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRTMS_Dictionary();
   static void cafcLcLSRTMS_TClassManip(TClass*);
   static void *new_cafcLcLSRTMS(void *p = 0);
   static void *newArray_cafcLcLSRTMS(Long_t size, void *p);
   static void delete_cafcLcLSRTMS(void *p);
   static void deleteArray_cafcLcLSRTMS(void *p);
   static void destruct_cafcLcLSRTMS(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRTMS*)
   {
      ::caf::SRTMS *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRTMS));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRTMS", 10, "SRTMS.h", 11,
                  typeid(::caf::SRTMS), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRTMS_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRTMS) );
      instance.SetNew(&new_cafcLcLSRTMS);
      instance.SetNewArray(&newArray_cafcLcLSRTMS);
      instance.SetDelete(&delete_cafcLcLSRTMS);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRTMS);
      instance.SetDestructor(&destruct_cafcLcLSRTMS);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRTMS*)
   {
      return GenerateInitInstanceLocal((::caf::SRTMS*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRTMS*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRTMS_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRTMS*)0x0)->GetClass();
      cafcLcLSRTMS_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRTMS_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRNDBranch_Dictionary();
   static void cafcLcLSRNDBranch_TClassManip(TClass*);
   static void *new_cafcLcLSRNDBranch(void *p = 0);
   static void *newArray_cafcLcLSRNDBranch(Long_t size, void *p);
   static void delete_cafcLcLSRNDBranch(void *p);
   static void deleteArray_cafcLcLSRNDBranch(void *p);
   static void destruct_cafcLcLSRNDBranch(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRNDBranch*)
   {
      ::caf::SRNDBranch *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRNDBranch));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRNDBranch", 13, "SRNDBranch.h", 18,
                  typeid(::caf::SRNDBranch), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRNDBranch_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRNDBranch) );
      instance.SetNew(&new_cafcLcLSRNDBranch);
      instance.SetNewArray(&newArray_cafcLcLSRNDBranch);
      instance.SetDelete(&delete_cafcLcLSRNDBranch);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRNDBranch);
      instance.SetDestructor(&destruct_cafcLcLSRNDBranch);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRNDBranch*)
   {
      return GenerateInitInstanceLocal((::caf::SRNDBranch*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRNDBranch*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRNDBranch_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRNDBranch*)0x0)->GetClass();
      cafcLcLSRNDBranch_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRNDBranch_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLStandardRecord_Dictionary();
   static void cafcLcLStandardRecord_TClassManip(TClass*);
   static void *new_cafcLcLStandardRecord(void *p = 0);
   static void *newArray_cafcLcLStandardRecord(Long_t size, void *p);
   static void delete_cafcLcLStandardRecord(void *p);
   static void deleteArray_cafcLcLStandardRecord(void *p);
   static void destruct_cafcLcLStandardRecord(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::StandardRecord*)
   {
      ::caf::StandardRecord *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::StandardRecord));
      static ::ROOT::TGenericClassInfo 
         instance("caf::StandardRecord", 13, "StandardRecord.h", 24,
                  typeid(::caf::StandardRecord), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLStandardRecord_Dictionary, isa_proxy, 12,
                  sizeof(::caf::StandardRecord) );
      instance.SetNew(&new_cafcLcLStandardRecord);
      instance.SetNewArray(&newArray_cafcLcLStandardRecord);
      instance.SetDelete(&delete_cafcLcLStandardRecord);
      instance.SetDeleteArray(&deleteArray_cafcLcLStandardRecord);
      instance.SetDestructor(&destruct_cafcLcLStandardRecord);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::StandardRecord*)
   {
      return GenerateInitInstanceLocal((::caf::StandardRecord*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::StandardRecord*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLStandardRecord_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::StandardRecord*)0x0)->GetClass();
      cafcLcLStandardRecord_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLStandardRecord_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRSystParamHeader_Dictionary();
   static void cafcLcLSRSystParamHeader_TClassManip(TClass*);
   static void *new_cafcLcLSRSystParamHeader(void *p = 0);
   static void *newArray_cafcLcLSRSystParamHeader(Long_t size, void *p);
   static void delete_cafcLcLSRSystParamHeader(void *p);
   static void deleteArray_cafcLcLSRSystParamHeader(void *p);
   static void destruct_cafcLcLSRSystParamHeader(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRSystParamHeader*)
   {
      ::caf::SRSystParamHeader *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRSystParamHeader));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRSystParamHeader", 10, "SRSystParamHeader.h", 9,
                  typeid(::caf::SRSystParamHeader), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRSystParamHeader_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRSystParamHeader) );
      instance.SetNew(&new_cafcLcLSRSystParamHeader);
      instance.SetNewArray(&newArray_cafcLcLSRSystParamHeader);
      instance.SetDelete(&delete_cafcLcLSRSystParamHeader);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRSystParamHeader);
      instance.SetDestructor(&destruct_cafcLcLSRSystParamHeader);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRSystParamHeader*)
   {
      return GenerateInitInstanceLocal((::caf::SRSystParamHeader*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRSystParamHeader*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRSystParamHeader_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRSystParamHeader*)0x0)->GetClass();
      cafcLcLSRSystParamHeader_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRSystParamHeader_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRWeightGlobal_Dictionary();
   static void cafcLcLSRWeightGlobal_TClassManip(TClass*);
   static void *new_cafcLcLSRWeightGlobal(void *p = 0);
   static void *newArray_cafcLcLSRWeightGlobal(Long_t size, void *p);
   static void delete_cafcLcLSRWeightGlobal(void *p);
   static void deleteArray_cafcLcLSRWeightGlobal(void *p);
   static void destruct_cafcLcLSRWeightGlobal(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRWeightGlobal*)
   {
      ::caf::SRWeightGlobal *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRWeightGlobal));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRWeightGlobal", 10, "SRWeightGlobal.h", 10,
                  typeid(::caf::SRWeightGlobal), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRWeightGlobal_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRWeightGlobal) );
      instance.SetNew(&new_cafcLcLSRWeightGlobal);
      instance.SetNewArray(&newArray_cafcLcLSRWeightGlobal);
      instance.SetDelete(&delete_cafcLcLSRWeightGlobal);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRWeightGlobal);
      instance.SetDestructor(&destruct_cafcLcLSRWeightGlobal);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRWeightGlobal*)
   {
      return GenerateInitInstanceLocal((::caf::SRWeightGlobal*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRWeightGlobal*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRWeightGlobal_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRWeightGlobal*)0x0)->GetClass();
      cafcLcLSRWeightGlobal_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRWeightGlobal_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   static TClass *cafcLcLSRGlobal_Dictionary();
   static void cafcLcLSRGlobal_TClassManip(TClass*);
   static void *new_cafcLcLSRGlobal(void *p = 0);
   static void *newArray_cafcLcLSRGlobal(Long_t size, void *p);
   static void delete_cafcLcLSRGlobal(void *p);
   static void deleteArray_cafcLcLSRGlobal(void *p);
   static void destruct_cafcLcLSRGlobal(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::caf::SRGlobal*)
   {
      ::caf::SRGlobal *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::caf::SRGlobal));
      static ::ROOT::TGenericClassInfo 
         instance("caf::SRGlobal", 10, "SRGlobal.h", 8,
                  typeid(::caf::SRGlobal), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &cafcLcLSRGlobal_Dictionary, isa_proxy, 12,
                  sizeof(::caf::SRGlobal) );
      instance.SetNew(&new_cafcLcLSRGlobal);
      instance.SetNewArray(&newArray_cafcLcLSRGlobal);
      instance.SetDelete(&delete_cafcLcLSRGlobal);
      instance.SetDeleteArray(&deleteArray_cafcLcLSRGlobal);
      instance.SetDestructor(&destruct_cafcLcLSRGlobal);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::caf::SRGlobal*)
   {
      return GenerateInitInstanceLocal((::caf::SRGlobal*)0);
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const ::caf::SRGlobal*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *cafcLcLSRGlobal_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const ::caf::SRGlobal*)0x0)->GetClass();
      cafcLcLSRGlobal_TClassManip(theClass);
   return theClass;
   }

   static void cafcLcLSRGlobal_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRVector3D(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRVector3D : new ::caf::SRVector3D;
   }
   static void *newArray_cafcLcLSRVector3D(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRVector3D[nElements] : new ::caf::SRVector3D[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRVector3D(void *p) {
      delete ((::caf::SRVector3D*)p);
   }
   static void deleteArray_cafcLcLSRVector3D(void *p) {
      delete [] ((::caf::SRVector3D*)p);
   }
   static void destruct_cafcLcLSRVector3D(void *p) {
      typedef ::caf::SRVector3D current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRVector3D

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRLorentzVector(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRLorentzVector : new ::caf::SRLorentzVector;
   }
   static void *newArray_cafcLcLSRLorentzVector(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRLorentzVector[nElements] : new ::caf::SRLorentzVector[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRLorentzVector(void *p) {
      delete ((::caf::SRLorentzVector*)p);
   }
   static void deleteArray_cafcLcLSRLorentzVector(void *p) {
      delete [] ((::caf::SRLorentzVector*)p);
   }
   static void destruct_cafcLcLSRLorentzVector(void *p) {
      typedef ::caf::SRLorentzVector current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRLorentzVector

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRParticleTruth(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRParticleTruth : new ::caf::SRParticleTruth;
   }
   static void *newArray_cafcLcLSRParticleTruth(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRParticleTruth[nElements] : new ::caf::SRParticleTruth[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRParticleTruth(void *p) {
      delete ((::caf::SRParticleTruth*)p);
   }
   static void deleteArray_cafcLcLSRParticleTruth(void *p) {
      delete [] ((::caf::SRParticleTruth*)p);
   }
   static void destruct_cafcLcLSRParticleTruth(void *p) {
      typedef ::caf::SRParticleTruth current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRParticleTruth

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRTrack(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTrack : new ::caf::SRTrack;
   }
   static void *newArray_cafcLcLSRTrack(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTrack[nElements] : new ::caf::SRTrack[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRTrack(void *p) {
      delete ((::caf::SRTrack*)p);
   }
   static void deleteArray_cafcLcLSRTrack(void *p) {
      delete [] ((::caf::SRTrack*)p);
   }
   static void destruct_cafcLcLSRTrack(void *p) {
      typedef ::caf::SRTrack current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRTrack

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGArTrack(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArTrack : new ::caf::SRGArTrack;
   }
   static void *newArray_cafcLcLSRGArTrack(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArTrack[nElements] : new ::caf::SRGArTrack[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGArTrack(void *p) {
      delete ((::caf::SRGArTrack*)p);
   }
   static void deleteArray_cafcLcLSRGArTrack(void *p) {
      delete [] ((::caf::SRGArTrack*)p);
   }
   static void destruct_cafcLcLSRGArTrack(void *p) {
      typedef ::caf::SRGArTrack current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGArTrack

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGArECAL(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArECAL : new ::caf::SRGArECAL;
   }
   static void *newArray_cafcLcLSRGArECAL(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGArECAL[nElements] : new ::caf::SRGArECAL[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGArECAL(void *p) {
      delete ((::caf::SRGArECAL*)p);
   }
   static void deleteArray_cafcLcLSRGArECAL(void *p) {
      delete [] ((::caf::SRGArECAL*)p);
   }
   static void destruct_cafcLcLSRGArECAL(void *p) {
      typedef ::caf::SRGArECAL current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGArECAL

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGAr(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGAr : new ::caf::SRGAr;
   }
   static void *newArray_cafcLcLSRGAr(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGAr[nElements] : new ::caf::SRGAr[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGAr(void *p) {
      delete ((::caf::SRGAr*)p);
   }
   static void deleteArray_cafcLcLSRGAr(void *p) {
      delete [] ((::caf::SRGAr*)p);
   }
   static void destruct_cafcLcLSRGAr(void *p) {
      typedef ::caf::SRGAr current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGAr

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRShower(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRShower : new ::caf::SRShower;
   }
   static void *newArray_cafcLcLSRShower(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRShower[nElements] : new ::caf::SRShower[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRShower(void *p) {
      delete ((::caf::SRShower*)p);
   }
   static void deleteArray_cafcLcLSRShower(void *p) {
      delete [] ((::caf::SRShower*)p);
   }
   static void destruct_cafcLcLSRShower(void *p) {
      typedef ::caf::SRShower current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRShower

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDLAr(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDLAr : new ::caf::SRNDLAr;
   }
   static void *newArray_cafcLcLSRNDLAr(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDLAr[nElements] : new ::caf::SRNDLAr[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDLAr(void *p) {
      delete ((::caf::SRNDLAr*)p);
   }
   static void deleteArray_cafcLcLSRNDLAr(void *p) {
      delete [] ((::caf::SRNDLAr*)p);
   }
   static void destruct_cafcLcLSRNDLAr(void *p) {
      typedef ::caf::SRNDLAr current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDLAr

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDTrackAssn(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDTrackAssn : new ::caf::SRNDTrackAssn;
   }
   static void *newArray_cafcLcLSRNDTrackAssn(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDTrackAssn[nElements] : new ::caf::SRNDTrackAssn[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDTrackAssn(void *p) {
      delete ((::caf::SRNDTrackAssn*)p);
   }
   static void deleteArray_cafcLcLSRNDTrackAssn(void *p) {
      delete [] ((::caf::SRNDTrackAssn*)p);
   }
   static void destruct_cafcLcLSRNDTrackAssn(void *p) {
      typedef ::caf::SRNDTrackAssn current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDTrackAssn

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRTMS(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTMS : new ::caf::SRTMS;
   }
   static void *newArray_cafcLcLSRTMS(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRTMS[nElements] : new ::caf::SRTMS[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRTMS(void *p) {
      delete ((::caf::SRTMS*)p);
   }
   static void deleteArray_cafcLcLSRTMS(void *p) {
      delete [] ((::caf::SRTMS*)p);
   }
   static void destruct_cafcLcLSRTMS(void *p) {
      typedef ::caf::SRTMS current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRTMS

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRNDBranch(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDBranch : new ::caf::SRNDBranch;
   }
   static void *newArray_cafcLcLSRNDBranch(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRNDBranch[nElements] : new ::caf::SRNDBranch[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRNDBranch(void *p) {
      delete ((::caf::SRNDBranch*)p);
   }
   static void deleteArray_cafcLcLSRNDBranch(void *p) {
      delete [] ((::caf::SRNDBranch*)p);
   }
   static void destruct_cafcLcLSRNDBranch(void *p) {
      typedef ::caf::SRNDBranch current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRNDBranch

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLStandardRecord(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::StandardRecord : new ::caf::StandardRecord;
   }
   static void *newArray_cafcLcLStandardRecord(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::StandardRecord[nElements] : new ::caf::StandardRecord[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLStandardRecord(void *p) {
      delete ((::caf::StandardRecord*)p);
   }
   static void deleteArray_cafcLcLStandardRecord(void *p) {
      delete [] ((::caf::StandardRecord*)p);
   }
   static void destruct_cafcLcLStandardRecord(void *p) {
      typedef ::caf::StandardRecord current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::StandardRecord

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRSystParamHeader(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRSystParamHeader : new ::caf::SRSystParamHeader;
   }
   static void *newArray_cafcLcLSRSystParamHeader(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRSystParamHeader[nElements] : new ::caf::SRSystParamHeader[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRSystParamHeader(void *p) {
      delete ((::caf::SRSystParamHeader*)p);
   }
   static void deleteArray_cafcLcLSRSystParamHeader(void *p) {
      delete [] ((::caf::SRSystParamHeader*)p);
   }
   static void destruct_cafcLcLSRSystParamHeader(void *p) {
      typedef ::caf::SRSystParamHeader current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRSystParamHeader

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRWeightGlobal(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRWeightGlobal : new ::caf::SRWeightGlobal;
   }
   static void *newArray_cafcLcLSRWeightGlobal(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRWeightGlobal[nElements] : new ::caf::SRWeightGlobal[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRWeightGlobal(void *p) {
      delete ((::caf::SRWeightGlobal*)p);
   }
   static void deleteArray_cafcLcLSRWeightGlobal(void *p) {
      delete [] ((::caf::SRWeightGlobal*)p);
   }
   static void destruct_cafcLcLSRWeightGlobal(void *p) {
      typedef ::caf::SRWeightGlobal current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRWeightGlobal

namespace ROOT {
   // Wrappers around operator new
   static void *new_cafcLcLSRGlobal(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGlobal : new ::caf::SRGlobal;
   }
   static void *newArray_cafcLcLSRGlobal(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) ::caf::SRGlobal[nElements] : new ::caf::SRGlobal[nElements];
   }
   // Wrapper around operator delete
   static void delete_cafcLcLSRGlobal(void *p) {
      delete ((::caf::SRGlobal*)p);
   }
   static void deleteArray_cafcLcLSRGlobal(void *p) {
      delete [] ((::caf::SRGlobal*)p);
   }
   static void destruct_cafcLcLSRGlobal(void *p) {
      typedef ::caf::SRGlobal current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class ::caf::SRGlobal

namespace ROOT {
   static TClass *vectorlEcafcLcLSRTrackgR_Dictionary();
   static void vectorlEcafcLcLSRTrackgR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRTrackgR(void *p = 0);
   static void *newArray_vectorlEcafcLcLSRTrackgR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRTrackgR(void *p);
   static void deleteArray_vectorlEcafcLcLSRTrackgR(void *p);
   static void destruct_vectorlEcafcLcLSRTrackgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRTrack>*)
   {
      vector<caf::SRTrack> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRTrack>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRTrack>", -2, "vector", 386,
                  typeid(vector<caf::SRTrack>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRTrackgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRTrack>) );
      instance.SetNew(&new_vectorlEcafcLcLSRTrackgR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRTrackgR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRTrackgR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRTrackgR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRTrackgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRTrack> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRTrack>","std::vector<caf::SRTrack, std::allocator<caf::SRTrack> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRTrack>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRTrackgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRTrack>*)0x0)->GetClass();
      vectorlEcafcLcLSRTrackgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRTrackgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRTrackgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRTrack> : new vector<caf::SRTrack>;
   }
   static void *newArray_vectorlEcafcLcLSRTrackgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRTrack>[nElements] : new vector<caf::SRTrack>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRTrackgR(void *p) {
      delete ((vector<caf::SRTrack>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRTrackgR(void *p) {
      delete [] ((vector<caf::SRTrack>*)p);
   }
   static void destruct_vectorlEcafcLcLSRTrackgR(void *p) {
      typedef vector<caf::SRTrack> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRTrack>

namespace ROOT {
   static TClass *vectorlEcafcLcLSRShowergR_Dictionary();
   static void vectorlEcafcLcLSRShowergR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRShowergR(void *p = 0);
   static void *newArray_vectorlEcafcLcLSRShowergR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRShowergR(void *p);
   static void deleteArray_vectorlEcafcLcLSRShowergR(void *p);
   static void destruct_vectorlEcafcLcLSRShowergR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRShower>*)
   {
      vector<caf::SRShower> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRShower>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRShower>", -2, "vector", 386,
                  typeid(vector<caf::SRShower>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRShowergR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRShower>) );
      instance.SetNew(&new_vectorlEcafcLcLSRShowergR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRShowergR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRShowergR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRShowergR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRShowergR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRShower> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRShower>","std::vector<caf::SRShower, std::allocator<caf::SRShower> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRShower>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRShowergR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRShower>*)0x0)->GetClass();
      vectorlEcafcLcLSRShowergR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRShowergR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRShowergR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRShower> : new vector<caf::SRShower>;
   }
   static void *newArray_vectorlEcafcLcLSRShowergR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRShower>[nElements] : new vector<caf::SRShower>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRShowergR(void *p) {
      delete ((vector<caf::SRShower>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRShowergR(void *p) {
      delete [] ((vector<caf::SRShower>*)p);
   }
   static void destruct_vectorlEcafcLcLSRShowergR(void *p) {
      typedef vector<caf::SRShower> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRShower>

namespace ROOT {
   static TClass *vectorlEcafcLcLSRNDTrackAssngR_Dictionary();
   static void vectorlEcafcLcLSRNDTrackAssngR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRNDTrackAssngR(void *p = 0);
   static void *newArray_vectorlEcafcLcLSRNDTrackAssngR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRNDTrackAssngR(void *p);
   static void deleteArray_vectorlEcafcLcLSRNDTrackAssngR(void *p);
   static void destruct_vectorlEcafcLcLSRNDTrackAssngR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRNDTrackAssn>*)
   {
      vector<caf::SRNDTrackAssn> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRNDTrackAssn>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRNDTrackAssn>", -2, "vector", 386,
                  typeid(vector<caf::SRNDTrackAssn>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRNDTrackAssngR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRNDTrackAssn>) );
      instance.SetNew(&new_vectorlEcafcLcLSRNDTrackAssngR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRNDTrackAssngR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRNDTrackAssngR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRNDTrackAssngR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRNDTrackAssngR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRNDTrackAssn> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRNDTrackAssn>","std::vector<caf::SRNDTrackAssn, std::allocator<caf::SRNDTrackAssn> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRNDTrackAssn>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRNDTrackAssngR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRNDTrackAssn>*)0x0)->GetClass();
      vectorlEcafcLcLSRNDTrackAssngR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRNDTrackAssngR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRNDTrackAssngR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRNDTrackAssn> : new vector<caf::SRNDTrackAssn>;
   }
   static void *newArray_vectorlEcafcLcLSRNDTrackAssngR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRNDTrackAssn>[nElements] : new vector<caf::SRNDTrackAssn>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRNDTrackAssngR(void *p) {
      delete ((vector<caf::SRNDTrackAssn>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRNDTrackAssngR(void *p) {
      delete [] ((vector<caf::SRNDTrackAssn>*)p);
   }
   static void destruct_vectorlEcafcLcLSRNDTrackAssngR(void *p) {
      typedef vector<caf::SRNDTrackAssn> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRNDTrackAssn>

namespace ROOT {
   static TClass *vectorlEcafcLcLSRGArTrackgR_Dictionary();
   static void vectorlEcafcLcLSRGArTrackgR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRGArTrackgR(void *p = 0);
   static void *newArray_vectorlEcafcLcLSRGArTrackgR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRGArTrackgR(void *p);
   static void deleteArray_vectorlEcafcLcLSRGArTrackgR(void *p);
   static void destruct_vectorlEcafcLcLSRGArTrackgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRGArTrack>*)
   {
      vector<caf::SRGArTrack> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRGArTrack>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRGArTrack>", -2, "vector", 386,
                  typeid(vector<caf::SRGArTrack>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRGArTrackgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRGArTrack>) );
      instance.SetNew(&new_vectorlEcafcLcLSRGArTrackgR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRGArTrackgR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRGArTrackgR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRGArTrackgR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRGArTrackgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRGArTrack> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRGArTrack>","std::vector<caf::SRGArTrack, std::allocator<caf::SRGArTrack> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRGArTrack>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRGArTrackgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRGArTrack>*)0x0)->GetClass();
      vectorlEcafcLcLSRGArTrackgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRGArTrackgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRGArTrackgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRGArTrack> : new vector<caf::SRGArTrack>;
   }
   static void *newArray_vectorlEcafcLcLSRGArTrackgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRGArTrack>[nElements] : new vector<caf::SRGArTrack>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRGArTrackgR(void *p) {
      delete ((vector<caf::SRGArTrack>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRGArTrackgR(void *p) {
      delete [] ((vector<caf::SRGArTrack>*)p);
   }
   static void destruct_vectorlEcafcLcLSRGArTrackgR(void *p) {
      typedef vector<caf::SRGArTrack> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRGArTrack>

namespace ROOT {
   static TClass *vectorlEcafcLcLSRGArECALgR_Dictionary();
   static void vectorlEcafcLcLSRGArECALgR_TClassManip(TClass*);
   static void *new_vectorlEcafcLcLSRGArECALgR(void *p = 0);
   static void *newArray_vectorlEcafcLcLSRGArECALgR(Long_t size, void *p);
   static void delete_vectorlEcafcLcLSRGArECALgR(void *p);
   static void deleteArray_vectorlEcafcLcLSRGArECALgR(void *p);
   static void destruct_vectorlEcafcLcLSRGArECALgR(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const vector<caf::SRGArECAL>*)
   {
      vector<caf::SRGArECAL> *ptr = 0;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(vector<caf::SRGArECAL>));
      static ::ROOT::TGenericClassInfo 
         instance("vector<caf::SRGArECAL>", -2, "vector", 386,
                  typeid(vector<caf::SRGArECAL>), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &vectorlEcafcLcLSRGArECALgR_Dictionary, isa_proxy, 4,
                  sizeof(vector<caf::SRGArECAL>) );
      instance.SetNew(&new_vectorlEcafcLcLSRGArECALgR);
      instance.SetNewArray(&newArray_vectorlEcafcLcLSRGArECALgR);
      instance.SetDelete(&delete_vectorlEcafcLcLSRGArECALgR);
      instance.SetDeleteArray(&deleteArray_vectorlEcafcLcLSRGArECALgR);
      instance.SetDestructor(&destruct_vectorlEcafcLcLSRGArECALgR);
      instance.AdoptCollectionProxyInfo(TCollectionProxyInfo::Generate(TCollectionProxyInfo::Pushback< vector<caf::SRGArECAL> >()));

      ::ROOT::AddClassAlternate("vector<caf::SRGArECAL>","std::vector<caf::SRGArECAL, std::allocator<caf::SRGArECAL> >");
      return &instance;
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal((const vector<caf::SRGArECAL>*)0x0); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *vectorlEcafcLcLSRGArECALgR_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal((const vector<caf::SRGArECAL>*)0x0)->GetClass();
      vectorlEcafcLcLSRGArECALgR_TClassManip(theClass);
   return theClass;
   }

   static void vectorlEcafcLcLSRGArECALgR_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_vectorlEcafcLcLSRGArECALgR(void *p) {
      return  p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRGArECAL> : new vector<caf::SRGArECAL>;
   }
   static void *newArray_vectorlEcafcLcLSRGArECALgR(Long_t nElements, void *p) {
      return p ? ::new((::ROOT::Internal::TOperatorNewHelper*)p) vector<caf::SRGArECAL>[nElements] : new vector<caf::SRGArECAL>[nElements];
   }
   // Wrapper around operator delete
   static void delete_vectorlEcafcLcLSRGArECALgR(void *p) {
      delete ((vector<caf::SRGArECAL>*)p);
   }
   static void deleteArray_vectorlEcafcLcLSRGArECALgR(void *p) {
      delete [] ((vector<caf::SRGArECAL>*)p);
   }
   static void destruct_vectorlEcafcLcLSRGArECALgR(void *p) {
      typedef vector<caf::SRGArECAL> current_t;
      ((current_t*)p)->~current_t();
   }
} // end of namespace ROOT for class vector<caf::SRGArECAL>

namespace {
  void TriggerDictionaryInitialization_libduneanaobj_StandardRecord_dict_Impl() {
    static const char* headers[] = {
"0",
0
    };
    static const char* includePaths[] = {
"/dune/app/users/fmlopez/ndgar_tests/duneanaobj",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/cetmodules/v3_13_02/src",
"/dune/app/users/fmlopez/ndgar_tests/duneanaobj/duneanaobj/StandardRecord",
"/dune/app/users/fmlopez/ndgar_tests/build",
"/dune/app/users/fmlopez/ndgar_tests/duneanaobj",
"/dune/app/users/fmlopez/ndgar_tests/build",
"/dune/app/users/fmlopez/ndgar_tests/duneanaobj",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include",
"/cvmfs/larsoft.opensciencegrid.org/products/root/v6_22_08d/Linux64bit+3.10-2.17-e20-p392-prof/include/",
"/dune/app/users/fmlopez/ndgar_tests/build/duneanaobj/StandardRecord/",
0
    };
    static const char* fwdDeclCode = R"DICTFWDDCLS(
#line 1 "libduneanaobj_StandardRecord_dict dictionary forward declarations' payload"
#pragma clang diagnostic ignored "-Wkeyword-compat"
#pragma clang diagnostic ignored "-Wignored-attributes"
#pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
extern int __Cling_AutoLoading_Map;
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGArTrack.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRGArTrack;}
namespace std{template <typename _Tp> class __attribute__((annotate("$clingAutoload$bits/allocator.h")))  __attribute__((annotate("$clingAutoload$string")))  allocator;
}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGArECAL.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRGArECAL;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRTrack.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRTrack;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRShower.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRShower;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDTrackAssn.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDTrackAssn;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRVector3D.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRVector3D;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRLorentzVector.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRLorentzVector;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRParticleTruth.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRParticleTruth;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGAr.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRGAr;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDLAr.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDLAr;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRTMS.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRTMS;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRNDBranch.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  SRNDBranch;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/StandardRecord.h")))  StandardRecord;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRSystParamHeader.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGlobal.h")))  SRSystParamHeader;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRWeightGlobal.h")))  __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGlobal.h")))  SRWeightGlobal;}
namespace caf{class __attribute__((annotate("$clingAutoload$duneanaobj/StandardRecord/SRGlobal.h")))  SRGlobal;}
)DICTFWDDCLS";
    static const char* payloadCode = R"DICTPAYLOAD(
#line 1 "libduneanaobj_StandardRecord_dict dictionary payload"

#ifndef NDEBUG
  #define NDEBUG 1
#endif

#define _BACKWARD_BACKWARD_WARNING_H
// Inline headers
#include <vector>

#include "duneanaobj/StandardRecord/StandardRecord.h"
#include "duneanaobj/StandardRecord/SRGlobal.h"

#undef  _BACKWARD_BACKWARD_WARNING_H
)DICTPAYLOAD";
    static const char* classesHeaders[] = {
"caf::SRGAr", payloadCode, "@",
"caf::SRGArECAL", payloadCode, "@",
"caf::SRGArTrack", payloadCode, "@",
"caf::SRGlobal", payloadCode, "@",
"caf::SRLorentzVector", payloadCode, "@",
"caf::SRNDBranch", payloadCode, "@",
"caf::SRNDLAr", payloadCode, "@",
"caf::SRNDTrackAssn", payloadCode, "@",
"caf::SRParticleTruth", payloadCode, "@",
"caf::SRShower", payloadCode, "@",
"caf::SRSystParamHeader", payloadCode, "@",
"caf::SRTMS", payloadCode, "@",
"caf::SRTrack", payloadCode, "@",
"caf::SRVector3D", payloadCode, "@",
"caf::SRWeightGlobal", payloadCode, "@",
"caf::StandardRecord", payloadCode, "@",
nullptr
};
    static bool isInitialized = false;
    if (!isInitialized) {
      TROOT::RegisterModule("libduneanaobj_StandardRecord_dict",
        headers, includePaths, payloadCode, fwdDeclCode,
        TriggerDictionaryInitialization_libduneanaobj_StandardRecord_dict_Impl, {}, classesHeaders, /*hasCxxModule*/false);
      isInitialized = true;
    }
  }
  static struct DictInit {
    DictInit() {
      TriggerDictionaryInitialization_libduneanaobj_StandardRecord_dict_Impl();
    }
  } __TheDictionaryInitializer;
}
void TriggerDictionaryInitialization_libduneanaobj_StandardRecord_dict() {
  TriggerDictionaryInitialization_libduneanaobj_StandardRecord_dict_Impl();
}
