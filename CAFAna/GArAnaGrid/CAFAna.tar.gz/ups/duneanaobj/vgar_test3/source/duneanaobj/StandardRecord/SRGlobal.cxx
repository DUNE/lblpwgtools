#include "duneanaobj/StandardRecord/SRGlobal.h"

namespace caf
{
  SRGlobal::SRGlobal()
  {
  }

  SRGlobal::~SRGlobal()
  {
  }
}
