#include "duneanaobj/StandardRecord/SRWeightGlobal.h"

namespace caf
{
  SRWeightGlobal::SRWeightGlobal()
  {
  }

  SRWeightGlobal::~SRWeightGlobal()
  {
  }
}
