#include "duneanaobj/StandardRecord/SRSystParamHeader.h"

namespace caf
{
  SRSystParamHeader::SRSystParamHeader()
    : nshifts(0), id(-1)
  {
  }

  SRSystParamHeader::~SRSystParamHeader()
  {
  }
}
