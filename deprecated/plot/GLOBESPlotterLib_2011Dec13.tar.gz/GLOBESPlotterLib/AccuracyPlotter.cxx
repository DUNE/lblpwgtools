#define AccuracyPlotter_C

#include "AccuracyPlotter.h"

AccuracyPlotter::AccuracyPlotter(string name)
{
  ProjectName = name;
  SetX();
  SetXLabel();
  SetYLabel();
  
  init=false;
  
  return;
}
AccuracyPlotter::~AccuracyPlotter()
{
}
void AccuracyPlotter::AddSet(int npts,string *files,double *vals,string label,double *truedeltavals)
{
  int i,j;
  
  DataFiles.push_back( vector<string>() );
  XVal.push_back( vector<double>() );
  TrueMin.push_back( vector<double>() );
  j = DataFiles.size()-1;
  for(i=0;i<npts;i++)
  {
    DataFiles[j].push_back(files[i]);
    XVal[j].push_back(vals[i]);
    TrueMin[j].push_back(truedeltavals[i]);
  }
  Labels.push_back(label);
  
  return;
}
void AccuracyPlotter::SetX(int n,double low,double high)
{
  nX = n;
  
  double width = (high - low)/(n-1);
  XLow = low - width/2.;
  XHigh = high + width/2.;
  
  return;
}
void AccuracyPlotter::MakeChi2Maps()
{
  if(init) return;
  
  cout<<"Making chi2 maps..."<<endl;
  
  ifstream f;
  unsigned int i,j;
  string s;
  int nsol;
  double x,chi2_stat,chi2_syst,chi2_corr,dummy;
  int u;
  for(i=0;i<DataFiles.size();i++)
  {
    cout<<"Set "<<i<<endl;
    Chi2Map.push_back( vector<TH1D*>() );
    for(j=0;j<DataFiles[i].size();j++)
    {
      Chi2Map[i].push_back(new TH1D(Form("Chi2Map_%i_%i",i,j),"",nX,XLow,XHigh));
    
      f.open(DataFiles[i][j].c_str());
      
      nsol=0;
      while(!f.eof())
      {
        getline(f,s);
        if(s[0]=='#') continue;//skip comments
        if(s.size()==0) continue;//skip blank lines
        if(s[0]=='0') continue;
        if(s[0]=='-' && s[1]=='-')
        {
          nsol++;
          continue;
        }
        if(nsol>1) break;
        
        stringstream ss(s);
        ss >> dummy >> x >> chi2_stat >> chi2_syst >> chi2_corr >> dummy >> dummy >> dummy >> dummy >> dummy >> dummy >> dummy >> dummy;
        
        u = Chi2Map[i][j]->Fill(x,chi2_corr);
      }
    
      f.close();
    }
  }
  
  init = true;
  
  cout<<"Finished with chi2 maps."<<endl;
  
  return;
}
void AccuracyPlotter::DrawChi2()
{
  MakeChi2Maps();
  
  unsigned int i,j;
  const unsigned int n1 = Chi2Map.size();
  const unsigned int n2 = Chi2Map[0].size();
  TCanvas *c[n1][n2];
  
  for(i=0;i<Chi2Map.size();i++)
  {
    for(j=0;j<Chi2Map[i].size();j++)
    {
      c[i][j] = new TCanvas(Form("c_%i_%i",i,j),"c",800,800);
      Chi2Map[i][j]->Draw();
    }
  }
  
  return;
}
void AccuracyPlotter::DrawResVs(double deltachi2)
{
  MakeChi2Maps();
  
  int min=0,up=0,dn=0;
  double mincenter,mincont,upd,dnd,mind,minchi2;
  unsigned int i,j,k;
  TF1 *func;
  double a,b,c;
  double e,el,eh;
  double errlo,errhi;
  vector< vector<double> > dpar;
  bool search;
  
  for(i=0;i<Chi2Map.size();i++)
  {
    dpar.push_back( vector<double>() );
    for(j=0;j<Chi2Map[i].size();j++)
    {
      min = Chi2Map[i][j]->GetMinimumBin();
      mincenter = Chi2Map[i][j]->GetXaxis()->GetBinCenter(min);
      if(TMath::Abs(mincenter-TrueMin[i][j])>100)
      {
//         cout<<"found wrong minimum for true min "<<TrueMin[i][j]<<endl;
        mincont = Chi2Map[i][j]->GetBinContent(min);
        for(k=0;k<Chi2Map[i][j]->GetNbinsX();k++)
        {
          if(TMath::Abs(Chi2Map[i][j]->GetBinContent(k+1)-mincont)<1e-5)
          {
            if(TMath::Abs(mincenter-Chi2Map[i][j]->GetBinCenter(k+1))>100)
            {
              min = k+1;
            }
          }
        }
      }
//       cout<<min<<endl;
      
      search = true;
      up = nX;
      if(min+1>nX)
      {
        search = false;
//         up = nX;
      }
      if(search)
      {
//         cout<<"looking for upper bound to fit between bins "<<min+1<<" "<<nX<<endl;
        for(k=min;k<nX;k++)
        {
//           cout<<k+1<<", "<<Chi2Map[i][j]->GetBinContent(k+1)<<endl;
          if(Chi2Map[i][j]->GetBinContent(k+1)>4)
          {
            up = k+1;
//             cout<<"found it: "<<up<<endl;
            break;
          }
        }
      }
      
      search = true;
      dn=1;
      if(min-1<1)
      {
//         dn = 1;
        search = false;
      }
      if(search)
      {
//         cout<<"looking for lower bound to fit between bins "<<min-2+1<<" 0"<<endl;
        for(k=min-2;k>0;k=k-1)
        {
//           cout<<k+1<<", "<<Chi2Map[i][j]->GetBinContent(k+1)<<endl;
          if(Chi2Map[i][j]->GetBinContent(k+1)>4)
          {
            dn = k+1;
//             cout<<"found it: "<<dn<<endl;
            break;
          }
        }
      }
//       cout<<up<<", "<<dn<<endl;
      if((up-dn)>10)//temporary fix
      {
        up = min+5;
        dn = min-5;
      }
//       cout<<up<<", "<<dn<<endl;
      
      upd = Chi2Map[i][j]->GetXaxis()->GetBinUpEdge(up);
      dnd = Chi2Map[i][j]->GetXaxis()->GetBinLowEdge(dn);
//       cout<<"Fitting between "<<dnd<<" "<<upd<<endl;
      
      func = new TF1("myfunc","pol2",dnd,upd);
      Chi2Map[i][j]->Fit(func,"Q","",dnd,upd);
      c = func->GetParameter(0);
      b = func->GetParameter(1);
      a = func->GetParameter(2);
      mind = -1*b/(2*a);
      minchi2 = func->Eval(mind);
      el=0;
      eh=0;
      e=0;
      e = (-1*b + TMath::Sqrt(b*b - 4*a*(c-minchi2-deltachi2)))/(2*a);
      if(e<mind) el=e;
      else eh = e;
      e=0;
      e = (-1*b - TMath::Sqrt(b*b - 4*a*(c-minchi2-deltachi2)))/(2*a);
      if(e<mind) el=e;
      else eh = e;
      errlo = mind - el;
      errhi = eh - mind;
      if(errhi>errlo) dpar[i].push_back(errhi);
      else dpar[i].push_back(errlo);
//       cout<<ddelta[i][j]<<endl;
    }
  }
  
  const int n = Chi2Map.size();
  int max=0;
  for(i=0;i<n;i++)
  {
    if(Chi2Map[i].size()>max) max = Chi2Map[i].size();
  }
  const int m = max;
  
  double d0[n][m];
  double dd[n][m];
  for(i=0;i<n;i++)
  {
    for(j=0;j<m;j++)
    {
      d0[i][j] = XVal[i][j];
      dd[i][j] = dpar[i][j];
    }
  }
  
  int cl=1;
  TCanvas *cv = new TCanvas("cv","cv",800,800);
  TGraph *g[n];
  for(i=0;i<n;i++)
  { 
    g[i] = new TGraph(Chi2Map[i].size(),d0[i],dd[i]);
    g[i]->SetName(Form("Res_%i",i));
    g[i]->SetMarkerStyle(20);
    g[i]->GetXaxis()->SetTitle(XLabel.c_str());
    g[i]->GetYaxis()->SetTitle(YLabel.c_str());
    g[i]->GetYaxis()->SetTitleOffset(1.25);
    g[i]->SetMinimum(0);
    g[i]->SetMaximum(60);
    g[i]->SetTitle("");
    g[i]->SetMarkerColor(cl);
    cl++;
    if(cl==0 || cl==10) cl++;
    if(i==0) g[i]->Draw("ap");
    else g[i]->Draw("psame");
  }
  
  TLegend *l = new TLegend(0.5,0.85-0.05*n,0.85,0.85);
  l->SetFillColor(0);
  l->SetBorderSize(0);
  for(i=0;i<n;i++)
  {
    l->AddEntry(g[i],Labels[i].c_str(),"p");
  }
  l->Draw();
  
  string out = ProjectName + ".eps";
  cv->SaveAs(out.c_str());
  
  out = ProjectName + ".root";
  TFile *f = new TFile(out.c_str(),"RECREATE");
  for(i=0;i<n;i++)
  {
    g[i]->Write();
  }
  f->Close();
  
  return;
}
void AccuracyPlotter::DrawSinSq2Th13ErrorVs(double deltachi2)
{
  MakeChi2Maps();
  
  int min=0,up=0,dn=0;
  double mincenter,mincont,upd,dnd,mind,minchi2;
  unsigned int i,j,k;
  TF1 *func;
  double a,b,c;
  double e,el,eh;
  double errlo,errhi;
  vector< vector<double> > dssq2th13;
  bool search;
  double x[nX],y[nX];
  TGraph *g1;
  
  for(i=0;i<Chi2Map.size();i++)
  {
    dssq2th13.push_back( vector<double>() );
    for(j=0;j<Chi2Map[i].size();j++)
    {
      min = Chi2Map[i][j]->GetMinimumBin();
      mincenter = Chi2Map[i][j]->GetXaxis()->GetBinCenter(min);
      
      search = true;
      up = nX;
      if(min+1>nX)
      {
        search = false;
      }
      if(search)
      {
        cout<<"looking for upper bound to fit between bins "<<min+1<<" "<<nX<<endl;
        for(k=min;k<nX;k++)
        {
          cout<<k+1<<", "<<Chi2Map[i][j]->GetBinContent(k+1)<<endl;
          if(Chi2Map[i][j]->GetBinContent(k+1)>4)
          {
            up = k+1;
            cout<<"found it: "<<up<<endl;
            break;
          }
        }
      }
      
      search = true;
      dn=1;
      if(min-1<1)
      {
        search = false;
      }
      if(search)
      {
        cout<<"looking for lower bound to fit between bins "<<min-2+1<<" 0"<<endl;
        for(k=min-2;k>0;k=k-1)
        {
          cout<<k+1<<", "<<Chi2Map[i][j]->GetBinContent(k+1)<<endl;
          if(Chi2Map[i][j]->GetBinContent(k+1)>4)
          {
            dn = k+1;
            cout<<"found it: "<<dn<<endl;
            break;
          }
        }
      }
      cout<<up<<", "<<dn<<endl;
      
      upd = Chi2Map[i][j]->GetXaxis()->GetBinUpEdge(up);
      dnd = Chi2Map[i][j]->GetXaxis()->GetBinLowEdge(dn);
      upd = TMath::Power(10,upd);
      dnd = TMath::Power(10,dnd);
      cout<<"Fitting between "<<dnd<<" "<<upd<<endl;
      
      for(k=0;k<nX;k++)
      {
        x[k] = Chi2Map[i][j]->GetXaxis()->GetBinCenter(k+1);
        y[k] = Chi2Map[i][j]->GetBinContent(k+1);
        x[k] = TMath::Power(10,x[k]);
      }
      g1 = new TGraph(nX,x,y);
      
      func = new TF1("myfunc","pol2",dnd,upd);
      g1->Fit(func,"Q","",dnd,upd);
      c = func->GetParameter(0);
      b = func->GetParameter(1);
      a = func->GetParameter(2);
      mind = -1*b/(2*a);
      minchi2 = func->Eval(mind);
      el=0;
      eh=0;
      e=0;
      e = (-1*b + TMath::Sqrt(b*b - 4*a*(c-minchi2-deltachi2)))/(2*a);
      if(e<mind) el=e;
      else eh = e;
      e=0;
      e = (-1*b - TMath::Sqrt(b*b - 4*a*(c-minchi2-deltachi2)))/(2*a);
      if(e<mind) el=e;
      else eh = e;
      errlo = mind - el;
      errhi = eh - mind;
      if(errhi>errlo) dssq2th13[i].push_back(errhi);
      else dssq2th13[i].push_back(errlo);
      cout<<dssq2th13[i][j]<<endl;
    }
  }
  
  const int n = Chi2Map.size();
  int max=0;
  for(i=0;i<n;i++)
  {
    if(Chi2Map[i].size()>max) max = Chi2Map[i].size();
  }
  const int m = max;
  
  double xn[n][m];
  double yn[n][m];
  for(i=0;i<n;i++)
  {
    for(j=0;j<m;j++)
    {
      xn[i][j] = XVal[i][j];
      yn[i][j] = dssq2th13[i][j];
    }
  }
  
  int cl=1;
  TCanvas *cv = new TCanvas("cv","cv",800,800);
  TGraph *g[n];
  for(i=0;i<n;i++)
  { 
    g[i] = new TGraph(Chi2Map[i].size(),xn[i],yn[i]);
    g[i]->SetName(Form("Th13Acc_%i",i));
    g[i]->SetMarkerStyle(20);
    g[i]->GetXaxis()->SetTitle(XLabel.c_str());
    g[i]->GetYaxis()->SetTitle(YLabel.c_str());
    g[i]->GetYaxis()->SetTitleOffset(1.25);
    g[i]->SetMinimum(0);
    g[i]->SetMaximum(0.006);
    g[i]->SetTitle("");
    g[i]->SetMarkerColor(cl);
    cl++;
    if(cl==0 || cl==10) cl++;
    if(i==0) g[i]->Draw("ap");
    else g[i]->Draw("psame");
  }
  
  TLegend *l = new TLegend(0.5,0.85-0.05*n,0.85,0.85);
  l->SetFillColor(0);
  l->SetBorderSize(0);
  for(i=0;i<n;i++)
  {
    l->AddEntry(g[i],Labels[i].c_str(),"p");
  }
  l->Draw();
  
  string out = ProjectName + ".eps";
//   cv->SaveAs(out.c_str());
  
  out = ProjectName + ".root";
  TFile *f = new TFile(out.c_str(),"RECREATE");
  for(i=0;i<n;i++)
  {
    g[i]->Write();
  }
  f->Close();
  
  return;
}
