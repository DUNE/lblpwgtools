#ifndef DiscoveryPlotter_h
#define DiscoveryPlotter_h

#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include "TROOT.h"
#include "TH2D.h"
#include "TH1D.h"
#include "TFile.h"
#include "TCanvas.h"
#include "TLegend.h"
#include "TF1.h"
#include "TLatex.h"
#include "TStyle.h"
#include "TGraph.h"
#include "TMath.h"

using namespace std;

class DiscoveryPlotter{
  public:
    DiscoveryPlotter();
    virtual ~DiscoveryPlotter();
    void AddCurve(string datafile,string label);
    
    void SetX(int n=20, double low=-3, double high=-1);
    void SetY(int n=21, double low=-180, double high=180);
    void SetXLabel(string s="Log_{10}(sin^{2}(2#theta_{13}))") { XLabel = s; };
    void SetYLabel(string s="#delta_{CP}") { YLabel = s; };
    void SetLineColors(vector<int> colors);
    void SetLineStyles(vector<int> lstyle);
    void SetContourLevels(vector<double> levels);
    
    void DrawContours(string name="Cont");
    void DrawDeltaCoverage(string name,double deltachi2=1);
    void DrawContourPoint(string name,double val,vector<double> vs);
    
  private:
    void MakeChi2Maps();
    
    int nX,nY;
    double XLow,XHigh,YLow,YHigh;
    string XLabel,YLabel;
    vector<string> DataFiles;
    vector<string> Labels;
    vector<TH2D*> Chi2Map_Delta;
    vector<TH2D*> Chi2Map_Th13;
    vector<TH2D*> Chi2Map_Hier;
    bool init;
    vector<int> LineColor;
    vector<int> LineStyle;
    vector<double> Levels;
    string ProjectName;
    
};


#endif
