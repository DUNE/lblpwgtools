#define BubblePlotter_C

#include "BubblePlotter.h"

BubblePlotter::BubblePlotter()
{
  SetX();
  SetY();
  SetXLabel();
  SetYLabel();
  
  vector<int> colors;
  colors.push_back(kRed);
  colors.push_back(kBlue);
  SetLineColors(colors);
  
  vector<int> lstyle;
  lstyle.push_back(1);
  lstyle.push_back(2);
  SetLineStyles(lstyle);
  
  vector<double> levels;
  levels.push_back(2.71);
  levels.push_back(9);
  SetContourLevels(levels);
  
  init=false;
  
  return;
}
BubblePlotter::~BubblePlotter()
{
}
void BubblePlotter::AddCurve(string datafile,string label)
{
  DataFiles.push_back(datafile);
  Labels.push_back(label);
  return;
}
void BubblePlotter::SetX(int n,double low,double high)
{
  nX = n;
  
  double width = (high - low)/(n-1);
  XLow = low - width/2.;
  XHigh = high + width/2.;
  
  return;
}
void BubblePlotter::SetY(int n,double low,double high)
{
  nY = n;
  
  double width = (high - low)/(n-1);
  YLow = low - width/2.;
  YHigh = high + width/2.;
  
  return;
}
void BubblePlotter::SetLineColors(vector<int> colors)
{
  LineColor.clear();
  
  int i;
  for(i=0;i<colors.size();i++)
  {
    LineColor.push_back(colors[i]);
  }
  
  return;
}
void BubblePlotter::SetLineStyles(vector<int> lstyle)
{
  LineStyle.clear();
  
  int i;
  for(i=0;i<lstyle.size();i++)
  {
    LineStyle.push_back(lstyle[i]);
  }
  
  return;
}
void BubblePlotter::SetContourLevels(vector<double> levels)
{
  Levels.clear();
  
  int i;
  for(i=0;i<levels.size();i++)
  {
    Levels.push_back(levels[i]);
  }
  
  return;
}
void BubblePlotter::MakeChi2Maps()
{
  if(init) return;
  
  ifstream f;
  unsigned int i;
  string s;
  
  double x,y,chi2;
  
  for(i=0;i<DataFiles.size();i++)
  {
    Chi2Map.push_back(new TH2D(Form("Chi2Map_%i",i),"",nX,XLow,XHigh,nY,YLow,YHigh));
    
    Chi2Map[i]->GetXaxis()->SetTitle(XLabel.c_str());
    Chi2Map[i]->GetYaxis()->SetTitle(YLabel.c_str());
    Chi2Map[i]->SetStats(kFALSE);
    Chi2Map[i]->SetLineColor(LineColor[i]);
    Chi2Map[i]->SetLineStyle(LineStyle[i]);
    Chi2Map[i]->SetLineWidth(4);
    
    f.open(DataFiles[i].c_str());
    
    while(!f.eof())
    {
      getline(f,s);
      if(s[0]=='#') continue;//skip comments
      stringstream ss(s);
      ss >> x >> y >> chi2;
      
      Chi2Map[i]->Fill(x,y,chi2);
    }
    
    f.close();
  }
  
  string filename = "chi2maps_" + ProjectName + ".root";
  TFile *fmap = new TFile(filename.c_str(),"RECREATE");
  for(i=0;i<DataFiles.size();i++)
  {
    Chi2Map[i]->Write();
  }
  fmap->Close();
  
  init = true;
  
  return;
}
void BubblePlotter::SetTruePoints(vector<double> x, vector<double> y)
{
  xTrue.clear();
  yTrue.clear();
  
  unsigned int i;
  for(i=0;i<x.size();i++)
  {
    xTrue.push_back(x[i]);
    yTrue.push_back(y[i]);
  }
  
  return;
}
void BubblePlotter::DrawBubbles(string name)
{
  ProjectName = name;
  
  MakeChi2Maps();
  
  unsigned int i;
  double levels[1];
  unsigned int n = Chi2Map.size();
  
  TLegend *l = new TLegend(0.18,0.85-0.06*n,0.38,0.85);
  l->SetFillColor(0);
  l->SetBorderSize(0);
  for(i=0;i<Chi2Map.size();i++)
  {
    l->AddEntry(Chi2Map[i],Labels[i].c_str(),"l");
  }
  
  gStyle->SetPadLeftMargin(0.15);
  gStyle->SetPadRightMargin(0.05);
  
  TCanvas *c = new TCanvas("c","c",800,800);
  for(i=0;i<Chi2Map.size();i++)
  {
    levels[0] = Levels[i];
    Chi2Map[i]->SetContour(1,levels);
    if(i==0) 
    {
      Chi2Map[i]->GetYaxis()->SetTitleOffset(1.7);
      Chi2Map[i]->Draw("cont3");
    }
    else Chi2Map[i]->Draw("cont3 same");
  }
  l->Draw();
  
  TGraph *g;
  unsigned int nTrue = xTrue.size();
  double px[nTrue],py[nTrue];
  if(nTrue)
  {
    for(i=0;i<nTrue;i++)
    {
      px[i] = xTrue.at(i);
      py[i] = yTrue.at(i);
    }
    
    g = new TGraph(nTrue,px,py);
    g->SetMarkerStyle(28);
    g->Draw("psame");
  }
  
  string outname = name + ".eps";
  c->SaveAs(outname.c_str());
  
  outname = name + ".root";
  TFile *f = new TFile(outname.c_str(),"RECREATE");
  for(i=0;i<Chi2Map.size();i++)
  {
    Chi2Map[i]->Write();
  }
  f->Close();
  
  return;
}
