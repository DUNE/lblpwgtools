#ifndef AccuracyPlotter_h
#define AccuracyPlotter_h

#include <vector>
#include <string>
#include "TROOT.h"
#include "TH1D.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include "TCanvas.h"
#include "TF1.h"
#include "TMath.h"
#include "TGraph.h"
#include "TFile.h"
#include "TLegend.h"

using namespace std;

class AccuracyPlotter{
  public:
    AccuracyPlotter(string name="Acc");
    virtual ~AccuracyPlotter();
    void AddSet(int npts,string *files,double *vals,string label,double *truedeltavals);
    void SetX(int n=20, double low=-3, double high=-1);
    void SetXLabel(string s="true #delta_{CP} (degrees)") { XLabel = s; };
    void SetYLabel(string s="1#sigma error on #delta_{CP} (degrees)") { YLabel = s; };
    void DrawChi2();
    void DrawSinSq2Th13ErrorVs(double deltachi2=1);
    void DrawResVs(double deltachi2=1);
    
  private:
    void MakeChi2Maps();
    
    string ProjectName;
    int nX,nY;
    double XLow,XHigh;
    string XLabel,YLabel;
    vector< vector<string> > DataFiles;
    vector<string> Labels;
    vector< vector<double> > XVal;
    bool init;
    vector< vector<TH1D*> >Chi2Map;
    vector< vector<double> > TrueMin;
};


#endif
