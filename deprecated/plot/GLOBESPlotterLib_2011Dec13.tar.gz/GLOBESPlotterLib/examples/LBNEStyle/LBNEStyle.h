class TLegend;

namespace LBNEStyle
{
   void SetupLBNEStyle();
   void FormatLegend(TLegend *l);
   
   //colors and line styles
   const static int ThreeSigmaColor=kRed;
   const static int FiveSigmaColor=kBlue;
   const static int NinetyPercentColor=kBlack;
   const static int NormalHierLine = 1;
   const static int InvertedHierLine = 2;
}
