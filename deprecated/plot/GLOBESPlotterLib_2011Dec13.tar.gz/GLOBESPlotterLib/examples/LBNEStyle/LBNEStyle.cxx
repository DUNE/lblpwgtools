#include "TROOT.h"
#include "TStyle.h"
#include "TLegend.h"
#include "TColor.h"
#include "LBNEStyle.h"

using namespace std;

void LBNEStyle::SetupLBNEStyle()
{
gROOT->SetStyle("Plain");
gStyle->SetPadTickX(1);
gStyle->SetPadTickY(1);

// Turn off all borders
gStyle->SetCanvasBorderMode(0);
gStyle->SetFrameBorderMode(0);
gStyle->SetPadBorderMode(0);
gStyle->SetDrawBorder(0);
gStyle->SetCanvasBorderSize(0);
gStyle->SetFrameBorderSize(0);
gStyle->SetPadBorderSize(0);
gStyle->SetTitleBorderSize(0);

// Set the size of the default canvas
gStyle->SetCanvasDefH(600);
gStyle->SetCanvasDefW(730);
gStyle->SetCanvasDefX(10);
gStyle->SetCanvasDefY(10);

//set marker style
gStyle->SetMarkerStyle(20);
gStyle->SetMarkerSize(1);

// Set Line Widths
gStyle->SetFrameLineWidth(1);
gStyle->SetFuncWidth(2);
gStyle->SetHistLineWidth(4);
gStyle->SetFuncColor(2);
gStyle->SetFuncWidth(3);

gStyle->SetPadLeftMargin(0.15);
gStyle->SetPadRightMargin(0.05);

gStyle->SetTitleOffset(1.7,"y");

// Set paper size for life in the US
gStyle->SetPaperSize(TStyle::kUSLetter);

gStyle->SetTitleY(.90);
gStyle->SetPalette(1);

gStyle->SetLegendBorderSize(0);
// gROOT->ForceStyle();
}

void LBNEStyle::FormatLegend(TLegend *l)
{
   l->SetFillStyle(0);
   l->SetBorderSize(0);
}



