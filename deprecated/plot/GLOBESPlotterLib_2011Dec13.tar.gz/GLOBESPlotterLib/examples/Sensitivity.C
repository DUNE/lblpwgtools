#include <vector>

void Sensitivity()
{
  //Use this to draw the sensitivity curves.
  
  //load GLOBESPlotterLib
  gSystem->Load("/home/lisa/LBNE/GLOBESPlotterLib/lib/libGLOBESPlotterLib.so");
  
  //Create a DiscoveryPlotter object.  DiscoveryPlotter takes in a .plt file (see the documentation for what that means) and draws the non-zero theta13, mass hierarchy, and CP discovery sensitivity curves.
  //use AddCurve(string filename,string label) for each curve you want drawn. 'label' is in TLatex style.
  //Note if you want to show more than one CL for a given data set, you have to add the file more than once (below, we use WC_Disc.plt for both the 3 sigma and 5 sigma curve).  
  DiscoveryPlotter *p = new DiscoveryPlotter();
  p->AddCurve("WC_Disc.plt","3#sigma, Normal");
  p->AddCurve("WC_Disc.plt","5#sigma, Normal");
  p->AddCurve("WC_Disc_i.plt","3#sigma, Inverted");
  p->AddCurve("WC_Disc_i.plt","5#sigma, Inverted");
  
  //SetX(number of log(sin^2(2theta13)) points and the range (inclusive) of those points. 
  //SetY(number of delta_CP points and the range (inclusive) of those points (in degrees).
  //set the labels for each axis
  p->SetX(51,-3.5,-1);
  p->SetY(73,-180,180);
  p->SetXLabel("log(sin^{2}(2#theta_{13}))");
  p->SetYLabel("#delta_{CP} (degrees)");
  
  //Set a vector that determines what color each curve will be.  Each entry is the ROOT TColor code.
  //Here, the 3sigma curves will be red and the 5 sigma curves will be blue.
  vector<int> colors;
  colors.push_back(kRed);
  colors.push_back(kBlue);
  colors.push_back(kRed);
  colors.push_back(kBlue);
  p->SetLineColors(colors);
  
  //Set a vector that determines what line style each curve will be.  Each entry is the ROOT TAttLine style code.
  //Here, the normal hierarchy cuves will be solid and the inverted hierarchy curves will be dashed.
  vector<int> styles;
  styles.push_back(1);
  styles.push_back(1);
  styles.push_back(2);
  styles.push_back(2);
  p->SetLineStyles(styles);
  
  //Set a vector that determines the contour level, i.e. for what delta-chi2 do you want to draw the contour.
  //The 3sigma curves correspond to a delta-chi2 of 9, and the 5sigma curves correspond to a delta-chi2 of 25
  vector<double> levels;
  levels.push_back(9);
  levels.push_back(25);
  levels.push_back(9);
  levels.push_back(25);
  p->SetContourLevels(levels);
  
  //Draw it!  
  //The string will be used in the names of the output files:
  //"xx.root" Has each histogram (#input files x 3) AFTER the contour level has been set.  Draw with histname->Draw("cont3") to see the contour curve.
  //"chi2maps_xx.root" Has each chi2 vs delta_CP vs log(sin^2(2theta13))  histogram (#input files x 3) BEFORE the contour level has been set, so you can see the whole chi2 map.  Draw with histname->Draw("colz").
  //"xx_Delta.eps","xx_Th13.eps","xx_Hier.eps" - each plot will be saved to an eps file.
  p->DrawContours("Sensitivity");
  
  //To make a pretty plot (like with the nice sin^2(2theta13) axis), you'll have to read in the histograms from the file into another script.
  
  return;
}
