#include "LBNEStyle/LBNEStyle.cxx"

void DrawSensitivity()
{  
  //use style class
  LBNEStyle::SetupLBNEStyle();
  
  //read sensitivity curves from a file
  TFile *f = new TFile("Sensitivity_DrawExample.root","READ");
  
  TH2D *Th13_3 = (TH2D*)f->Get("Chi2Map_Th13_0");
  TH2D *Th13_5 = (TH2D*)f->Get("Chi2Map_Th13_1");
  TH2D *Th13i_3 = (TH2D*)f->Get("Chi2Map_Th13_2");
  TH2D *Th13i_5 = (TH2D*)f->Get("Chi2Map_Th13_3");
  
  TH2D *Hier_3 = (TH2D*)f->Get("Chi2Map_Hier_0");
  TH2D *Hier_5 = (TH2D*)f->Get("Chi2Map_Hier_1");
  TH2D *Hieri_3 = (TH2D*)f->Get("Chi2Map_Hier_2");
  TH2D *Hieri_5 = (TH2D*)f->Get("Chi2Map_Hier_3");
  
  TH2D *Delta_3 = (TH2D*)f->Get("Chi2Map_Delta_0");
  TH2D *Delta_5 = (TH2D*)f->Get("Chi2Map_Delta_1");
  TH2D *Deltai_3 = (TH2D*)f->Get("Chi2Map_Delta_2");
  TH2D *Deltai_5 = (TH2D*)f->Get("Chi2Map_Delta_3");
  
  //set up a legend
  TLegend *l = new TLegend(0.17,0.47,0.47,0.67);
  LBNEStyle::FormatLegend(l);
  l->AddEntry(Th13_3,"3#sigma, normal","l");
  l->AddEntry(Th13_5,"5#sigma, normal","l");
  l->AddEntry(Th13i_3,"3#sigma, inverted","l");
  l->AddEntry(Th13i_5,"5#sigma, inverted","l");
  
  //get rid of the x-axis labels (which are linear in log(sin^2(2theta_13))
  Th13_3->GetXaxis()->SetNdivisions(0);
  Th13_3->GetXaxis()->SetLabelOffset(99);
  
  Hier_3->GetXaxis()->SetNdivisions(0);
  Hier_3->GetXaxis()->SetLabelOffset(99);
  
  Delta_3->GetXaxis()->SetNdivisions(0);
  Delta_3->GetXaxis()->SetLabelOffset(99);
  
  //change the axis labels, because now we're going to draw sin^2(2theta_13) instead of log(sin^2(2theta_13))
  Th13_3->GetXaxis()->SetTitle("sin^{2}(2#theta_{13})");
  
  Hier_3->GetXaxis()->SetTitle("sin^{2}(2#theta_{13})");
  
  Delta_3->GetXaxis()->SetTitle("sin^{2}(2#theta_{13})");
  
  double lowedge = Th13_3->GetXaxis()->GetBinLowEdge(1);
  double highedge = Th13_3->GetXaxis()->GetBinUpEdge(Th13_3->GetNbinsX());
  cout<<lowedge<<", "<<highedge<<endl;
  
  double lowedge_pow10 = TMath::Power(10,lowedge);
  double highedge_pow10 = TMath::Power(10,highedge);
  cout<<lowedge_pow10<<", "<<highedge_pow10<<endl;
  
  double ylowedge = Th13_3->GetYaxis()->GetBinLowEdge(1);
  double yhighedge = Th13_3->GetYaxis()->GetBinUpEdge(Th13_3->GetNbinsY());
  cout<<ylowedge<<", "<<yhighedge<<endl;
  
  TLatex time;
  time.SetNDC();
  time.SetTextSize(0.045);
  TLatex power;
  power.SetNDC();
  power.SetTextSize(0.045);
  TLatex mass;
  mass.SetNDC();
  mass.SetTextSize(0.045);
  TLatex title;
  title.SetNDC();
  
  //The edges of the xaxis are actually -3.525 (which is log(sin^2(2theta_13)), but we want that to read 10^-3.525 (because we want to draw sin^2(2theta_13).
  //So we make a new axis with the edge at 10^-3.525 and then we'll draw that new axis in log scale
  //Note you maybe be able to see the new axis when you draw interactively, but look at the output eps files.  It should be drawn there.
  TGaxis *tg = new TGaxis(lowedge_pow10,ylowedge,highedge_pow10,ylowedge,lowedge_pow10,highedge_pow10,4,"G");
  
  TCanvas *c1 = new TCanvas("c1","",800,800);
  Th13_3->Draw("cont3");
  Th13_5->Draw("cont3 same");
  Th13i_3->Draw("cont3 same");
  Th13i_5->Draw("cont3 same");
  l->Draw();
  mass.DrawLatex(0.18,0.86,"200 kton WC");
  time.DrawLatex(0.18,0.81,"5 yrs #nu + 5 yrs #bar{#nu}");
  power.DrawLatex(0.18,0.76,"700 kW");
  title.DrawLatex(0.15,0.93,"#theta_{13} Sensitivity");
  
  c1->cd();
  TPad *overlay2 = new TPad("overlay2","",0,0,1,1);
  overlay2->SetFillStyle(4000);
  overlay2->SetFillColor(0);
  overlay2->SetFrameFillStyle(4000);
  overlay2->Draw();
  overlay2->cd();
  TH1F *hframe2 = overlay2->DrawFrame(lowedge_pow10,ylowedge,highedge_pow10,yhighedge);
  hframe2->GetXaxis()->SetLabelOffset(99);
  hframe2->GetYaxis()->SetLabelOffset(99);
  hframe2->SetNdivisions(0,"xy");
  tg->Draw();
  c1->SaveAs("Sensitivity_DrawExample_Th13.eps");
  
  TCanvas *c2 = new TCanvas("c2","",800,800);
  Hier_3->Draw("cont3");
  Hier_5->Draw("cont3 same");
  Hieri_3->Draw("cont3 same");
  Hieri_5->Draw("cont3 same");
  l->Draw();
  mass.DrawLatex(0.18,0.86,"200 kton WC");
  time.DrawLatex(0.18,0.81,"5 yrs #nu + 5 yrs #bar{#nu}");
  power.DrawLatex(0.18,0.76,"700 kW");
  title.DrawLatex(0.15,0.93,"Mass Hierarchy Sensitivity");
  
  c2->cd();
  overlay2->Draw();
  overlay2->cd();
  TH1F *hframe2 = overlay2->DrawFrame(lowedge_pow10,ylowedge,highedge_pow10,yhighedge);
  hframe2->GetXaxis()->SetLabelOffset(99);
  hframe2->GetYaxis()->SetLabelOffset(99);
  hframe2->SetNdivisions(0,"xy");
  tg->Draw();
  c2->SaveAs("Sensitivity_DrawExample_Hier.eps");
  
  TCanvas *c3 = new TCanvas("c3","",800,800);
  Delta_3->Draw("cont3");
  Delta_5->Draw("cont3 same");
  Deltai_3->Draw("cont3 same");
  Deltai_5->Draw("cont3 same");
  l->Draw();
  mass.DrawLatex(0.18,0.86,"200 kton WC");
  time.DrawLatex(0.18,0.81,"5 yrs #nu + 5 yrs #bar{#nu}");
  power.DrawLatex(0.18,0.76,"700 kW");
  title.DrawLatex(0.15,0.93,"CPV Sensitivity");
  
  c3->cd();
  overlay2->Draw();
  overlay2->cd();
  TH1F *hframe2 = overlay2->DrawFrame(lowedge_pow10,ylowedge,highedge_pow10,yhighedge);
  hframe2->GetXaxis()->SetLabelOffset(99);
  hframe2->GetYaxis()->SetLabelOffset(99);
  hframe2->SetNdivisions(0,"xy");
  tg->Draw();
  c3->SaveAs("Sensitivity_DrawExample_Delta.eps");
  
  return;
}
