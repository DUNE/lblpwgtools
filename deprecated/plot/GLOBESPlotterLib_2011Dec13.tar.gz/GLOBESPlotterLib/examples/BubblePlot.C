#include <vector>

void BubblePlot()
{
  //Use this to draw the contours for a delta_CP and sin^2(2theta13) simulataneous measurement.
  
  //load GLOBESPlotterLib
  gSystem->Load("/home/lisa/LBNE/GLOBESPlotterLib/lib/libGLOBESPlotterLib.so");
  
  //Create a BubblePlotter object.  BubblePlotter takes in a .dat file (see the documentation for details) and draws the contours for a delta_CP vs sin^2(2theta13) measurement.
  //use AddCurve(string filename,string label) for each curve you want drawn. 'label' is in TLatex style.
  BubblePlotter *p = new BubblePlotter();
  p->AddCurve("WC_JellyBean_700.dat","delta=-90, 68% CL");
  p->AddCurve("WC_JellyBean_700.dat","delta=-90, 95% CL");
  p->AddCurve("WC_JellyBean_700_delta0.dat","delta=0, 68% CL");
  p->AddCurve("WC_JellyBean_700_delta0.dat","delta=0, 95% CL");
  
  //SetX(number of log(sin^2(2theta13)) points and the range (inclusive) of those points. 
  //SetY(number of delta_CP points and the range (inclusive) of those points (in degrees).
  //set the labels for each axis
  p->SetX(51,-3,-0.5);
  p->SetY(85,-210,210);
  p->SetXLabel("log(sin^{2}(2#theta_{13}))");
  p->SetYLabel("#delta_{CP} (degrees)");
  
  //Set a vector that determines what color each curve will be.  Each entry is the ROOT TColor code.
  //Here, the 68% curves will be red and the 95% curves will be blue.
  vector<int> colors;
  colors.push_back(kRed);
  colors.push_back(kBlue);
  colors.push_back(kRed);
  colors.push_back(kBlue);
  p->SetLineColors(colors);
  
  //Set a vector that determines what line style each curve will be.  Each entry is the ROOT TAttLine style code.
  //Here, all curves are solid
  vector<int> styles;
  styles.push_back(1);
  styles.push_back(1);
  styles.push_back(1);
  styles.push_back(1);
  p->SetLineStyles(styles);
  
  //Set a vector that determines the contour level, i.e. for what delta-chi2 do you want to draw the contour.
  //The 68% curves correspond to a delta-chi2 of 2.3, and the 95% curves correspond to a delta-chi2 of 6 (these are the delta-chi2 for *2* degrees of freedom!)
  vector<double> levels;
  levels.push_back(2.3);
  levels.push_back(6);
  levels.push_back(2.3);
  levels.push_back(6);
  p->SetContourLevels(levels);
  
  //if you want to draw the true values on the plot, use this function.  leave this part out if you don't want true values on there.
  vector<double> xtrue;
  xtrue.push_back(-2);
  xtrue.push_back(-2);
  vector<double> ytrue;
  ytrue.push_back(-90);
  ytrue.push_back(0);
  p->SetTruePoints(xtrue,ytrue);
  
  //Draw it!  
  //The string will be used in the names of the output files:
  //"xx.root" Has each histogram AFTER the contour levels have been set.  Draw with histname->Draw("cont3") to see the contour curves.
  //"chi2maps_xx.root" Has each chi2 vs delta_CP vs log(sin^2(2theta13))  histogram BEFORE the contour level has been set, so you can see the whole chi2 map.  Draw with histname->Draw("colz").
  //"xx.eps" Each plot will be saved to an eps file.
  p->DrawBubbles("Bubbles");
  
  //To make a pretty plot (like with the nice sin^2(2theta13) axis), you'll have to read in the histograms from the file into another script.
  
  return;
}
