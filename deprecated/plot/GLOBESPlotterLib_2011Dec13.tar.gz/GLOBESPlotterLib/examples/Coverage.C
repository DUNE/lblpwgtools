void Coverage()
{
  //Use this to draw delta_CP coverage vs log(sin^2(2theta13)) for each measurement.
  
  //load GLOBESPlotterLib
  gSystem->Load("/home/lisa/LBNE/GLOBESPlotterLib/lib/libGLOBESPlotterLib.so");
  
  //Create a DiscoveryPlotter object.  DiscoveryPlotter takes in a .plt file (see the documentation for what that means) and draws the CP coverage vs Log(sin^2(2theta13) for each sensitivity (non-zero theta13, mass hierarchy, CPV discovery).
  //use AddCurve(string filename,string label) for each curve you want drawn. 'label' is in TLatex style.
  DiscoveryPlotter *p = new DiscoveryPlotter();
  p->AddCurve("WC_Disc.plt","normal hierarchy");
  p->AddCurve("WC_Disc_i.plt","inverted hierarchy");
  
  //SetX(int number of log(sin^2(2theta13)) points and the range (inclusive) of those points. 
  //SetY(int number of delta_CP points and the range (inclusive) of those points (in degrees).
  //set the label for the x axis.
  p->SetX(51,-3.5,-1);
  p->SetY(73,-180,180);
  
  //Draw it!  
  //The string will be used in the names of the output files:
  //"xx.root" Has the coverage vs log(sin^2(2theta13)) histograms (# input files x 3)
  //"chi2maps_xx.root" Has each chi2 vs delta_CP vs log(sin^2(2theta13)) histogram (#input files x 3) BEFORE the contour level has been set, so you can see the whole chi2 map.  Draw with histname->Draw("colz").
  //"xx_Delta.eps","xx_Th13.eps","xx_Hier.eps" - each coverage plot will be saved to an eps file.
  //The number is the contour level, i.e. for what delta-chi2 do you want to know the coverage.  delta-chi2 of 9 corresponds to 3 sigma.
  p->DrawDeltaCoverage("Coverage",9);
  
  //Note - this function doesn't use the color/line style settings or the axis label settings.
  //To make a pretty plot (like with the nice sin^2(2theta13) axis), you'll have to read in the histograms from the file into another script.
  
  return;
}
