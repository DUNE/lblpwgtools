void DeltaResVsBaseline()
{
  //Use this to draw the 1-sigma delta_CP resolution vs some variable (here, baseline).
  
  //load GLOBESPlotterLib
  gSystem->Load("/home/lisa/LBNE/GLOBESPlotterLib/lib/libGLOBESPlotterLib.so");
 
  //Create a AccuracyPlotter object.  AccuracyPlotter takes in a .dat file (see the documentation for the format) and draws the 1-sigma delta_CP resolution vs some variable (here it's baseline).
  //The string will be used in the names of the output files:
  //"xx.root" Has delta_CP resolution vs variable curve (TGraphs) for each set of points.
  //"xx.eps" The plot is saved to an eps file.
  AccuracyPlotter *p = new AccuracyPlotter("DeltaResVsBaseline");
  
  double vals_LE[9] = {500,750,1000,1300,1500,1750,2000,2250,2500};
  double true_LE[9] = {0,0,0,0,0,0,0,0,0};
  string files_LE[9] = {"LE_SK1_80LL_500_0.04.dat","LE_SK1_80LL_750_0.04.dat","LE_SK1_80LL_1000_0.04.dat","LE_SK1_80LL_1300_0.04.dat","LE_SK1_80LL_1500_0.04.dat","LE_SK1_80LL_1750_0.04.dat","LE_SK1_80LL_2000_0.04.dat","LE_SK1_80LL_2250_0.04.dat","LE_SK1_80LL_2500_0.04.dat"};
  
  //use AddSet(npts,files,vals,label,truevals) for each curve you want drawn. 'npts' is the number of points (ie number of baseline points), 'files' is an array of input file names that corresponds to each point, 'vals' is an array of variable values (baseline here),'label' is a string in TLatex style.
  //'truevals' is the true delta_CP value (here delta_CP=0).  The purpose of putting in the true delta_CP values is to help the algorithm find the true chi2 minimum when there are other local minima
  p->AddSet(9,files_LE,vals_LE,"LE beam",true_LE);
  //this script only draws one set for simplicity, but you can add another set and a second curve would be drawn
  
  //Set the number of points scanned in delta_CP and the range (inclusive) in degrees.
  p->SetX(71,-210,210);
  
  //Set the label for the x-axis in the resolution vs ?? plot
  p->SetXLabel("Baseline (km)");
  
  //Draw it!
  p->DrawResVs();
  
  //By default, it draw 1-sigma resolution (ie delta-chi2 = 1).  If you want a different CL, put the desired delta-chi2 as an input to DrawResVs(), i.e, p->DrawResVs(9) for a 3-sigma range.
  //To make a pretty plot, you'll have to read in the graphs from the file into another script.
  
 return;
}
