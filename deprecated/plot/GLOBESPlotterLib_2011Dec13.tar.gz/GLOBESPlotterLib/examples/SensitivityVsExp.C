#include <vector>

void SensitivityVsExp()
{
  //Use this to draw the sensitivity (in sin^2(2theta13)) at a particular value of delta_CP vs exposure.
  //Basically, it makes a series of sensitivity curves (one for each exposure), and then reads one point off each curve to draw that value vs exposure.
  
  //load GLOBESPlotterLib
  gSystem->Load("/home/lisa/LBNE/GLOBESPlotterLib/lib/libGLOBESPlotterLib.so");
  
  //Create a DiscoveryPlotter object.  DiscoveryPlotter takes in a .plt file (see the documentation for what that means) and draws the sensitivity (in sin^2(2theta13)) at a particular value of delta_CP for each measurement (non-zero theta13, mass hierarchy, and CPV discovery) as a function of exposure
  //use AddCurve(string filename,string label) for each point in exposure you want drawn. (You'll have a separate .plt file for each exposure) 'label' is in TLatex style.
  DiscoveryPlotter *pn = new DiscoveryPlotter();
  pn->AddCurve("WC_DiscVsExp_0-1.plt"," 0.3 yrs");
  pn->AddCurve("WC_DiscVsExp_0-2.plt"," 1.0 yrs");
  pn->AddCurve("WC_DiscVsExp_0-3.plt"," 5.0 yrs");
  pn->AddCurve("WC_DiscVsExp_0-4.plt"," 10 yrs");
  pn->AddCurve("WC_DiscVsExp_0-5.plt"," 15 yrs");
  pn->AddCurve("WC_DiscVsExp_0-6.plt"," 20 yrs");
  pn->AddCurve("WC_DiscVsExp_0-7.plt"," 25 yrs");
  pn->AddCurve("WC_DiscVsExp_0-8.plt"," 30 yrs");
  
  //SetX(number of log(sin^2(2theta13)) points and the range (inclusive) of those points. 
  //SetY(number of delta_CP points and the range (inclusive) of those points (in degrees).
  pn->SetX(51,-3.5,-1);
  pn->SetY(5,-10,10);
  
  //set the label for the exposure axis
  pn->SetXLabel("WC Exposure (kton #bullet years)");
  
  //Set a vector that determines the contour level, i.e. for what delta-chi2 do you want to draw the contour.
  //The 3sigma curves correspond to a delta-chi2 of 9.
  vector<double> levels3s;
  levels3s.push_back(9);
  levels3s.push_back(9);
  levels3s.push_back(9);
  levels3s.push_back(9);
  levels3s.push_back(9);
  levels3s.push_back(9);
  levels3s.push_back(9);
  levels3s.push_back(9);
  pn->SetContourLevels(levels3s);
  
  //Set a vector of the exposure points.  This will become the x axis of the sensitivity vs exposure plot.
  vector<double> exp;
  exp.push_back(60);//200 ktons * (0.15 yrs nu + 0.15 yrs antinu)
  exp.push_back(200);
  exp.push_back(1000);
  exp.push_back(2000);
  exp.push_back(3000);
  exp.push_back(4000);
  exp.push_back(5000);
  exp.push_back(6000);
  
  //Draw it!  
  //The string will be used in the names of the output files:
  //"xx.root" Has the sensitivity vs exposure curve (TGraphs) for theta13 and mass hierarchy discovery.
  //"chi2maps_xx.root" Has each chi2 vs delta_CP vs log(sin^2(2theta13)) histogram (#input files x 3) BEFORE the contour level has been set, so you can see the whole chi2 map.  Draw with histname->Draw("colz").
  //the number is the value of delta_CP for which you want to draw it. 'exp' is the vector of exposure points
  pn->DrawContourPoint("SensVsExp",0,exp);
  
  //Note: If the sensitivity is out of range and can't be calculated, it will be set to 0.  When making a nice version of the plot, you can use TGraph::RemovePoint() to get rid of it or TGraph::SetPoint() if you want to set it to something.
  //To make a pretty plot, you'll have to read in the graphs from the file into another script.
  
  return;
}
