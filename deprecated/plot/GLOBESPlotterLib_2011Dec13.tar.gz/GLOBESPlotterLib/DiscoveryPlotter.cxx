#define DiscoveryPlotter_C

#include "DiscoveryPlotter.h"

DiscoveryPlotter::DiscoveryPlotter()
{
  SetX();
  SetY();
  SetXLabel();
  SetYLabel();
  
  vector<int> colors;
  colors.push_back(kBlack);
  colors.push_back(kBlue);
  SetLineColors(colors);
  
  vector<int> lstyle;
  lstyle.push_back(1);
  lstyle.push_back(9);
  SetLineStyles(lstyle);
  
  vector<double> levels;
  levels.push_back(2.71);
  levels.push_back(9);
  SetContourLevels(levels);
  
  init=false;
  
  return;
}
DiscoveryPlotter::~DiscoveryPlotter()
{
}
void DiscoveryPlotter::AddCurve(string datafile,string label)
{
  DataFiles.push_back(datafile);
  Labels.push_back(label);
  return;
}
void DiscoveryPlotter::SetX(int n,double low,double high)
{
  nX = n;
  
  double width = (high - low)/(n-1);
  XLow = low - width/2.;
  XHigh = high + width/2.;
  
  return;
}
void DiscoveryPlotter::SetY(int n,double low,double high)
{
  nY = n;
  
  double width = (high - low)/(n-1);
  YLow = low - width/2.;
  YHigh = high + width/2.;
  
  return;
}
void DiscoveryPlotter::SetLineColors(vector<int> colors)
{
  LineColor.clear();
  
  int i;
  for(i=0;i<colors.size();i++)
  {
    LineColor.push_back(colors[i]);
  }
  
  return;
}
void DiscoveryPlotter::SetLineStyles(vector<int> lstyle)
{
  LineStyle.clear();
  
  int i;
  for(i=0;i<lstyle.size();i++)
  {
    LineStyle.push_back(lstyle[i]);
  }
  
  return;
}
void DiscoveryPlotter::SetContourLevels(vector<double> levels)
{
  Levels.clear();
  
  int i;
  for(i=0;i<levels.size();i++)
  {
    Levels.push_back(levels[i]);
  }
  
  return;
}
void DiscoveryPlotter::MakeChi2Maps()
{
  if(init) return;
  
  ifstream f;
  unsigned int i;
  string s;
  
  double x,y,chi2_cp,chi2_hier,chi2_th13,dummy;
  
  for(i=0;i<DataFiles.size();i++)
  {
    Chi2Map_Delta.push_back(new TH2D(Form("Chi2Map_Delta_%i",i),"",nX,XLow,XHigh,nY,YLow,YHigh));
    Chi2Map_Th13.push_back(new TH2D(Form("Chi2Map_Th13_%i",i),"",nX,XLow,XHigh,nY,YLow,YHigh));
    Chi2Map_Hier.push_back(new TH2D(Form("Chi2Map_Hier_%i",i),"",nX,XLow,XHigh,nY,YLow,YHigh));
    
    Chi2Map_Delta[i]->GetXaxis()->SetTitle(XLabel.c_str());
    Chi2Map_Delta[i]->GetYaxis()->SetTitle(YLabel.c_str());
    Chi2Map_Delta[i]->SetStats(kFALSE);
    Chi2Map_Delta[i]->SetLineColor(LineColor[i]);
    Chi2Map_Delta[i]->SetLineStyle(LineStyle[i]);
    Chi2Map_Delta[i]->SetLineWidth(4);
    
    Chi2Map_Th13[i]->GetXaxis()->SetTitle(XLabel.c_str());
    Chi2Map_Th13[i]->GetYaxis()->SetTitle(YLabel.c_str());
    Chi2Map_Th13[i]->SetStats(kFALSE);
    Chi2Map_Th13[i]->SetLineColor(LineColor[i]);
    Chi2Map_Th13[i]->SetLineStyle(LineStyle[i]);
    Chi2Map_Th13[i]->SetLineWidth(4);
    
    Chi2Map_Hier[i]->GetXaxis()->SetTitle(XLabel.c_str());
    Chi2Map_Hier[i]->GetYaxis()->SetTitle(YLabel.c_str());
    Chi2Map_Hier[i]->SetStats(kFALSE);
    Chi2Map_Hier[i]->SetLineColor(LineColor[i]);
    Chi2Map_Hier[i]->SetLineStyle(LineStyle[i]);
    Chi2Map_Hier[i]->SetLineWidth(4);
    
    f.open(DataFiles[i].c_str());
    
    while(!f.eof())
    {
      getline(f,s);
      if(s[0]=='#') continue;//skip comments
      stringstream ss(s);
      ss >> x >> y >> chi2_cp >> chi2_hier >> chi2_th13 >> dummy >> dummy;
      
      Chi2Map_Delta[i]->Fill(x,y,chi2_cp);
      Chi2Map_Th13[i]->Fill(x,y,chi2_th13);
      Chi2Map_Hier[i]->Fill(x,y,chi2_hier);
    }
    
    f.close();
  }
  
  string filename = "chi2maps_" + ProjectName + ".root";
  TFile *fmap = new TFile(filename.c_str(),"RECREATE");
  for(i=0;i<DataFiles.size();i++)
  {
    Chi2Map_Delta[i]->Write();
    Chi2Map_Th13[i]->Write();
    Chi2Map_Hier[i]->Write();
  }
  fmap->Close();
  
  init = true;
  
  return;
}
void DiscoveryPlotter::DrawContours(string name)
{
  ProjectName = name;
  
  MakeChi2Maps();
  
  TLatex *del = new TLatex(-3.25,200,"#delta_{CP} Discovery");
  TLatex *t13 = new TLatex(-3.25,200,"#theta_{13} Discovery");
  TLatex *mh = new TLatex(-3.25,200,"Hierarchy Discovery");
  
  unsigned int i;
  double levels[1];
  unsigned int n = Chi2Map_Delta.size();
  
  TLegend *l = new TLegend(0.18,0.85-0.06*n,0.38,0.85);
  l->SetFillColor(0);
  l->SetBorderSize(0);
  for(i=0;i<Chi2Map_Delta.size();i++)
  {
    l->AddEntry(Chi2Map_Delta[i],Labels[i].c_str(),"l");
  }
  
  gStyle->SetPadLeftMargin(0.15);
  gStyle->SetPadRightMargin(0.05);
  
  TCanvas *cd = new TCanvas("Contours_Delta","",800,800);
  for(i=0;i<Chi2Map_Delta.size();i++)
  {
    levels[0] = Levels[i];
    Chi2Map_Delta[i]->SetContour(1,levels);
    if(i==0) 
    {
      Chi2Map_Delta[i]->GetYaxis()->SetTitleOffset(1.7);
      Chi2Map_Delta[i]->Draw("cont3");
    }
    else Chi2Map_Delta[i]->Draw("cont3 same");
  }
  l->Draw();
  del->Draw();
  string outname = name + "_Delta.eps";
  cd->SaveAs(outname.c_str());
  
  TCanvas *ct = new TCanvas("Contours_Th13","",800,800);
  for(i=0;i<Chi2Map_Th13.size();i++)
  {
    levels[0] = Levels[i];
    Chi2Map_Th13[i]->SetContour(1,levels);
    if(i==0) 
    {
      Chi2Map_Th13[i]->GetYaxis()->SetTitleOffset(1.7);
      Chi2Map_Th13[i]->Draw("cont3");
    }
    else Chi2Map_Th13[i]->Draw("cont3 same");
  }
  l->Draw();
  t13->Draw();
  outname = name + "_Th13.eps";
  ct->SaveAs(outname.c_str());
  
  TCanvas *ch = new TCanvas("Contours_Hier","",800,800);
  for(i=0;i<Chi2Map_Hier.size();i++)
  {
    levels[0] = Levels[i];
    Chi2Map_Hier[i]->SetContour(1,levels);
    if(i==0) 
    {
      Chi2Map_Hier[i]->GetYaxis()->SetTitleOffset(1.7);
      Chi2Map_Hier[i]->Draw("cont3");
    }
    else Chi2Map_Hier[i]->Draw("cont3 same");
  }
  l->Draw();
  mh->Draw();
  outname = name + "_Hier.eps";
  ch->SaveAs(outname.c_str());
  
  outname = name + ".root";
  TFile *f = new TFile(outname.c_str(),"RECREATE");
  for(i=0;i<Chi2Map_Th13.size();i++)
  {
    Chi2Map_Th13[i]->Write();
    Chi2Map_Delta[i]->Write();
    Chi2Map_Hier[i]->Write();
  }
  f->Close();
  
  return;
}
void DiscoveryPlotter::DrawDeltaCoverage(string name,double deltachi2)
{
  ProjectName = name;
  
  MakeChi2Maps();
  
  vector<TH1D*> DeltaCov_Delta;
  vector<TH1D*> DeltaCov_Th13;
  vector<TH1D*> DeltaCov_Hier;
  
  double t13;
  int ntotal=0;
  int ncovered=0;
  TH1D *h;
  double level = deltachi2;
  
//   TF1* fn = new TF1("fn","[0] + [1]*x + [2]*x^2 + [3]*x^3 + [4]*x^4 + [5]*x^5 + [6]*x^6 + [7]*x^7 + [8]*x^8 + [9]*x^9 + [10]*x^10 + [11]*x^11");
  double eval;
  
  unsigned int i,j,k;
  for(i=0;i<Chi2Map_Delta.size();i++)
  {
    DeltaCov_Delta.push_back(new TH1D(Form("DeltaCov_Delta_%i",i),"",nX,XLow,XHigh));
    DeltaCov_Delta[i]->GetXaxis()->SetTitle("Log_{10}(sin^{2}(2#theta_{13}))");
    DeltaCov_Delta[i]->GetYaxis()->SetTitle("#delta_{CP} coverage (%)");
    DeltaCov_Delta[i]->SetStats(kFALSE);
    
    DeltaCov_Th13.push_back(new TH1D(Form("DeltaCov_Th13_%i",i),"",nX,XLow,XHigh));
    DeltaCov_Th13[i]->GetXaxis()->SetTitle("Log_{10}(sin^{2}(2#theta_{13}))");
    DeltaCov_Th13[i]->GetYaxis()->SetTitle("#delta_{CP} coverage (%)");
    DeltaCov_Th13[i]->SetStats(kFALSE);
    
    DeltaCov_Hier.push_back(new TH1D(Form("DeltaCov_Hier_%i",i),"",nX,XLow,XHigh));
    DeltaCov_Hier[i]->GetXaxis()->SetTitle("Log_{10}(sin^{2}(2#theta_{13}))");
    DeltaCov_Hier[i]->GetYaxis()->SetTitle("#delta_{CP} coverage (%)");
    DeltaCov_Hier[i]->SetStats(kFALSE);
    
    for(j=0;j<nX;j++)
    {
      h = (TH1D*)Chi2Map_Delta[i]->ProjectionY("temp",j+1,j+1);
      t13 = Chi2Map_Delta[i]->GetXaxis()->GetBinCenter(j+1);
      ntotal=0;
      ncovered=0;
//       h->Fit("fn","Q","",h->GetXaxis()->GetBinCenter(2),h->GetXaxis()->GetBinCenter(nY-1));
//       for(k=0;k<361;k++)
//       {
//         eval = fn->Eval(-180 + k);
//         ntotal++;
//         if(eval>level) ncovered++;
//       }
      
      for(k=0;k<h->GetNbinsX();k++)
      {
        ntotal++;
        if(h->GetBinContent(k+1)>level)
        {
          ncovered++;
        }
      }
      DeltaCov_Delta[i]->Fill(t13,100.*ncovered/ntotal);
      
      h = (TH1D*)Chi2Map_Th13[i]->ProjectionY("temp",j+1,j+1);
      t13 = Chi2Map_Th13[i]->GetXaxis()->GetBinCenter(j+1);
      ntotal=0;
      ncovered=0;
//       h->Fit("fn","Q","",h->GetXaxis()->GetBinCenter(2),h->GetXaxis()->GetBinCenter(nY-1));
//       for(k=0;k<361;k++)
//       {
//         eval = fn->Eval(-180 + k);
//         ntotal++;
//         if(eval>level) ncovered++;
//       }
      
      for(k=0;k<h->GetNbinsX();k++)
      {
        ntotal++;
        if(h->GetBinContent(k+1)>level)
        {
          ncovered++;
        }
      }
      DeltaCov_Th13[i]->Fill(t13,100.*ncovered/ntotal);
      
      h = (TH1D*)Chi2Map_Hier[i]->ProjectionY("temp",j+1,j+1);
      t13 = Chi2Map_Hier[i]->GetXaxis()->GetBinCenter(j+1);
      ntotal=0;
      ncovered=0;
//       h->Fit("fn","Q","",h->GetXaxis()->GetBinCenter(2),h->GetXaxis()->GetBinCenter(nY-1));
//       for(k=0;k<361;k++)
//       {
//         eval = fn->Eval(-180 + k);
//         ntotal++;
//         if(eval>level) ncovered++;
//       }
      
      for(k=0;k<h->GetNbinsX();k++)
      {
        ntotal++;
        if(h->GetBinContent(k+1)>level)
        {
          ncovered++;
        }
      }
      DeltaCov_Hier[i]->Fill(t13,100.*ncovered/ntotal);
    }
  }
  
  TLegend *l = new TLegend(0.1,0.5,0.5,0.9);
  l->SetFillColor(0);
  for(i=0;i<DeltaCov_Delta.size();i++)
  {
    l->AddEntry(DeltaCov_Delta[i],Labels[i].c_str(),"l");
  }
  
  int cl=1;
  TCanvas *cd = new TCanvas();
  DeltaCov_Delta[0]->SetMaximum(100);
  DeltaCov_Delta[0]->SetMinimum(0);
//   DeltaCov_Delta[0]->SetMarkerStyle(20);
  DeltaCov_Delta[0]->Draw("p");
  for(i=0;i<DeltaCov_Delta.size();i++)
  {
    DeltaCov_Delta[i]->SetLineColor(cl);
    DeltaCov_Delta[i]->SetLineWidth(4);
//     DeltaCov_Delta[i]->SetMarkerStyle(20);
    DeltaCov_Delta[i]->SetMarkerColor(cl);
    DeltaCov_Delta[i]->Draw("lpsame");
    cl++;
    if(cl==0 || cl==10) cl++;
  }
  l->Draw();
  string outfile = name + "_Delta.eps";
  cd->SaveAs(outfile.c_str());
  
  cl=1;
  TCanvas *ct = new TCanvas();
  DeltaCov_Th13[0]->SetMaximum(100);
  DeltaCov_Th13[0]->SetMinimum(0);
//   DeltaCov_Th13[0]->SetMarkerStyle(20);
  DeltaCov_Th13[0]->Draw("p");
  for(i=0;i<DeltaCov_Th13.size();i++)
  {
    DeltaCov_Th13[i]->SetLineColor(cl);
    DeltaCov_Th13[i]->SetLineWidth(4);
//     DeltaCov_Th13[i]->SetMarkerStyle(20);
    DeltaCov_Th13[i]->SetMarkerColor(cl);
    DeltaCov_Th13[i]->Draw("lpsame");
    cl++;
    if(cl==0 || cl==10) cl++;
  }
  l->Draw();
  outfile = name + "_Th13.eps";
  ct->SaveAs(outfile.c_str());
  
  cl=1;
  TCanvas *ch = new TCanvas();
  DeltaCov_Hier[0]->SetMaximum(100);
  DeltaCov_Hier[0]->SetMinimum(0);
//   DeltaCov_Hier[0]->SetMarkerStyle(20);
  DeltaCov_Hier[0]->Draw("p");
  for(i=0;i<DeltaCov_Hier.size();i++)
  {
    DeltaCov_Hier[i]->SetLineColor(cl);
    DeltaCov_Hier[i]->SetLineWidth(4);
//     DeltaCov_Hier[i]->SetMarkerStyle(20);
    DeltaCov_Hier[i]->SetMarkerColor(cl);
    DeltaCov_Hier[i]->Draw("lpsame");
    cl++;
    if(cl==0 || cl==10) cl++;
  }
  l->Draw();
  outfile = name + "_Hier.eps";
  ch->SaveAs(outfile.c_str());
  
  outfile = name + ".root";
  TFile *f = new TFile(outfile.c_str(),"RECREATE");
  for(i=0;i<Chi2Map_Th13.size();i++)
  {
    DeltaCov_Th13[i]->Write();
    DeltaCov_Delta[i]->Write();
    DeltaCov_Hier[i]->Write();
  }
  f->Close();
  
  return;
}
void DiscoveryPlotter::DrawContourPoint(string name,double val,vector<double> vs)
{
  ProjectName = name;
  
  MakeChi2Maps();
  
  gStyle->SetPadLeftMargin(0.15);
  gStyle->SetPadRightMargin(0.05);
  
  unsigned int i,j;
  double levels[1];
  double x,y;
  TCanvas *c = new TCanvas();
  vector<double> limit;
  
  for(i=0;i<Chi2Map_Th13.size();i++)
  {
    levels[0] = Levels[i];
    Chi2Map_Th13[i]->SetContour(1,levels);
    Chi2Map_Th13[i]->Draw("cont list");
    c->Update();
    TObjArray *conts = (TObjArray*)gROOT->GetListOfSpecials()->FindObject("contours");
    TGraph *g1 = new TGraph();
    g1->Merge((TList *)conts->At(0));
    limit.push_back(0);
    for(j=0;j<g1->GetN();j++)
    {
      g1->GetPoint(j,x,y);
      if(TMath::Abs(y-val)<1e-4)
      {
        limit[i] = TMath::Power(10,x);
        break;
      }
    }
  }
  
  const unsigned int n = vs.size();
  double xt[n],yt[n];
  for(i=0;i<n;i++)
  {
    xt[i] = vs[i];
    yt[i] = limit[i];
  }
  
  TCanvas *c1 = new TCanvas();
  TGraph *gt = new TGraph(n,xt,yt);
  string gname = name + "_Th13";
  gt->SetName(gname.c_str());
  gt->GetXaxis()->SetTitle(XLabel.c_str());
  gt->GetYaxis()->SetTitle("sin^{2}(2#theta_{13})");
  gt->GetYaxis()->SetTitleOffset(1.7);
  gt->SetMarkerStyle(20);
  gt->SetLineWidth(4);
  gt->SetTitle("");
  gt->SetMinimum(0);
  gt->Draw("alp");
  TLatex t13;
  t13.SetNDC();
  t13.DrawLatex(0.15,0.93,"#theta_{13} Sensitivity");
  c1->SetGridx();
  c1->SetGridy();
  string outname = name + "_Th13.eps";
  c1->SaveAs(outname.c_str());
  
  c->cd();
  vector<double> th13_hier;
  
  for(i=0;i<Chi2Map_Hier.size();i++)
  {
    levels[0] = Levels[i];
    Chi2Map_Hier[i]->SetContour(1,levels);
    Chi2Map_Hier[i]->Draw("cont list");
    c->Update();
    TObjArray *conts = (TObjArray*)gROOT->GetListOfSpecials()->FindObject("contours");
    TGraph *g1 = new TGraph();
    g1->Merge((TList *)conts->At(0));
    th13_hier.push_back(0);
    for(j=0;j<g1->GetN();j++)
    {
      g1->GetPoint(j,x,y);
      if(TMath::Abs(y-val)<1e-4)
      {
        th13_hier[i] = TMath::Power(10,x);
        break;
      }
    }
  }
  
  double xh[n],yh[n];
  for(i=0;i<n;i++)
  {
    xh[i] = vs[i];
    yh[i] = th13_hier[i];
  }
  
  TCanvas *c2 = new TCanvas();
  TGraph *gh = new TGraph(n,xh,yh);
  gname = name + "_Hier";
  gh->SetName(gname.c_str());
  gh->GetXaxis()->SetTitle(XLabel.c_str());
  gh->GetYaxis()->SetTitle("sin^{2}(2#theta_{13})");
  gh->GetYaxis()->SetTitleOffset(1.7);
  gh->SetMarkerStyle(20);
  gh->SetLineWidth(4);
  gh->SetTitle("");
  gh->SetMinimum(0);
  gh->Draw("alp");
  TLatex hier;
  hier.SetNDC();
  hier.DrawLatex(0.15,0.93,"Mass Hierarchy Sensitivity");
  c2->SetGridx();
  c2->SetGridy();
  outname = name + "_Hier.eps";
  c2->SaveAs(outname.c_str());
  
  string filename = name + ".root";
  TFile *f = new TFile(filename.c_str(),"RECREATE");
  gt->Write();
  gh->Write();
  f->Close();
  
  return;
}
