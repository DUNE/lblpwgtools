#ifndef BubblePlotter_h
#define BubblePlotter_h

#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include "TROOT.h"
#include "TH2D.h"
#include "TFile.h"
#include "TCanvas.h"
#include "TLegend.h"
#include "TLatex.h"
#include "TStyle.h"
#include "TGraph.h"

using namespace std;

class BubblePlotter{
  public:
    BubblePlotter();
    virtual ~BubblePlotter();
    void AddCurve(string datafile,string label);
    
    void SetX(int n=20, double low=-3, double high=-1);
    void SetY(int n=21, double low=-180, double high=180);
    void SetXLabel(string s="Log_{10}(sin^{2}(2#theta_{13}))") { XLabel = s; };
    void SetYLabel(string s="#delta_{CP}") { YLabel = s; };
    void SetLineColors(vector<int> colors);
    void SetLineStyles(vector<int> lstyle);
    void SetContourLevels(vector<double> levels);
    void SetTruePoints(vector<double> x, vector<double> y);
    
    void DrawBubbles(string name);
    
  private:
    void MakeChi2Maps();
    
    int nX,nY;
    double XLow,XHigh,YLow,YHigh;
    string XLabel,YLabel;
    vector<string> DataFiles;
    vector<string> Labels;
    vector<TH2D*> Chi2Map;
    bool init;
    vector<int> LineColor;
    vector<int> LineStyle;
    vector<double> Levels;
    string ProjectName;
    vector<double> xTrue;
    vector<double> yTrue;
    
};


#endif
